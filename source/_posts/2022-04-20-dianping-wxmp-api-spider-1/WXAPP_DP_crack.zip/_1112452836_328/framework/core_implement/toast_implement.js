module.exports = {
    setApp: function(t) {
        if (!t.__service_block__.__FRAMEWORK_TOAST_IMPLEMENT_LOADED__) {
            t.__service_block__.__FRAMEWORK_TOAST_IMPLEMENT_LOADED__ = 1;
            var e = 0;
            t.env.register(33001, function(n, o) {
                var i = o.icon || "none", c = 0 === o.duration ? 0 : o.duration || 1500;
                0 === c && (o.title || o.content || "none" !== i) && (c = 1e5);
                if (t.env.notify(33002, o), t.env.notify(33003, o), o.title || o.content || "none" !== i) {
                    var _ = {
                        icon: i,
                        duration: c,
                        mask: !1 !== o.mask
                    };
                    (o.title || o.content) && (_.title = o.title || o.content), _.duration >= 36e6 && (_.duration = 36e6), 
                    wx.showToast(_), "function" == typeof o.callback && (e && (clearTimeout(e), e = 0), 
                    _.duration < 12e4 && (e = setTimeout(function() {
                        e && (clearTimeout(e), e = 0), o.callback();
                    }, _.duration)), _.success = o.callback);
                } else 0 === c && (e && (clearTimeout(e), e = 0), wx.hideToast());
            });
        }
    }
};