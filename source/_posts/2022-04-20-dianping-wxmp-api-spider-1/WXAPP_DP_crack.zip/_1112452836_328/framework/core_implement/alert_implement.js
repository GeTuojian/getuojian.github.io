module.exports = {
    setApp: function(c) {
        c.__service_block__.__FRAMEWORK_ALERT_IMPLEMENT_WXMP_LOADED__ || (c.__service_block__.__FRAMEWORK_ALERT_IMPLEMENT_WXMP_LOADED__ = 1, 
        c.env.register(33101, function(o, t) {
            if (c.env.notify(33102, t), c.env.notify(33103, t), (t.content || t.title) && t.buttons && t.buttons[0]) {
                var n = t.buttons;
                t.buttons[1] && (n = [ t.buttons[1], t.buttons[0] ]);
                var l = {
                    content: t.content || t.title,
                    icon: t.icon || "none",
                    showCancel: !!n[1],
                    confirmText: n[0].label || n[0].text,
                    success: function(c) {
                        c.confirm ? "function" == typeof n[0].callback && n[0].callback() : c.cancel ? "function" == typeof n[1].callback && n[1].callback() : "function" == typeof t.closeCallback ? t.closeCallback() : n[1] ? "function" == typeof n[1].callback && n[1].callback() : n[0] && "function" == typeof n[0].callback && n[0].callback();
                    }
                };
                n[0].color ? l.confirmColor = n[0].color : l.confirmColor = "#000", n[1] && (l.cancelText = n[1].label || n[1].text || "取消", 
                n[1].color ? l.cancelColor = n[1].color : l.cancelColor = "#000"), wx.showModal(l);
            }
        }));
    }
};