var t = require("../class_define/intersection_observer.js");

module.exports = {
    setApp: function(e) {
        e.__service_block__.__FRAMEWORK_AUTO_LOG_SERVICE_LOADED__ || (e.__service_block__.__FRAMEWORK_AUTO_LOG_SERVICE_LOADED__ = 1, 
        e.env.register(20015, function(e, n) {
            var r = n.page;
            r.ob = new t({
                selector: ".auto-view",
                observeAll: !0,
                context: r,
                onElemView: function(t, e) {
                    getApp().env.notify(37002, {
                        identity: t,
                        data: e
                    });
                }
            }), r.ob.connect();
            var i = function(t) {
                if ("function" != typeof r[t]) return "continue";
                var e = r[t];
                r[t] = function() {
                    var t = arguments[0];
                    if (t && t.currentTarget && t.currentTarget.dataset) {
                        var n = t.currentTarget && t.currentTarget.dataset || {}, r = n.identity, i = n.lxdata;
                        r && getApp().env.notify(37001, {
                            identity: r,
                            data: i
                        });
                    }
                    return e.apply(this, arguments);
                };
            };
            for (var a in r) i(a);
            r.handleLxClick = function(t) {
                if (t && t.currentTarget && t.currentTarget.dataset) {
                    var e = t.currentTarget && t.currentTarget.dataset || {}, n = e.identity, r = e.lxdata;
                    n && getApp().env.notify(37001, {
                        identity: n,
                        data: r
                    });
                }
            };
        }), e.env.register(20012, function(t, e) {
            var n = e.page;
            "function" == typeof n.handleLxClick && (n.handleLxClick = null);
            for (var r in n) {
                var i = n[r];
                "function" == typeof i && i.__originalFunc && (n[r] = i.__originalFunc, i.__originalFunc = null);
            }
        }));
    }
};