module.exports = {
    setApp: function(e) {
        "undefined" != typeof wx && wx.requestPayment && (e.requestPayment = wx.requestPayment);
    }
};