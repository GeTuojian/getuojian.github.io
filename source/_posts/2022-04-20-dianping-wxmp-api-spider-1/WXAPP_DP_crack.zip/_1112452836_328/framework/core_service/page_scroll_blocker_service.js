module.exports = {
    setApp: function(e) {
        e.__service_block__.__FRAMEWORK_PAGE_SCROLL_BLOCKER_SERVICE_LOADED__ || (e.__service_block__.__FRAMEWORK_PAGE_SCROLL_BLOCKER_SERVICE_LOADED__ = 1, 
        e.env.register(20011, function(e, t) {
            var r = -1, n = 0, i = null, o = -1;
            t.onCatchTouch || (t.onCatchTouch = function(e) {
                c(e);
            });
            t.onHandleTouch || (t.onHandleTouch = function(e) {
                if ("touchstart" == e.type) {
                    var t = e.touches;
                    if (t && -1 !== r) {
                        for (var u = !1, _ = 0; _ < t.length; _++) if (r == t[_].identifier) {
                            u = !0;
                            break;
                        }
                        u || (r = -1);
                    }
                    if (-1 !== r) return void c(e);
                    var a = Date.now();
                    if (a - n < 500 && i && i.id === e.currentTarget.id) return void c(e);
                    n = a, i = e.currentTarget, r = t[0].identifier, t[0].clientX || t[0].screenX, o = t[0].clientY || t[0].screenY;
                } else if ("touchmove" == e.type) {
                    if (!((s = e.changedTouches) && s[0] && r == s[0].identifier && i && i.id === e.currentTarget.id)) return void c(e);
                    var l = s[0].clientX || s[0].screenX, f = s[0].clientY || s[0].screenY;
                    !function(e, t, r) {
                        var n = e.scrollHeight - e.clientHeight, i = Math.round(e.scrollTop - r);
                        i < 0 ? i = 0 : i > n && (i = n);
                        if (i != e.scrollTop) return e.scrollTop = i, !0;
                    }(i, 0, f - o), l, o = f, c(e);
                } else if ("touchend" == e.type) {
                    var s;
                    if (!((s = e.changedTouches) && s[0] && r === s[0].identifier && i && i.id === e.currentTarget.id)) return void c(e);
                    r = -1, -1, o = -1, i = null;
                }
            });
            function c(e) {
                e && e.stopPropagation && e.stopPropagation(), e && e.preventDefault && e.preventDefault();
            }
        }));
    }
};