module.exports = {
    setApp: function(o) {
        o.__service_block__.__FRAMEWORK_PAGE_SCROLL_SERVICE_LOADED__ || (o.__service_block__.__FRAMEWORK_PAGE_SCROLL_SERVICE_LOADED__ = 1, 
        o.env.register(20011, function(e, l) {
            l.onPageScroll ? l.onPageScroll = (_ = l.onPageScroll, function(o) {
                _.call(this, o), c.call(this, o);
            }) : l.onPageScroll = c;
            var _;
            var i, r = 0;
            function c(e) {
                if (!i) {
                    var l = o.runtimeInfo || new (require("../class_define/runtime_info.js"))();
                    i = l.windowHeight;
                }
                o.env.notify(40044, {
                    scrollViewTop: e.scrollTop,
                    scrollViewBottom: e.scrollTop + i,
                    delta: e.scrollTop - r,
                    page: this,
                    pageName: this.pageName
                }), r = e.scrollTop;
            }
        }));
    }
};