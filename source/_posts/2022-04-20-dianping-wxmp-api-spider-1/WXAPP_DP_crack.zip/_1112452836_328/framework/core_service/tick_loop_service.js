module.exports = {
    setApp: function(e) {
        var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 10;
        if (!e.__service_block__.__FRAMEWORK_TICK_LOOP_SERVICE_LOADED__) {
            e.__service_block__.__FRAMEWORK_TICK_LOOP_SERVICE_LOADED__ = 1;
            var a = 0, t = Date.now(), i = 0;
            setInterval(function() {
                var r = Date.now();
                e.env.notify(21007, {
                    localTime: r,
                    serverTime: r + i,
                    tick: a++,
                    delta: r - t
                }), t = r;
            }, 1e3 / (r || 10)), e.env.register(31103, function(e, r) {
                if (r.socketJsonData.serverTime) {
                    var a = r.socketJsonData.serverTime;
                    a < 2545634624 && (a *= 1e3), s({
                        serverTime: a
                    });
                }
            }), e.env.register(30005, function(e, r) {
                if (r.serverData && r.serverData.data && r.serverData.data.serverTime) {
                    var a = r.serverData.data.serverTime;
                    a < 2545634624 && (a *= 1e3), s({
                        serverTime: a
                    });
                }
            });
        }
        function s(e) {
            var r = e.serverTime, a = e.ping, t = r + (void 0 === a ? 50 : a) - Date.now();
            Math.abs(t - i) >= 100 && (i = t);
        }
    }
};