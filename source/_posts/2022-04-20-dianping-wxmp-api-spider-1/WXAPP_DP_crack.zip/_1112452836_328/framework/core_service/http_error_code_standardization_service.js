module.exports = {
    setApp: function(e) {
        function _(e, _) {
            if (30006 === e) _.errorCode = 1e3; else if (_.serverData) {
                var r = _.serverData.statusCode;
                r >= 400 && r < 500 ? (_.errorCode = 1400, 405 === r ? _.errorCode = -1405 : 426 === r && (_.errorCode = 5003)) : _.errorCode = r >= 500 && r < 700 ? 1406 : 200 === r || 0 === r ? "Host Not Found " === _.serverData.data ? 1002 : 0 : -1;
            } else _.errorCode = -1;
        }
        !e.__service_block__.IS_SSR_BLOCKING && e.__service_block__.__FRAMEWORK_HTTP_ERROR_CODE_STARDARD_LOADED__ || (e.__service_block__.__FRAMEWORK_HTTP_ERROR_CODE_STARDARD_LOADED__ = 1, 
        e.env.register(30005, _), e.env.register(30006, _));
    }
};