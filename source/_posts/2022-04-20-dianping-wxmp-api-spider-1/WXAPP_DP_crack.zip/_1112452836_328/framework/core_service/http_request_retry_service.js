module.exports = {
    setApp: function(r) {
        if (!r.__service_block__.__FRAMEWORK_REQUESR_RETRY_SERVICE_LOADED__) {
            r.__service_block__.__FRAMEWORK_REQUESR_RETRY_SERVICE_LOADED__ = 1;
            var t = !1, e = [];
            r.env.register(30005, o), r.env.register(30006, o);
        }
        function o(o, n) {
            if (void 0 !== n.errorCode) {
                var f, s = n.task;
                if (0 === n.errorCode) s.taskInfo.retryInfo && s.taskInfo.retryInfo.callback && (s.callback = s.taskInfo.retryInfo.callback); else if (s.retryMax) {
                    var I = (f = n.errorCode || 0, 100 * Math.floor(Math.abs(f) / 100));
                    if (15e3 === I || 5e3 === I) return;
                    if (s.taskInfo.retryInfo || (s.taskInfo.retryInfo = {}, s.taskInfo.retryInfo.retry = 0, 
                    s.taskInfo.retryInfo.history = [], s.taskInfo.retryInfo.callback = s.callback, s.taskInfo.retryInfo.protocol = s.protocol, 
                    s.taskInfo.retryInfo.url = s.url), s.callback = null, s.taskInfo.retryInfo.history.push({
                        errorCode: n.errorCode,
                        requestId: s.taskInfo.requestId,
                        serverData: n.serverData,
                        timestamp: Date.now()
                    }), s.taskInfo.retryInfo.retry++, s.taskInfo.retryInfo.retry > s.retryMax) s.callback = s.taskInfo.retryInfo.callback, 
                    s.taskInfo.retryInfo.callback = null; else {
                        var l = s.retryDelay || (30006 === o ? 500 : 100);
                        s.taskInfo.retryInfo.nextRetry = Date.now() + l, function(o) {
                            o.priority -= .5 / Math.max(o.retryMax, 1), o.data || (o.data = {});
                            o.data.retry = o.taskInfo.retryInfo.retry, e.push(o), !t && e.length && (t = !0, 
                            r.env.register(21007, a));
                        }(s);
                    }
                }
            }
        }
        function a() {
            if (e.length) for (var o = Date.now(), n = 0; n < e.length; ) {
                var f = e[n];
                o >= f.taskInfo.retryInfo.nextRetry ? (e.splice(n, 1), f.url = f.taskInfo.retryInfo.url, 
                f.protocol = f.taskInfo.retryInfo.protocol, f.callback = f.taskInfo.retryInfo.callback, 
                r.env.notify(30001, f)) : n++;
            } else t && (t = !1, r.env.unregister(21007, a));
        }
    }
};