var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/helpers/defineProperty")), r = e(require("../../@babel/runtime/helpers/classCallCheck")), n = e(require("../../@babel/runtime/helpers/createClass"));

function i(e, t) {
    var r = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(e);
        t && (n = n.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
        })), r.push.apply(r, n);
    }
    return r;
}

var o = function() {
    function e(n) {
        (0, r.default)(this, e), this.$options = function(e) {
            for (var r = 1; r < arguments.length; r++) {
                var n = null != arguments[r] ? arguments[r] : {};
                r % 2 ? i(Object(n), !0).forEach(function(r) {
                    (0, t.default)(e, r, n[r]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach(function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                });
            }
            return e;
        }({
            context: null,
            selector: null,
            onEach: function(e) {
                return e.dataset;
            },
            relativeTo: null,
            threshold: .5,
            delay: 200,
            observeAll: !1,
            initialRatio: 0
        }, n), this.$observer = null;
    }
    return (0, n.default)(e, [ {
        key: "connect",
        value: function() {
            return this.$observer || (this.$observer = this._createObserver()), this;
        }
    }, {
        key: "reconnect",
        value: function() {
            this.disconnect(), this.connect();
        }
    }, {
        key: "disconnect",
        value: function() {
            if (this.$observer) {
                var e = this.$observer;
                e.$timer && clearTimeout(e.$timer), e.disconnect(), this.$observer = null;
            }
        }
    }, {
        key: "_createObserver",
        value: function() {
            var e = this.$options, t = {
                thresholds: [ e.threshold ],
                observeAll: e.observeAll,
                initialRatio: e.initialRatio
            }, r = e.context ? e.context.createIntersectionObserver(t) : wx.createIntersectionObserver(null, t);
            e.relativeTo ? r.relativeTo(e.relativeTo) : r.relativeToViewport();
            var n = [], i = !1;
            return r.observe(e.selector, function(t) {
                if (t.intersectionRatio >= e.threshold) {
                    var r = e.onEach(t);
                    n.push(r), i || (i = !0, setTimeout(function() {
                        if (n) {
                            for (var t = 0; t < n.length; t++) n[t] && n[t].identity && e.onElemView.call(null, n[t].identity, n[t].lxdata);
                            n = [], i = !1;
                        }
                    }, e.delay));
                }
            }), r;
        }
    } ]), e;
}();

module.exports = o;