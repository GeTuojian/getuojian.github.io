module.exports = function(n) {
    var o, t = App, i = require("../../framework/utils/target_compile_platform.js").IS_WXMP;
    function e(n) {
        i && n.query && delete n.query[""], this.env.notify(20019, n);
    }
    function r(n) {
        this.env && (n.query || (n.query = {}), this.env.notify(10001, {
            options: n
        }));
    }
    function c() {
        this.env.notify(10002);
    }
    function u(n) {
        this.env && this.env.notify(10003, {
            error: n
        });
    }
    function s(n) {
        this.env.notify(10005, {
            error: n
        });
    }
    n.onShow ? n.onShow = (o = n.onShow, function(n) {
        r.call(this, n), o.call(this, n);
    }) : n.onShow = r, n.onHide ? n.onHide = function(n) {
        return function() {
            c.call(this), n.call(this);
        };
    }(n.onHide) : n.onHide = c, n.onLaunch = function(n) {
        return function(o) {
            this.__service_block__ = {}, this.env || (this.env = new (require("../../framework/class_define/app_env.js"))("APP_BASE")), 
            o && ("function" == typeof n && n.call(this, o), this.env.notify(1e4, {
                options: o,
                app: this
            }));
        };
    }(n.onLaunch), n.onError ? n.onError = function(n) {
        return function(o) {
            u.call(this, o), n.call(this, o);
        };
    }(n.onError) : n.onError = u, n.onPageNotFound ? n.onPageNotFound = function(n) {
        return function(o) {
            e.call(this, o), n.call(this, o);
        };
    }(n.onPageNotFound) : n.onPageNotFound = e, n.onUnhandledRejection ? n.onUnhandledRejection = function(n) {
        return function(o) {
            s.call(this, o), n.call(this, o);
        };
    }(n.onUnhandledRejection) : n.onUnhandledRejection = s, t(n);
};