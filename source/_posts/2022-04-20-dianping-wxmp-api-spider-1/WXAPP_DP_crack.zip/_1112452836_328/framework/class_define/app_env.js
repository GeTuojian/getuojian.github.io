var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/helpers/classCallCheck")), i = e(require("../../@babel/runtime/helpers/createClass")), r = function() {
    function e() {
        (0, t.default)(this, e), this.dict = {};
    }
    return (0, i.default)(e, [ {
        key: "dispose",
        value: function() {
            this.dict = null;
        }
    }, {
        key: "notify",
        value: function(e, t, i) {
            if (e) {
                var r = this.dict[e];
                if (r) for (var l = 0; l < r.length; ) {
                    var n = r[l];
                    n && (n.func(e, t, i, r[l].refer), n === r[l] && l++);
                }
            }
        }
    }, {
        key: "register",
        value: function(e, t, i) {
            e && (this.dict[e] || (this.dict[e] = []), this.dict[e].push({
                func: t,
                refer: i
            }));
        }
    }, {
        key: "unregister",
        value: function(e, t, i) {
            if (e) {
                var r = this.dict[e];
                if (r) for (var l = r.length, n = 0; n < l; n++) if (r[n].func === t && r[n].refer === i) return r.splice(n, 1), 
                void (0 === r.length && delete this.dict[e]);
            }
        }
    } ]), e;
}(), l = function() {
    function e(i) {
        (0, t.default)(this, e), this.appName = i, this.callbackMgr = new r();
    }
    return (0, i.default)(e, [ {
        key: "notify",
        value: function(e, t, i) {
            return this.callbackMgr.notify(e, t, i);
        }
    }, {
        key: "register",
        value: function(e, t, i) {
            return this.callbackMgr.register(e, t, i);
        }
    }, {
        key: "unregister",
        value: function(e, t, i) {
            return this.callbackMgr.unregister(e, t, i);
        }
    }, {
        key: "dispose",
        value: function() {
            this.callbackMgr && (this.callbackMgr.dispose(), this.callbackMgr = null), this.appName = null;
        }
    } ]), e;
}();

l.CallbackMgr = r, module.exports = l;