var e = require("../../@babel/runtime/helpers/interopRequireDefault"), i = e(require("../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../@babel/runtime/helpers/createClass")), t = function() {
    function e(r, t) {
        (0, i.default)(this, e), this.protocol = r, this.taskInfo = null, this.priority = 2, 
        this.response = null, void 0 !== r.priority && (this.priority = r.priority), t && ("function" == typeof t.callback && (this.callback = t.callback), 
        void 0 !== t.priority && (this.priority = t.priority), void 0 !== t.retryMax && (this.retryMax = t.retryMax), 
        void 0 !== t.retryDelay && (this.retryDelay = t.retryDelay), void 0 !== t.skipPreload && (this.skipPreload = t.skipPreload), 
        void 0 !== t.preloadCacheTime && (this.preloadCacheTime = t.preloadCacheTime), void 0 !== t.domain && (this.domain = t.domain), 
        t.data && (this.data = t.data), t.header && (this.header = t.header));
    }
    return (0, r.default)(e, [ {
        key: "dispose",
        value: function() {
            this.url = null, this.callback = null, this.protocol = null, this.response = null;
        }
    } ]), e;
}();

module.exports = t;