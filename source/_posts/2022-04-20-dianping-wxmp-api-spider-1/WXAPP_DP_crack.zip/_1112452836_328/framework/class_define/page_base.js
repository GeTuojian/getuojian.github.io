module.exports = function(e) {
    var t;
    function n() {
        getApp().env.notify(20017, {
            pageName: this.pageName,
            page: this
        });
    }
    function a() {
        getApp().env.notify(20018, {
            pageName: this.pageName,
            page: this
        });
    }
    function o() {
        getApp().env.notify(20016, {
            pageName: this.pageName,
            page: this
        });
    }
    function i(e) {
        getApp().env.notify(20022, {
            pageName: this.pageName,
            item: e,
            page: this
        });
    }
    getApp().env.notify(20011, e), e.onShow ? e.onShow = (t = e.onShow, function(e) {
        n.call(this, e), t.call(this, e);
    }) : e.onShow = n, e.onHide ? e.onHide = function(e) {
        return function(t) {
            a.call(this, t), e.call(this, t);
        };
    }(e.onHide) : e.onHide = a, e.onReady ? e.onReady = function(e) {
        return function(t) {
            o.call(this, t), e.call(this, t);
        };
    }(e.onReady) : e.onReady = o, e.onLoad = function(e) {
        return function(t) {
            var n = getApp();
            n.env.notify(20014, {
                pageName: this.pageName,
                options: t,
                page: this
            });
            var a = require("../utils/storage.js"), o = a.getSessionStorageSync("_SWTICHTAB_QUERY");
            o && (a.setSessionStorageSync("_SWTICHTAB_QUERY", void 0), o.route === "/" + this.__route__ && Date.now() < o.ts + 1e3 && Object.assign(t, o.query)), 
            "function" == typeof e && e.call(this, t), n.env.notify(20015, {
                pageName: this.pageName,
                options: t,
                page: this
            });
        };
    }(e.onLoad), e.onUnload = function(e) {
        return function(t) {
            var n = getApp();
            n.env.notify(20012, {
                pageName: this.pageName,
                options: t,
                page: this
            }), "function" == typeof e && e.call(this, t), n.env.notify(20013, {
                pageName: this.pageName,
                options: t,
                page: this
            });
        };
    }(e.onUnload), e.onTabItemTap ? e.onTabItemTap = function(e) {
        return function(t) {
            i.call(this, t), e.call(this, t);
        };
    }(e.onTabItemTap) : e.onTabItemTap = i, e.setTitle = function(e) {
        wx.setNavigationBarTitle({
            title: e
        });
    }, Page(e);
};