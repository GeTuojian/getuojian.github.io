var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/helpers/typeof")), r = e(require("../../@babel/runtime/helpers/classCallCheck"));

module.exports = function e(i, a) {
    var c = this;
    for (var l in (0, r.default)(this, e), i) i.hasOwnProperty(l) && "[object Function]" !== Object.prototype.toString.call(i[l]) && (36 === l.charCodeAt(0) && (l = l.slice(1)), 
    this[l] = i[l]);
    for (var n = Object.keys(this), s = function() {
        var r = n[o];
        if (c.hasOwnProperty(r)) {
            var i = c[r];
            if ("object" === (0, t.default)(i)) {
                if (Array.isArray(i)) {
                    var a = require("./monitored_array.js");
                    c["$" + r] = new a(c[r], function(e, t, i) {
                        c[r] = t;
                    });
                }
                "[object Object]" === Object.prototype.toString.call(i) && (c["$" + r] = new e(c[r], function(e, t, i) {
                    c[r] = t;
                }));
            } else c["$" + r] = i;
            delete c[r], Object.defineProperty(c, r, {
                get: function() {
                    return this["$" + r];
                },
                set: function(t) {
                    if (this.callback) {
                        var i = new e(this, this.callback);
                        i["$" + r] = t, this.callback(this, i, "set");
                    } else this["$" + r] = t;
                }
            });
        }
    }, o = 0; o < n.length; o++) s();
    this.callback = a;
};