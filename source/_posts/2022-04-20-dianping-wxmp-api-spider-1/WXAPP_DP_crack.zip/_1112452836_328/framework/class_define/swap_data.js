var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/helpers/classCallCheck")), a = e(require("../../@babel/runtime/helpers/createClass")), i = function() {
    function e(a, i) {
        (0, t.default)(this, e), this.name = i, this.env = a;
    }
    return (0, a.default)(e, [ {
        key: "dataUpdate",
        value: function(e, t) {
            var a = "$" + e, i = {
                swapData: this,
                field: e,
                oldData: this[a],
                newData: t,
                name: this.name
            };
            this.env.notify(43001, i), this[a] = i.newData, this.env.notify(43002, i);
        }
    }, {
        key: "dispose",
        value: function() {}
    } ]), e;
}();

module.exports = i;