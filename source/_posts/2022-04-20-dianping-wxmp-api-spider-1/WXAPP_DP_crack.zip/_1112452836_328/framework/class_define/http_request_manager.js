var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/helpers/classCallCheck")), i = e(require("../../@babel/runtime/helpers/createClass"));

function r(e, t, i, r) {
    t.handled || (t.handled = 1, r.request(t), t.handled = 0);
}

var o = function() {
    function e(i) {
        (0, t.default)(this, e), this.requestId = 1, this.requestingCount = 0, this.waitingQueue = [], 
        this.env = i, this.env.register(30001, r, this);
    }
    return (0, i.default)(e, [ {
        key: "request",
        value: function(e) {
            return this.requestingCount < 8 ? this.requestSend(e) : this.requestWait(e), e;
        }
    }, {
        key: "requestWait",
        value: function(e) {
            for (var t = this.waitingQueue.length, i = 0; i < t; i++) {
                if (this.waitingQueue[i].priority > e.priority) return void this.waitingQueue.splice(i, 0, e);
            }
            this.waitingQueue.push(e);
        }
    }, {
        key: "dispose",
        value: function() {
            if (this.env && (this.env.unregister(30001, r, this), this.env = null), this.waitingQueue) {
                for (var e = 0; e < this.waitingQueue.length; e++) this.waitingQueue[e] && (this.waitingQueue[e].dispose(), 
                this.waitingQueue[e] = null);
                this.waitingQueue = null;
            }
        }
    }, {
        key: "requestSend",
        value: function(e) {
            if (e.url || (e.url = (e.domain || e.protocol.domain || "") + e.protocol.path), 
            (e.protocol.data || e.data) && (e.data = Object.assign({}, e.protocol.data, e.data)), 
            (e.protocol.header || e.header) && (e.header = Object.assign({}, e.protocol.header, e.header)), 
            void 0 === e.retryMax && e.protocol.retryMax && (e.retryMax = e.protocol.retryMax), 
            void 0 === e.retryDelay && void 0 !== e.protocol.retryDelay && (e.retryDelay = e.protocol.retryDelay), 
            void 0 === e.withCredentials && void 0 !== e.protocol.withCredentials && (e.withCredentials = e.protocol.withCredentials), 
            void 0 === e.timeout && e.protocol.timeout && (e.timeout = e.protocol.timeout), 
            e.taskInfo = e.taskInfo || {}, e.taskInfo.requestId = this.requestId++, this.env.notify(30002, e, this), 
            e.url && this.env.notify(30003, e, this), e.url) {
                var t = this;
                t.requestingCount++;
                var i = require("../../framework/utils/http_request.js").request;
                this.env.notify(30007, e, this), i({
                    url: e.url,
                    data: e.data || void 0,
                    header: e.header,
                    method: e.method || e.protocol.method || void 0,
                    dataType: e.dataType || e.protocol.dataType || void 0,
                    responseType: e.responseType || e.protocol.responseType || void 0,
                    withCredentials: e.withCredentials,
                    timeout: e.timeout || 0,
                    success: function(i) {
                        var r = {
                            task: e,
                            wxRawData: i,
                            serverData: i
                        };
                        e.response = i, t.env.notify(30008, r, t), t.env.notify(30005, r, t), "function" == typeof e.callback && e.callback(r), 
                        e.dispose && e.dispose(), t.requestingCount--, t.env.notify(30004, r, t), t.requestingCount < 8 && t.waitingQueue.length && t.requestSend(t.waitingQueue.shift());
                    },
                    fail: function(i) {
                        var r = {
                            task: e,
                            serverData: i
                        };
                        e.response = i, t.env.notify(30008, r, t), t.env.notify(30006, r, t), "function" == typeof e.callback && e.callback(r), 
                        e.dispose(), t.requestingCount--, t.env.notify(30004, r, t), t.requestingCount < 8 && t.waitingQueue.length && t.requestSend(t.waitingQueue.shift());
                    }
                });
            }
        }
    } ]), e;
}();

module.exports = o;