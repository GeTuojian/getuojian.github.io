var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/helpers/classCallCheck")), n = e(require("../../@babel/runtime/helpers/createClass")), r = null, i = null, o = function() {
    function e(n) {
        (0, t.default)(this, e), wx.getSystemInfo({
            success: function(e) {
                r || (r = e);
            }
        }), wx.getNetworkType({
            success: function(e) {
                e.networkType && (i = e.networkType);
            }
        });
    }
    return (0, n.default)(e, [ {
        key: "runtimeContainer",
        get: function() {
            return "WXMP";
        }
    }, {
        key: "wxAppVersion",
        get: function() {
            return (r || (r = wx.getSystemInfoSync())).version;
        }
    }, {
        key: "wxmpVersion",
        get: function() {
            return (r || (r = wx.getSystemInfoSync())).SDKVersion;
        }
    }, {
        key: "deviceSystem",
        get: function() {
            var e = (r || (r = wx.getSystemInfoSync())).system;
            return e.substring(0, e.indexOf(" ")).toUpperCase();
        }
    }, {
        key: "deviceSystemVersion",
        get: function() {
            var e = (r || (r = wx.getSystemInfoSync())).system;
            return e.substring(e.indexOf(" "));
        }
    }, {
        key: "deviceBrand",
        get: function() {
            return (r || (r = wx.getSystemInfoSync())).brand.toUpperCase();
        }
    }, {
        key: "deviceModel",
        get: function() {
            return (r || (r = wx.getSystemInfoSync())).model;
        }
    }, {
        key: "pixelRatio",
        get: function() {
            return (r || (r = wx.getSystemInfoSync())).pixelRatio;
        }
    }, {
        key: "screenWidth",
        get: function() {
            return (r || (r = wx.getSystemInfoSync())).screenWidth;
        }
    }, {
        key: "screenHeight",
        get: function() {
            return (r || (r = wx.getSystemInfoSync())).screenHeight;
        }
    }, {
        key: "windowWidth",
        get: function() {
            return (r || (r = wx.getSystemInfoSync())).windowWidth;
        }
    }, {
        key: "windowHeight",
        get: function() {
            return wx.getSystemInfoSync().windowHeight;
        }
    }, {
        key: "platform",
        get: function() {
            return (r || (r = wx.getSystemInfoSync())).platform;
        }
    }, {
        key: "brand",
        get: function() {
            return (r || (r = wx.getSystemInfoSync())).brand;
        }
    }, {
        key: "model",
        get: function() {
            return (r || (r = wx.getSystemInfoSync())).model;
        }
    }, {
        key: "networkType",
        get: function() {
            return i;
        }
    }, {
        key: "statusBarHeight",
        get: function() {
            return (r || (r = wx.getSystemInfoSync())).statusBarHeight;
        }
    } ]), e;
}();

module.exports = o;