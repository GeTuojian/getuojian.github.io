var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../@babel/runtime/helpers/typeof")), r = t(require("../../@babel/runtime/helpers/classCallCheck")), l = t(require("../../@babel/runtime/helpers/createClass")), a = t(require("../../@babel/runtime/helpers/assertThisInitialized")), i = t(require("../../@babel/runtime/helpers/inherits")), c = t(require("../../@babel/runtime/helpers/possibleConstructorReturn")), s = t(require("../../@babel/runtime/helpers/getPrototypeOf"));

function o(t) {
    var e = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (t) {
            return !1;
        }
    }();
    return function() {
        var r, l = (0, s.default)(t);
        if (e) {
            var a = (0, s.default)(this).constructor;
            r = Reflect.construct(l, arguments, a);
        } else r = l.apply(this, arguments);
        return (0, c.default)(this, r);
    };
}

var p = function(t) {
    (0, i.default)(s, t);
    var c = o(s);
    function s(t, l) {
        var i;
        (0, r.default)(this, s), i = c.call(this);
        for (var o = 0; o < t.length; o++) {
            var p = t[o];
            Array.prototype.push.call((0, a.default)(i), p);
        }
        for (var n = Object.keys((0, a.default)(i)), u = function() {
            var t = n[h];
            if (i.hasOwnProperty(t)) {
                var r = i[t];
                if ("object" === (0, e.default)(r)) {
                    if (Array.isArray(r) && (i["$" + t] = new s(i[t], function(e, r, l) {
                        i[t] = r;
                    })), "[object Object]" === Object.prototype.toString.call(r)) {
                        var l = require("./monitored_object.js");
                        i["$" + t] = new l(i[t], function(e, r, l) {
                            i[t] = r;
                        });
                    }
                } else i["$" + t] = r;
                delete i[t], Object.defineProperty((0, a.default)(i), t, {
                    get: function() {
                        return this["$" + t];
                    },
                    set: function(e) {
                        if (this.callback) {
                            var r = new s(this, this.callback);
                            r["$" + t] = e, this.callback(this, r, "set");
                        } else this["$" + t] = e;
                    }
                });
            }
        }, h = 0; h < n.length; h++) u();
        return i.callback = l, i;
    }
    return (0, l.default)(s, [ {
        key: "pop",
        value: function() {
            var t = Array.prototype.slice.call(this, 0), e = Array.prototype.pop.apply(this, Array.prototype.slice.call(arguments)), r = new s(this, this.callback);
            return this.length > 0 && this.callback && this.callback(t, r, "pop"), e;
        }
    }, {
        key: "copyWithin",
        value: function() {
            var t = Array.prototype.slice.call(this, 0), e = Array.prototype.copyWithin.apply(this, Array.prototype.slice.call(arguments)), r = new s(this, this.callback);
            return this.callback && this.callback(t, r, "copyWithin"), e;
        }
    }, {
        key: "fill",
        value: function() {
            var t = Array.prototype.slice.call(this, 0), e = Array.prototype.fill.apply(this, Array.prototype.slice.call(arguments)), r = new s(this, this.callback);
            return this.callback && this.callback(t, r, "fill"), e;
        }
    }, {
        key: "push",
        value: function() {
            var t = Array.prototype.slice.call(this, 0), e = Array.prototype.push.apply(this, Array.prototype.slice.call(arguments)), r = new s(this, this.callback);
            return this.callback && this.callback(t, r, "push"), e;
        }
    }, {
        key: "reverse",
        value: function() {
            var t = Array.prototype.slice.call(this, 0), e = Array.prototype.reverse.apply(this, Array.prototype.slice.call(arguments)), r = new s(this, this.callback);
            return this.length > 0 && this.callback && this.callback(t, r, "reverse"), e;
        }
    }, {
        key: "shift",
        value: function() {
            var t = Array.prototype.slice.call(this, 0), e = Array.prototype.shift.apply(this, Array.prototype.slice.call(arguments)), r = new s(this, this.callback);
            return this.callback && this.callback(t, r, "shift"), e;
        }
    }, {
        key: "splice",
        value: function() {
            var t = Array.prototype.slice.call(this, 0), e = Array.prototype.splice.apply(this, Array.prototype.slice.call(arguments)), r = new s(this, this.callback);
            return this.callback && this.callback(t, r, "splice"), e;
        }
    }, {
        key: "unshift",
        value: function() {
            var t = Array.prototype.slice.call(this, 0), e = Array.prototype.unshift.apply(this, Array.prototype.slice.call(arguments)), r = new s(this, this.callback);
            return this.callback && this.callback(t, r, "unshift"), e;
        }
    } ]), s;
}((0, t(require("../../@babel/runtime/helpers/wrapNativeSuper")).default)(Array));

module.exports = p;