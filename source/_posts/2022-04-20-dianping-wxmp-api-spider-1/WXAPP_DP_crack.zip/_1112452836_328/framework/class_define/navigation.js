var e = require("../../@babel/runtime/helpers/interopRequireDefault"), r = e(require("../../@babel/runtime/helpers/classCallCheck")), t = e(require("../../@babel/runtime/helpers/createClass")), i = function() {
    function e(t) {
        (0, r.default)(this, e), this.env = t;
    }
    return (0, t.default)(e, [ {
        key: "forwardTo",
        value: function(e) {
            var r = Object.assign({
                method: "forward"
            }, e);
            r.url && this.env.notify(34002, r), r.url && this.env.notify(34003, r), r.url && (this.env.notify(34001, r), 
            require("../../framework/utils/navigator.js").forwardTo(r));
        }
    }, {
        key: "back",
        value: function(e) {
            var r = Object.assign({
                method: "back"
            }, e);
            require("../../framework/utils/navigator.js").back(r);
        }
    }, {
        key: "redirectTo",
        value: function(e) {
            var r = Object.assign({
                method: "redirect"
            }, e);
            this.env.notify(34001, r), r.url && this.env.notify(34002, r), r.url && this.env.notify(34003, r), 
            r.url && (this.env.notify(34001, r), require("../../framework/utils/navigator.js").redirectTo(r));
        }
    } ]), e;
}();

module.exports = i;