var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/classCallCheck"));

module.exports = function t(i, s) {
    (0, e.default)(this, t), this.path = i, this.method = "GET", this.header = null, 
    this.needAccessToken = !1, this.needConfusion = !1, this.dataType = "json", this.responseType = "text", 
    this.priority = 2, this.domain = "", this.data = {}, this.withCredentials = !1, 
    this.timeout = 0, s && (s.method && (this.method = s.method), s.needAccessToken && (this.needAccessToken = s.needAccessToken), 
    s.betterAccessToken && (this.betterAccessToken = s.betterAccessToken), s.header && (this.header = s.header), 
    s.domain && (this.domain = s.domain), s.data && (this.data = s.data), void 0 !== s.withCredentials && (this.withCredentials = s.withCredentials), 
    void 0 !== s.priority && (this.priority = s.priority), s.retryMax && (this.retryMax = s.retryMax), 
    s.retryDelay && (this.retryDelay = s.retryDelay), void 0 !== s.skipPreload && (this.skipPreload = s.skipPreload), 
    void 0 !== s.preloadCacheTime && (this.preloadCacheTime = s.preloadCacheTime), void 0 !== s.timeout && (this.timeout = s.timeout), 
    s.needConfusion && (this.needConfusion = s.needConfusion)), Object.freeze ? Object.freeze(this) : Object.preventExtensions && Object.preventExtensions(this);
};