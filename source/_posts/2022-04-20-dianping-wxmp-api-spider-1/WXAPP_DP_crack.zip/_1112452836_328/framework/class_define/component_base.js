module.exports = function(o) {
    Component(o);
};