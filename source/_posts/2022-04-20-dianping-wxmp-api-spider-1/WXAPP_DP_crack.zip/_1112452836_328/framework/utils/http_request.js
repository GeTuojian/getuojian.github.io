module.exports = {
    request: wx.request
};