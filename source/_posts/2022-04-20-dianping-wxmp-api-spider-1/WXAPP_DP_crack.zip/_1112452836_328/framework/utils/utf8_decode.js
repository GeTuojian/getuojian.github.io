module.exports = function(e) {
    for (var r = "", t = 0; t < e.length; ) {
        var i, n = e[t++];
        if (0 == (128 & n)) i = n; else if (0 == (32 & n)) {
            i = n << 6 & 1984 | 63 & e[t++];
        } else if (0 == (16 & n)) {
            i = n << 12 & 61440 | e[t++] << 6 & 4032 | 63 & e[t++];
        } else {
            if (0 != (8 & n)) continue;
            i = (7 & n) << 18 | (63 & e[t++]) << 12 | (63 & e[t++]) << 6 | 63 & e[t++];
        }
        if (i >= 65535) {
            var o = i - 65536, f = 56320 + (1023 & o);
            r += "\\u" + (55296 + (o >> 10)).toString(16) + "\\u" + f.toString(16);
        } else r += String.fromCharCode(i);
    }
    return r;
};