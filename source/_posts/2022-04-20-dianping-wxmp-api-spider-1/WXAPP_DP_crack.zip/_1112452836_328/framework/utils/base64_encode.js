var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/typeof")), r = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split("");

var t = "object" === ("undefined" == typeof wx ? "undefined" : (0, e.default)(wx)) && wx.arrayBufferToBase64 ? wx.arrayBufferToBase64 : function(e) {
    if (!e) return null;
    if (!e.byteLength) return "";
    for (var t = new Uint8Array(e), n = t.length % 3, u = t.length - n, f = "", i = 0; i < u; i += 3) {
        var a = t[i], l = t[i + 1], o = t[i + 2];
        f += r[a >>> 2], f += r[((3 & a) << 4) + (l >>> 4)], f += r[((15 & l) << 2) + (o >>> 6)], 
        f += r[63 & o];
    }
    if (1 === n) {
        a = t[u];
        f += r[a >>> 2], f += r[(3 & a) << 4], f += "==";
    } else if (2 === n) {
        a = t[u], l = t[u + 1];
        f += r[a >>> 2], f += r[((3 & a) << 4) + (l >>> 4)], f += r[(15 & l) << 2], f += "=";
    }
    return f;
};

module.exports = t;