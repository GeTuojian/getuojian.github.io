var r = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/typeof"));

module.exports = function e(t) {
    var u = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1 / 0;
    if (u <= 0) return t;
    var i, n = (0, r.default)(t);
    if (null == t || "object" !== n && "function" !== n) return t;
    for (var a in i = Array.isArray(t) ? u > 1 ? t.map(function(r) {
        return e(r, u - 1);
    }) : t.slice() : {}, t) i[a] = u > 1 ? e(t[a], u - 1) : t[a];
    return i;
};