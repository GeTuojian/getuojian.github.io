var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/defineProperty"));

module.exports = function(r, t, l, a) {
    var n, i = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : null, u = arguments.length > 5 && void 0 !== arguments[5] && arguments[5], s = require("./swap_data_wrapper.js"), p = s.createSwapData(r, l, a, i, u), o = a ? Object.keys(a) : [];
    function d(r, l) {
        o && t && p && l.swapData === p && -1 !== o.indexOf(l.field) && t.setData((0, e.default)({}, l.field, l.newData));
    }
    return i && (o = o.concat(Object.keys(i))), r.register(43002, d, null), p.dispose = (n = p.dispose, 
    function() {
        r.unregister(43002, d, null), n.apply(p), p = null, t = null, o = null;
    }), p;
};