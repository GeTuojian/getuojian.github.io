var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/typeof"));

function r(e) {
    var r, t, f, a = e.length, n = 3 * a / 4;
    61 == e.charCodeAt(e.length - 2) ? n -= 2 : 61 == e.charCodeAt(e.length - 1) && (n -= 1);
    for (var u = new ArrayBuffer(n), i = new Uint8Array(u), d = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", o = 0, c = 0; c < a; c += 4) r = d.indexOf(e.charAt(c + 1)), 
    t = d.indexOf(e.charAt(c + 2)), f = d.indexOf(e.charAt(c + 3)), i[o++] = (d.indexOf(e.charAt(c)) << 2) + ((48 & r) >> 4), 
    o < n && (i[o++] = ((15 & r) << 4) + ((60 & t) >> 2)), o < n && (i[o++] = ((3 & t) << 6) + f);
    return u;
}

var t = "object" === ("undefined" == typeof wx ? "undefined" : (0, e.default)(wx)) && wx.base64ToArrayBuffer ? wx.base64ToArrayBuffer : r;

if ("object" === ("undefined" == typeof wx ? "undefined" : (0, e.default)(wx)) && wx.base64ToArrayBuffer) try {
    t("1234");
} catch (e) {
    t = r;
}

module.exports = t;