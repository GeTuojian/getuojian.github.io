var r = {
    forwardTo: function(r) {
        "miniprogram" === r.type ? wx.navigateToMiniProgram(r) : "tabbar" == r.type ? t(r) : wx.navigateTo(r);
    },
    back: function(r) {
        wx.navigateBack(r);
    },
    redirectTo: function(r) {
        "miniprogram" === r.type ? wx.navigateToMiniProgram(r) : "tabbar" == r.type ? t(r) : wx.redirectTo(r);
    }
};

function t(r) {
    var t;
    if (-1 !== (t = r.url.indexOf("?"))) {
        r.url = r.url.substring(0, t);
        var i = r.url.substring(t + 1), a = {};
        i.split("&").forEach(function(r) {
            var t = r.split("=");
            a[t[0]] = t[1] || "";
        }), require("../utils/storage.js").setSessionStorageSync("_SWTICHTAB_QUERY", {
            route: r.url,
            query: a,
            ts: Date.now()
        });
    }
    wx.switchTab(r);
}

module.exports = r;