var e = "undefined" != typeof Picasso, n = "undefined" != typeof my || "undefined" != typeof global && global.AFAppX, d = "undefined" != typeof swan, o = "undefined" != typeof global && (!!global.JsBridge && !!global.BroadcastChannel || !!global.appDestroy), f = "undefined" != typeof window && window.IS_CANVAS || "undefined" != typeof global && global.IS_CANVAS, p = !(f || e || o || n || d || "undefined" == typeof window || "undefined" != typeof swan), t = !p && "undefined" != typeof ks, i = !p && "undefined" != typeof tt, S = !p && "undefined" != typeof mmp, s = !(p || i || t || S || "undefined" == typeof wx), u = !(e || p || o || d || n || "undefined" == typeof process || process.browser), a = !(u || e || p || o || d || n || "undefined" == typeof process || "undefined" == typeof requestAnimationFrame);

module.exports = {
    IS_BROWSER: p,
    IS_WXMP: s,
    IS_TTMA: i,
    IS_SWAN: d,
    IS_ALIMP: n,
    IS_HAP: o,
    IS_NODE: u,
    IS_PICASSO: e,
    IS_CANVAS: f,
    IS_KSMP: t,
    IS_HARMONY: a,
    IS_MMP: S
};