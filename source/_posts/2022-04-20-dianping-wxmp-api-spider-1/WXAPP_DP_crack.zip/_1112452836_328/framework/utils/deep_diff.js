var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/typeof"));

module.exports = function r(t, i) {
    var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
    if (t === i) return !1;
    var u = (0, e.default)(t), a = (0, e.default)(i);
    if (u !== a) return !0;
    if ("object" === u) {
        if (Object.prototype.toString.call(t) !== Object.prototype.toString.call(i)) return !0;
        if (Object.keys(t).length !== Object.keys(i).length) return !0;
        for (var l in t) {
            if (!i.hasOwnProperty(l)) return !0;
            var o = t[l], f = i[l];
            if (o !== f && r(o, f)) return !0;
        }
        return !1;
    }
    return !(n && "number" === u && isNaN(t) && isNaN(i));
};