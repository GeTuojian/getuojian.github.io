module.exports = function() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
    return "".concat(t, "rpx");
};