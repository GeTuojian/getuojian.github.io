module.exports = {
    onLoad: function() {
        var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], t = arguments.length > 1 ? arguments[1] : void 0, a = arguments.length > 2 ? arguments[2] : void 0, e = {}, r = [];
        t.setData = function(n, a) {
            Object.assign(e, n), Object.assign(t.data, n), a && r.push(a);
        };
        var i = n.map(function(n) {
            return new n(t);
        });
        t.specWidgetInstanceArray ? (t.widgetInstanceArray = t.specWidgetInstanceArray.concat(i), 
        t.specWidgetInstanceArray = null) : t.widgetInstanceArray = i;
        var c = {};
        t.widgetInstanceArray.forEach(function(n) {
            if (n.getPrivateData) {
                var a = n.getPrivateData(t);
                return Object.assign(c, a);
            }
        }), t.setData(c), c = null, t.widgetInstanceArray.forEach(function(n) {
            n.injectPrivateFunction && n.injectPrivateFunction(t);
        }), t.widgetInstanceArray.forEach(function(n) {
            n.onPageInit && n.onPageInit(t, a);
        }), delete t.setData, r.length || (r = null), t.setData(e, r ? function() {
            r.forEach(function(n) {
                return n();
            }), r = null;
        } : null);
    },
    onUnload: function(n) {
        n.widgetInstanceArray && n.widgetInstanceArray.length && (n.widgetInstanceArray.forEach(function(t) {
            t && t.dispose && t.dispose(n);
        }), n.widgetInstanceArray = null);
    },
    forEachWidget: function(n, t) {
        n && n.widgetInstanceArray && t && n.widgetInstanceArray.forEach(t);
    }
};