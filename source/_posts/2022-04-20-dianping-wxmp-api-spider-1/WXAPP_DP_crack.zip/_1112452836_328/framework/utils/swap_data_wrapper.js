var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/typeof")), t = require("../class_define/swap_data.js"), r = require("../class_define/monitored_array.js"), n = require("../class_define/monitored_object.js");

function a(t, a) {
    var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null, o = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
    if (a) {
        var c = function(i) {
            var c = a[i];
            o && "object" === (0, e.default)(c) ? (Array.isArray(c) && (t["$" + i] = new r(c, function(e, r, n) {
                t[i] = r;
            })), "[object Object]" === Object.prototype.toString.call(c) && (t["$" + i] = new n(c, function(e, r, n) {
                t[i] = r;
            }))) : t["$" + i] = c, Object.defineProperty(t, i, {
                get: function() {
                    return this["$" + i];
                },
                set: function(e) {
                    this.dataUpdate(i, e);
                }
            });
        };
        for (var s in a) c(s);
    }
    if (i) {
        var u = Object.keys(i);
        if (!u.length) return;
        var l = require("../utils/storage.js"), f = function(a) {
            var c = l.getLocalStorageSync(t.name + "_$" + a);
            void 0 === c && (c = i[a]), o && "object" === (0, e.default)(c) ? (Array.isArray(c) && (t["$" + a] = new r(c, function(e, r, n) {
                t[a] = r;
            })), "[object Object]" === Object.prototype.toString.call(c) && (t["$" + a] = new n(c, function(e, r, n) {
                t[a] = r;
            }))) : t["$" + a] = c, Object.defineProperty(t, a, {
                get: function() {
                    return this["$" + a];
                },
                set: function(e) {
                    this.dataUpdate(a, e);
                }
            });
        };
        for (var d in i) f(d);
        var p = t.dataUpdate;
        t.dataUpdate = function(e, t) {
            var r = "$" + e;
            this[r] !== t && (p.call(this, e, t), -1 !== u.indexOf(e) && require("../../framework/utils/storage.js").setLocalStorageAsync(this.name + "_$" + e, this[r]));
        }.bind(t);
    }
}

module.exports = {
    createSwapData: function(e, r, n) {
        var i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null, o = arguments.length > 4 && void 0 !== arguments[4] && arguments[4], c = new t(e, r);
        return a(c, n, i, o), c;
    },
    monitorSwapDataFields: a
};