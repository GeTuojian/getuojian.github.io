var e = {
    sessionStorage: {},
    getLocalStorageSync: function(e) {
        try {
            return wx.getStorageSync(e);
        } catch (e) {
            return null;
        }
    },
    setLocalStorageSync: function(e, t) {
        if (void 0 !== t) return wx.setStorageSync(e, t);
        try {
            return wx.removeStorageSync(e);
        } catch (e) {
            return;
        }
    },
    getLocalStorageAsync: function(e) {
        return void 0 === e ? Promise.reject(void 0) : new Promise(function(t, o) {
            wx.getStorage({
                key: e,
                success: function(e) {
                    t(e.data);
                },
                fail: function() {
                    t();
                }
            });
        });
    },
    setLocalStorageAsync: function(e, t) {
        if (void 0 !== t) return new Promise(function(o) {
            wx.setStorage({
                key: e,
                data: t,
                success: function(e) {
                    o(e.data);
                },
                fail: function() {
                    o();
                }
            });
        });
        try {
            return wx.removeStorageSync(e), Promise.resolve({
                code: 0,
                msg: "setLocalStorageAsync ok"
            });
        } catch (e) {
            return Promise.reject({
                code: -1,
                msg: "setLocalStorageAsync fail"
            });
        }
    },
    getSessionStorageSync: function(t) {
        if (t) return e.sessionStorage[t];
    },
    setSessionStorageSync: function(t, o) {
        t && (void 0 === o ? delete e.sessionStorage[t] : e.sessionStorage[t] = o);
    }
};

module.exports = e;