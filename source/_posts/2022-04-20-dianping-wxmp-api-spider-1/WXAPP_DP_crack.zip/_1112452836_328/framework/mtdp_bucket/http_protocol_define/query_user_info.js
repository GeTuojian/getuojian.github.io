var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), r = e(require("../../../@babel/runtime/helpers/classCallCheck")), t = e(require("../../../@babel/runtime/helpers/inherits")), u = e(require("../../../@babel/runtime/helpers/possibleConstructorReturn")), n = e(require("../../../@babel/runtime/helpers/getPrototypeOf"));

function i(e) {
    var r = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var t, i = (0, n.default)(e);
        if (r) {
            var l = (0, n.default)(this).constructor;
            t = Reflect.construct(i, arguments, l);
        } else t = i.apply(this, arguments);
        return (0, u.default)(this, t);
    };
}

var l = require("../../class_define/http_protocol.js"), o = require("../../class_define/http_request_task.js"), s = new l("/wxmapi/user/userinfo", {
    method: "GET",
    needAccessToken: !0,
    retryMax: 3,
    retryDelay: 200,
    priority: 0,
    preloadCacheTime: 0,
    header: {
        token: ""
    }
}), a = function(e) {
    (0, t.default)(n, e);
    var u = i(n);
    function n(e) {
        return (0, r.default)(this, n), u.call(this, s, e);
    }
    return n;
}(o);

a.defaultProtocol = s, module.exports = a;