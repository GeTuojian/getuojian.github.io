var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../@babel/runtime/helpers/inherits")), n = e(require("../../../@babel/runtime/helpers/possibleConstructorReturn")), u = e(require("../../../@babel/runtime/helpers/getPrototypeOf"));

function i(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, i = (0, u.default)(e);
        if (t) {
            var l = (0, u.default)(this).constructor;
            r = Reflect.construct(i, arguments, l);
        } else r = i.apply(this, arguments);
        return (0, n.default)(this, r);
    };
}

var l = require("../../class_define/http_protocol.js"), o = require("../../class_define/http_request_task.js"), c = new l("/thirdlogin/ajax/auth", {
    method: "POST",
    needAccessToken: !1,
    retryMax: 1,
    priority: 0,
    header: {
        "content-type": "application/x-www-form-urlencoded",
        openidPlt: null
    },
    data: {
        sourceType: 0,
        directLogin: !0,
        cx: "!"
    },
    preloadCacheTime: 0
}), a = function(e) {
    (0, r.default)(u, e);
    var n = i(u);
    function u(e) {
        return (0, t.default)(this, u), n.call(this, c, e);
    }
    return u;
}(o);

module.exports = a;