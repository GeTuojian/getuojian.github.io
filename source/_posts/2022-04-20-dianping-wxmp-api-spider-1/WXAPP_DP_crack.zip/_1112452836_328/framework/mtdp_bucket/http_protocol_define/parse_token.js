var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../@babel/runtime/helpers/inherits")), n = e(require("../../../@babel/runtime/helpers/possibleConstructorReturn")), u = e(require("../../../@babel/runtime/helpers/getPrototypeOf"));

function o(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, o = (0, u.default)(e);
        if (t) {
            var i = (0, u.default)(this).constructor;
            r = Reflect.construct(o, arguments, i);
        } else r = o.apply(this, arguments);
        return (0, n.default)(this, r);
    };
}

var i = require("../../class_define/http_protocol.js"), l = require("../../class_define/http_request_task.js"), a = new i("/mina/api/parsetoken", {
    method: "POST",
    needAccessToken: !1,
    retryMax: 1,
    priority: 0,
    header: {
        "content-type": "application/x-www-form-urlencoded"
    },
    data: {},
    preloadCacheTime: 0
}), c = function(e) {
    (0, r.default)(u, e);
    var n = o(u);
    function u(e) {
        return (0, t.default)(this, u), n.call(this, a, e);
    }
    return u;
}(l);

c.defaultProtocol = a, module.exports = c;