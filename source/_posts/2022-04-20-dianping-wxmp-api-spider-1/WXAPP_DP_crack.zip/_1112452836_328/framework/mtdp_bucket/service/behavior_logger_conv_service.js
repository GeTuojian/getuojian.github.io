module.exports = {
    setApp: function(e, i) {
        function t(t, a) {
            var d = 37001 === t ? i.bid_c : i.bid_v;
            if (d) var n = d[a.identity];
            if (!n && a.identity && 0 !== a.identity.indexOf("mvvm@") && (n = a.identity), n) {
                var r = {
                    behaviorType: 37001 === t ? "moduleClick" : "moduleView",
                    data: Object.assign({
                        bid: n
                    }, a.data)
                };
                e.env.notify(36001, r);
            }
        }
        e.env.register(37001, t), e.env.register(37002, t), e.env.register(32004, function(t, a) {
            var d = a.pageName, n = i.cid[d], r = i.main_s;
            n || (n = d);
            if (n) {
                var o = {
                    cid: n,
                    bid: r,
                    pageName: d,
                    shareOptId: a.options.shareOptId
                };
                a.options.shareTitleId && (o.shareTitleId = a.options.shareTitleId);
                var s = {
                    behaviorType: "moduleClick",
                    data: o
                };
                e.env.notify(36001, s);
            }
        });
    }
};