module.exports = {
    setApp: function(_, r, e, t) {
        if (!_.__service_block__.__USER_CX_FINGERPRINT_SERVICE_LOADED__) {
            _.__service_block__.__USER_CX_FINGERPRINT_SERVICE_LOADED__ = 1;
            var l = require("../utils/fingerprint_adaptor.js"), n = null, u = [];
            _.env.register(30003, a), l(r, e, t)(function(r) {
                if (n !== r) {
                    "string" != typeof r && (r = ""), n = r || "", _.env.unregister(30003, a);
                    for (var e = 0; e < u.length; e++) {
                        var t = u[e];
                        t.data.cx = n, t.url = t.urlCXBack, delete t.urlCXBack, _.env.notify(30001, t), 
                        u[e] = null;
                    }
                    u = null;
                }
            });
        }
        function a(_, r) {
            r.data && r.data.hasOwnProperty("cx") && !r.data.cx && (r.urlCXBack = r.url, r.url = null, 
            u.push(r));
        }
    }
};