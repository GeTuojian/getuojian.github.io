var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), r = e(require("../../../@babel/runtime/helpers/classCallCheck")), t = e(require("../../../@babel/runtime/helpers/assertThisInitialized")), n = e(require("../../../@babel/runtime/helpers/inherits")), i = e(require("../../../@babel/runtime/helpers/possibleConstructorReturn")), s = e(require("../../../@babel/runtime/helpers/getPrototypeOf"));

function a(e) {
    var r = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var t, n = (0, s.default)(e);
        if (r) {
            var a = (0, s.default)(this).constructor;
            t = Reflect.construct(n, arguments, a);
        } else t = n.apply(this, arguments);
        return (0, i.default)(this, t);
    };
}

var u = require("../../class_define/swap_data.js"), c = require("../../utils/swap_data_wrapper.js"), p = function(e) {
    (0, n.default)(s, e);
    var i = a(s);
    function s(e, n) {
        var a;
        return (0, r.default)(this, s), n || (n = "USER_DATA_MTDP"), a = i.call(this, e, n), 
        c.monitorSwapDataFields((0, t.default)(a), {
            cxFingerprint: "",
            wxUserCity: "",
            wxUserName: "",
            latitude: "",
            longitude: "",
            dpAccessTokenVerified: ""
        }, {
            dpAccessToken: "",
            dperAccessToken: "",
            mtAccessToken: "",
            dpUserId: "",
            dpDpId: "",
            dpUserNickName: "",
            dpUserAvatarUrl: "",
            wxmpEncryptedOpenId: "",
            wxmpOpenId: "",
            wxmpEncryptedUnionId: "",
            swanpEncryptedOpenId: "",
            swanOpenId: "",
            swanEncryptedUnionId: "",
            localSource: "",
            oaId: "",
            dpId: "",
            dpCityId: "",
            dpCityName: "",
            dpIsOverseasCity: "",
            dpLocCityId: "",
            dpLocCityName: "",
            dpLocIsOverseasCity: "",
            userid: ""
        }, !1), a;
    }
    return s;
}(u);

module.exports = p;