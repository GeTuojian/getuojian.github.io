module.exports = {
    setApp: function(e, r, t, n, o, i) {
        if (!e.__service_block__.__FRAMEWORK_STATICTIS_LOGGER_CAT_IMPLEMENT_LOADED__) {
            e.__service_block__.__FRAMEWORK_STATICTIS_LOGGER_CAT_IMPLEMENT_LOADED__ = 1;
            var a = require("../utils/owl_adaptor.js");
            e.owl = {
                addPoint: a.addPoint,
                reportSpeed: a.reportSpeed,
                addFirstContentfulPaint: a.addFirstContentfulPaint,
                createFirstContentfulPaint: a.createFirstContentfulPaint
            };
            var c, s = function() {};
            a && (o || (o = {
                project: n,
                devMode: "production" !== r,
                wxAppVersion: t || "0.0.0",
                ajax: {
                    flag: !0,
                    duration: 2e3
                },
                image: {
                    flag: !0,
                    fileSize: 100,
                    duration: 5e3
                }
            }), a.start(o), require("../../utils/http_request.js").request = function(e) {
                e.isRequest = !0, a.request(e);
            }, e.env.register(1e4, function() {
                a.appLaunch();
            }), e.env.register(10003, function(e, r) {
                a.appError(r.error);
            }), e.env.register(10002, function() {
                a.reportAll();
            }), e.env.register(10001, function() {
                a.reportPv && a.reportPv();
            }), e.env.register(20014, function() {
                a.pageLoad();
            }), e.env.register(20016, function() {
                a.pageReady();
            }), e.env.register(20018, function() {
                a.reportSpeed();
            }), e.env.register(20013, function() {
                a.reportSpeed();
            }), e.env.register(35001, function(e, r, t, n) {
                r.content && ("error" !== r.level && "warn" !== r.level || (r.sec_category = r.reason, 
                l(Object.assign({
                    content: "cat logger",
                    category: "jsError",
                    level: "info"
                }, r))));
                "pageNotFound" === r.reason && onCatReport();
            }), e.env.register(30006, function(e, r, t, n) {
                l({
                    content: r,
                    category: "ajaxError",
                    sec_category: "httpFail",
                    level: "error"
                });
            }), e.env.register(31104, function(e, r, t, n) {
                l({
                    content: r,
                    category: "ajaxError",
                    sec_category: "webSocketFail",
                    level: "error"
                });
            }), e.env.register(43002, function(r, t) {
                t.swapData === e.userData && "wxmpEncryptedOpenId" === t.field && a.setUnionId(e.userData.wxmpEncryptedOpenId);
            }), i && a.setUnionId(i));
        }
        function u() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            !c || e.success || e.fail || clearTimeout(c), c = setTimeout(function() {
                a.reportError(e.success || s, e.fail || s), c = null;
            }, 200);
        }
        function l() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            try {
                e = Object.assign({
                    content: "",
                    category: "ajaxError",
                    sec_category: "",
                    level: "error"
                }, e), a.pushError(e), r.isReport && u(r);
            } catch (e) {
                a.pushError({
                    content: e,
                    category: "jsError",
                    level: "error",
                    sec_category: "catLogger error"
                });
            }
        }
    }
};