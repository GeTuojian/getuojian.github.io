module.exports = {
    setApp: function(e, _, r, o, n, s) {
        if (!e.__service_block__.__FRAMEWORK_LOGAN_LOGGER_IMPLEMENT__) {
            e.__service_block__.__FRAMEWORK_LOGAN_LOGGER_IMPLEMENT__ = 1;
            var t = require("../utils/logan_adaptor.js");
            e.env.register(35001, function(e, _) {
                switch (_.level) {
                  case "log":
                    t.log(_.reason, _.content);

                  case "warn":
                    t.warn(_.reason, _.content);

                  case "error":
                    t.error(_.reason, _.content);
                }
            });
        }
    }
};