module.exports = {
    setApp: function(e, r, n) {
        if (!e.__service_block__.__FRAMEWORK_PERF_IMPLEMENT_LOADED__) {
            e.__service_block__.__FRAMEWORK_PERF_IMPLEMENT_LOADED__ = 1;
            var t = require("../utils/perf_adaptor.js"), i = t.app, o = t.page, a = {
                token: n,
                version: r
            }, s = [];
            if (t.init(a), t && t.perf && t.perf.core && t.perf.core.__config && t.perf.core.__config.fst && (t.perf.core.__config.fst.include = {
                has: function(e) {
                    return -1 !== s.indexOf(e);
                }
            }), e.env.register(20011, function(e, r) {
                r.perfOpts && r.perfOpts.enableFst && s.push(r.perfOpts.enableFst);
            }), t.request) {
                var c = require("../../utils/http_request.js"), f = c.request;
                c.request = function(e) {
                    t.request(e, f);
                };
            }
            e.env.register(1e4, function(e, r) {
                var n = r.options, t = void 0 === n ? {} : n;
                i.onLaunch(t);
            }), e.env.register(10003, function(e, r) {
                var n = r.error, t = void 0 === n ? {} : n;
                i.onError(t);
            }), e.env.register(10002, function() {
                i.onHide();
            }), e.env.register(10005, function(e, r) {
                var n = r.error, t = void 0 === n ? {} : n;
                i.onUnhandledRejection(t);
            }), e.env.register(20017, function(e, r) {
                var n = r.page;
                o.onShow.call(n);
            }), e.env.register(20014, function(e, r) {
                var n = r.options, t = void 0 === n ? {} : n, i = r.page;
                [ "perfFMP", "perfRewritePageName", "perfSetData", "perfStartPoint", "startMetricsPoint", "metricsFMP", "metricsSetData" ].forEach(function(e) {
                    o[e] && (i[e] = o[e].bind(i));
                }), o.onLoad.call(i, t);
            }), e.env.register(20016, function(e, r) {
                var n = r.page;
                o.onReady.call(n);
            }), e.env.register(20018, function(e, r) {
                var n = r.page;
                o.onHide.call(n);
            }), e.env.register(20013, function(e, r) {
                var n = r.page;
                o.onUnload.call(n);
            }), e.env.register(20022, function(e, r) {
                var n = r.page, t = r.item, i = void 0 === t ? {} : t;
                o.onTabItemTap.call(n, i);
            });
        }
    }
};