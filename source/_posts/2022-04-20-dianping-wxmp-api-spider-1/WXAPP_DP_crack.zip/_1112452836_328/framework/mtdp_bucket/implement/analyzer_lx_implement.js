module.exports = {
    setApp: function(e, a, t, i) {
        if (!e.__service_block__.__FRAMEWORK_ANALYZER_LX_IMPLEMENT_LOADED__) {
            e.__service_block__.__FRAMEWORK_ANALYZER_LX_IMPLEMENT_LOADED__ = 1;
            var r = require("../utils/lx_adaptor.js");
            r.init({
                appnm: a,
                utm_source: i || a,
                app: t
            });
            var s = null;
            !function() {
                var a = e.userData.wxmpEncryptedOpenId, t = e.userData.dpCityId;
                a && r.set("wxid", a);
                t && r.set("cityid", t);
                e.userData.latitude && e.userData.longitude && r.resetGeolocation(e.userData.longitude, e.userData.latitude);
            }();
            try {
                s = wx.getLaunchOptionsSync();
            } catch (e) {
                s = {};
            }
            r.setUTM(s), e.env.register(10001, n), e.env.register(10002, n), e.env.register(20013, n), 
            e.env.register(20018, n), e.env.register(36001, u), e.env.register(35001, function(e, a) {
                if ("PAGE_SHOW" === a.reason) {
                    u(36001, {
                        behaviorType: "pageView",
                        data: {
                            pageName: a.content,
                            cid: "!"
                        }
                    });
                }
            }), e.env.register(43002, function(a, t) {
                t.swapData === e.userData && "wxmpEncryptedOpenId" === t.field ? r.set("wxid", e.userData.wxmpEncryptedOpenId) : t.swapData === e.userData && "userid" === t.field ? r.set("uid", e.userData.userid || e.userData.dpUserId) : t.swapData === e.userData && "wxmpEncryptedUnionId" === t.field ? r.set("wxunionid", e.userData.wxmpEncryptedUnionId) : t.swapData === e.userData && "longitude" === t.field ? r.resetGeolocation(e.userData.longitude, e.userData.latitude) : t.swapData === e.userData && "dpCityId" === t.field && r.set("cityid", e.userData.dpCityId);
            });
            var d = Date.now();
        }
        function n(e, a) {
            switch (e) {
              case 10001:
                d = Date.now();
                r.setUTM(s, {
                    39: "wechat_search",
                    75: "enjoy_search",
                    76: "beauty_seatch"
                });
                try {
                    var t = require("../../../dpmapp/utils/scene.js");
                    if (s && s.query && s.query.scene) {
                        var i = t.parse(s.query.scene);
                        r.setUTM({
                            query: i
                        });
                    }
                } catch (e) {}
                var n = s && s.query && s.query.lch || "";
                n && r.setLch(n), r.startApp();
                break;

              case 10002:
                r.quitApp();
                break;

              case 20018:
                var u = Date.now() - d;
                r.pageDisappear({
                    duration: u
                });
                break;

              case 20013:
                r.pageDisappear();
            }
        }
        function u(a, t) {
            if (t && t.data && (t.data.bid || t.data.cid)) {
                t.lx = r;
                var i = t.behaviorType;
                if (e.env.notify(36002, t), "moduleView" === i || "moduleClick" === i || "moduleEdit" === i) {
                    var s = t.data.bid;
                    delete t.data.bid, t.bid = s, r[i](s, t.data, t.option);
                } else if ("pageView" === i) {
                    var d = t.data.cid;
                    delete t.data.cid, t.cid = d, r.pageView(d, t.data, t.option);
                }
                e.env.notify(36003, t);
            }
        }
    }
};