var e, a = require("../../../framework/class_define/http_protocol.js"), t = require("../../../framework/class_define/http_request_task.js");

function p() {
    return e && e.userData && !!e.userData.wxmpEncryptedOpenId && !!e.userData.wxmpOpenId;
}

function n() {
    if (e && e.userData && e.userData.wxmpEncryptedOpenId && e.userData.wxmpOpenId) return [ {
        key: "openid",
        value: e.userData.wxmpEncryptedOpenId
    }, {
        key: "openidPlt",
        value: e.userData.wxmpOpenId
    } ];
}

var r = null;

function d(e) {
    try {
        wx.login({
            success: function(p) {
                var n = p.code;
                getApp().h.request(new t(new a("/mina/api/user/openid", {
                    method: "GET",
                    data: {
                        code: n,
                        appId: e.wxmpAppId
                    },
                    header: {
                        openidPlt: ""
                    }
                }), {
                    callback: function(e) {
                        var a = e && e.serverData && e.serverData.data;
                        a && 200 == a.code && a.openId && a.openIdPlt && (getApp().userData.wxmpEncryptedOpenId = a.openId, 
                        getApp().userData.wxmpOpenId = a.openIdPlt);
                    }
                }));
            },
            fail: function(e) {}
        });
    } catch (e) {}
}

function u(a, t) {
    var p, n = t.swapData, d = t.newData, u = t.field;
    "wxmpEncryptedOpenId" !== u && "wxmpOpenId" !== u || n !== e.userData || d && getApp().userData.wxmpEncryptedOpenId && e.userData.wxmpOpenId && (p = [ {
        key: "openid",
        value: e.userData.wxmpEncryptedOpenId
    }, {
        key: "openidPlt",
        value: e.userData.wxmpOpenId
    } ], r && r.length && (r.forEach(function(e) {
        e(p);
    }), r = null));
}

module.exports = {
    setApp: function(a, t) {
        e || (e = a, a.env.register(43002, u), a.userData.wxmpEncryptedOpenId && a.userData.wxmpOpenId || (r = [], 
        d(t)));
    },
    isDataPrepared: p,
    getDataSync: n,
    getDataAsync: function(e, a) {
        p() ? e(n()) : r ? r.push(e) : (r = e ? [ e ] : [], d(a));
    }
};