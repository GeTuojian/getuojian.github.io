var t, n, r, e, a;

function u() {
    return t && t.userData && !!t.userData.cxFingerprint || a;
}

function i() {
    return t && t.userData && t.userData.cxFingerprint ? t.userData.cxFingerprint : "";
}

var c = null;

module.exports = {
    setApp: function(a, u) {
        t || (n = u && u.cxAppId, r = u && u.wxmpEncryptedOpenId, e = u && u.wxmpEncryptedUnionId, 
        t = a);
    },
    isDataPrepared: u,
    getDataSync: i,
    getDataAsync: function(p) {
        u() ? p(i()) : c ? c.push(p) : (c = p ? [ p ] : [], require("../../../framework/mtdp_bucket/utils/fingerprint_adaptor.js")(n, e, r)(function(n, r) {
            n && r && (t.userData.jsguardInstance = n, t.userData.cxFingerprint = r), a = 1, 
            c && c.length && (c.forEach(function(t) {
                t && t(i());
            }), c = null);
        }));
    }
};