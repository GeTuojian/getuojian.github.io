var t;

function e() {
    return t && t.userData && !!t.userData.latitude && !!t.userData.longitude;
}

function a() {
    return t && t.userData && t.userData.latitude && t.userData.longitude ? [ {
        key: "latitude",
        value: t.userData.latitude
    }, {
        key: "longitude",
        value: t.userData.longitude
    } ] : null;
}

var u = null;

module.exports = {
    setApp: function(e) {
        t || (t = e);
    },
    isDataPrepared: e,
    getDataSync: a,
    getDataAsync: function(n) {
        if (e()) n(a()); else if (u) u.push(n); else {
            var l = function() {
                u && u.length && (u.forEach(function(t) {
                    t && t(a());
                }), u = null);
            };
            u = n ? [ n ] : [], wx.getLocation({
                type: "wgs84",
                success: function(e) {
                    t.userData.latitude = e.latitude, t.userData.longitude = e.longitude, l();
                },
                fail: function(e) {
                    t.userData.latitude = "", t.userData.longitude = "", console.error("定位坐标获取异常：%o", e), 
                    l();
                },
                complete: function(e) {
                    e && e.latitude && e.longitude || (t.userData.latitude = "", t.userData.longitude = "", 
                    console.error("定位坐标获取异常"), l());
                }
            });
        }
    }
};