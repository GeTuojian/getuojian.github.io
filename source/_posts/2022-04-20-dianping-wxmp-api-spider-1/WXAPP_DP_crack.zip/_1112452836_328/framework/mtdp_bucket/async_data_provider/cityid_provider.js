var a, e = require("./loc_cityid_provider.js"), t = 2, s = "北京", r = 2;

function i() {
    return a && a.userData && !!a.userData.dpCityId && !!a.userData.dpCityName && !!a.userData.dpIsOverseasCity;
}

function u() {
    return a && a.userData && a.userData.dpCityId && a.userData.dpCityName && a.userData.dpIsOverseasCity ? [ {
        key: "cityId",
        value: a.userData.dpCityId
    }, {
        key: "cityName",
        value: a.userData.dpCityName
    }, {
        key: "isOverseasCity",
        value: a.userData.dpIsOverseasCity
    } ] : null;
}

var y = null;

function d(e, t, s) {
    e && t && s && (a.userData.dpCityId = e, a.userData.dpCityName = t, a.userData.dpIsOverseasCity = s, 
    a.env.notify(60001, {
        dpCityId: e,
        dpCityName: t,
        dpIsOverseasCity: s
    }));
}

module.exports = {
    setApp: function(e) {
        a || (a = e);
    },
    getDataSync: u,
    getDataAsync: function(n) {
        if (i()) n(u()); else if (y) y.push(n); else {
            y = n ? [ n ] : [], e.getDataAsync(function() {
                var e = a.userData.dpLocCityId, i = a.userData.dpLocCityName, n = a.userData.dpLocIsOverseasCity;
                e && i && n ? d(e, i, n) : d(t, s, r), y && y.length && (y.forEach(function(a) {
                    a && a(u());
                }), y = null);
            });
        }
    },
    isDataPrepared: i,
    setDataSync: d
};