var e, n = require("../../../dpmapp/config/app_config.js"), a = require("../../../framework/mtdp_bucket/async_data_provider/userid_provider.js");

function t() {
    return e && e.userData && !!e.userData.dpAccessToken;
}

function r() {
    return e && e.userData && e.userData.dpAccessToken ? e.userData.dpAccessToken : null;
}

var s = null;

function o(a, t, r) {
    try {
        var s = require("../../../framework/mtdp_bucket/http_protocol_define/apply_wx_third_login.js");
        wx.login({
            success: function(o) {
                if (o.code) {
                    var c = new s({
                        domain: n.DOMAIN,
                        data: {
                            code: o.code
                        },
                        callback: function(n) {
                            var s = n.serverData;
                            if (s && 200 === s.statusCode) {
                                var o = s.data;
                                o && o.msg && o.msg.eod && (e.userData.wxmpEncryptedOpenId = o.msg.eod, e.userData.wxmpOpenId = o.msg.openidPlt, 
                                e.userData.wxmpEncryptedUnionId = o.msg.eud), o.msg && o.msg.token && (e.userData.dpAccessToken = o.msg.token), 
                                a && r && r(null, "静默登陆失败!");
                            }
                            s && s.data && s.data.msg && s.data.msg.token || a || e.env.notify(38001, {
                                reason: t
                            });
                        }
                    });
                    e.h.request(c);
                }
            },
            fail: function() {
                a || e.env.notify(38001, {
                    reason: t
                });
            }
        });
    } catch (n) {
        a || e.env.notify(38001, {
            reason: t
        });
    }
}

module.exports = {
    setApp: function(n) {
        e || (e = n, n.env.register(30005, function(e, a) {
            a.task && a.task.protocol && a.task.protocol.needAccessToken && a.serverData && 400 === a.serverData.data.code && (n.userData.dpAccessToken = null, 
            o(!1, "network_token_error"));
        }), e.userData && (e.userData.dpAccessToken = ""), o(!0, "app_start_sync"), n.env.register(43002, function(e, t) {
            var r = t.swapData, o = t.newData;
            if ("dpAccessToken" === t.field && r === n.userData && o) {
                var c = getCurrentPages(), u = c[c.length - 1];
                if (u && "login" === u.pageName) {
                    var i = function(e, a) {
                        "login" === a.pageName && (n.env.unregister(e, i), i = null, n.userData.dpAccessToken && d());
                    };
                    n.env.register(20013, i);
                } else d();
                a.getDataAsync(function() {});
            }
            function d() {
                s && s.length && (s.forEach(function(e) {
                    e && e(o);
                }), s = null);
            }
        }), n.env.register(38002, function(e, a) {
            n.userData.dpAccessToken || s && s.length && (s.forEach(function(e) {
                e && e(null);
            }), s = null);
        }));
    },
    isDataPrepared: t,
    getDataSync: r,
    getDataAsync: function(e, n) {
        t() ? e(r()) : n ? o(n, "silentMode", e) : s ? s.push(e) : (s = e ? [ e ] : [], 
        o(n, "token_provider_require"));
    }
};