var t, e = require("../../../framework/class_define/http_protocol.js"), a = require("../../../framework/class_define/http_request_task.js"), s = require("./lbs_provider.js");

function r() {
    return t && t.userData && !!t.userData.dpLocCityId && !!t.userData.dpLocCityName && !!t.userData.dpLocIsOverseasCity;
}

function i() {
    return t && t.userData && t.userData.dpLocCityId && t.userData.dpLocCityName && t.userData.dpLocIsOverseasCity ? [ {
        key: "locCityId",
        value: t.userData.dpLocCityId
    }, {
        key: "locCityName",
        value: t.userData.dpLocCityName
    }, {
        key: "locIsOverseasCity",
        value: t.userData.dpLocIsOverseasCity
    } ] : null;
}

var c = null;

function o() {
    c && c.length && (c.forEach(function(t) {
        t && t(i());
    }), c = null);
}

function n() {
    s.getDataAsync(function() {
        var s = t.userData.latitude, r = t.userData.longitude;
        s && r ? getApp().h.request(new a(new e("/wxmapi/city/locatecity", {
            domain: "https://m.dianping.com",
            method: "GET",
            data: {
                lat: s,
                lng: r
            }
        }), {
            callback: function(e) {
                var a = e && e.serverData && e.serverData.data;
                a && 200 == a.code && a.cityInfo ? (t.userData.dpLocCityId = a.cityInfo && a.cityInfo.cityId, 
                t.userData.dpLocCityName = a.cityInfo && a.cityInfo.cityName, t.userData.dpLocIsOverseasCity = a.cityInfo && a.cityInfo.isOverseasCity ? 1 : 2, 
                o()) : (o(), console.error("定位城市获取异常：%o", e));
            }
        })) : (wx.getSetting({
            success: function(t) {
                t.authSetting["scope.userLocation"];
            }
        }), o());
    });
}

module.exports = {
    setApp: function(e) {
        t || (t = e, n());
    },
    getDataSync: i,
    getDataAsync: function(t) {
        r() ? t(i()) : c ? c.push(t) : (c = t ? [ t ] : [], n());
    },
    isDataPrepared: r
};