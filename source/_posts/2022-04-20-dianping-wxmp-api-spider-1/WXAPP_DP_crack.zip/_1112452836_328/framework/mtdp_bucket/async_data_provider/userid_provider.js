var e, a = require("../../../framework/class_define/http_protocol.js"), t = require("../../../framework/class_define/http_request_task.js");

function r() {
    return e && e.userData && !!e.userData.userid;
}

function s() {
    return e && e.userData && e.userData.userid ? e.userData.userid : null;
}

var n = null;

module.exports = {
    setApp: function(a) {
        e || (e = a);
    },
    getDataSync: s,
    getDataAsync: function(u, i) {
        if (r()) u(s()); else if (n) n.push(u); else {
            var o = function() {
                n && n.length && (n.forEach(function(e) {
                    e && e(s());
                }), n = null);
            };
            n = u ? [ u ] : [], (i || getApp() || {}).h.request(new t(new a("/mina/api/parsetoken", {
                domain: "https://m.dianping.com",
                method: "GET"
            }), {
                data: {
                    token: "!"
                },
                callback: function(a) {
                    var t = a && a.serverData && a.serverData.data;
                    t && 200 == t.code && t.userId ? (e.userData.userid = t.userId, o()) : (502 == t.code && e.userData.dpAccessToken, 
                    e.userData.dpAccessToken = "", o());
                }.bind(this)
            }));
        }
    },
    isDataPrepared: r
};