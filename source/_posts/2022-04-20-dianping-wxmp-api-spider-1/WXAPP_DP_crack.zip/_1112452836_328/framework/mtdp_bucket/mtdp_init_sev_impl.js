module.exports = function(e, r, t, p, i, m, s, _, n, l, c) {
    if (require("./implement/logan_logger_implement.js").setApp(e), r && require("./service/user_cx_fingerprint_service.js").setApp(e, r, n, l), 
    t && (require("./service/behavior_logger_conv_service.js").setApp(e, p), require("../../framework/mtdp_bucket/implement/analyzer_lx_implement.js").setApp(e, t, _ || "0.0.0", t)), 
    i && (s || (s = "production"), require("../../framework/mtdp_bucket/implement/statictis_logger_cat_implement.js").setApp(e, s, _, i, m, n)), 
    s && _) {
        var o = require("../../framework/mtdp_bucket/implement/perf_mp_implement.js");
        o && o.setApp(e, _, c);
    }
};