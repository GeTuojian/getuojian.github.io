module.exports = function(e, p, o, _, t, n, r) {
    require("../../framework/mtdp_bucket/mtdp_init_sev_impl.js")(e, o.cx_appId, _.lx_appName, _.lxId, t.owl_appName, t.owl_startConfig, t.owl_env, t.owl_version, p.wxUnionId, p.wxmpOpenId, n.perf_token);
    var a = require("../../framework/mtdp_bucket/mtdp_init_other.js");
    a && a(e, o.cx_appId, _.lx_appName, _.lxId, t.owl_appName, t.owl_startConfig, t.owl_env, t.owl_version, p.wxUnionId, p.wxmpOpenId);
};