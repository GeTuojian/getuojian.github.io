var e = require("../../../induction/wxmp/@mtfe/perf-mp/perf-mp_1.4.4.js"), t = e.perf, n = function(e) {}, r = function(e) {}, o = e.App, a = e.Page, i = function() {
    var e = {};
    return o(e, n), e;
}(), d = function() {
    var e = {};
    return a(e, r), e;
}();

module.exports = {
    init: function(e) {
        t.init(e);
    },
    setUserId: function(e) {
        t.setUserId(e);
    },
    addWebview: function(e, n) {
        t.addWebview(e, n);
    },
    addSocketOverview: function(e) {
        t.addSocketOverview(e);
    },
    addSocket: function(e) {
        t.addSocket(e);
    },
    addRate: function(e) {
        t.addRate(e);
    },
    appFmp: function(e) {
        t.appFmp(e);
    },
    appLvc: function(e) {
        t.appLvc(e);
    },
    addPoint: function(e) {
        t.addPoint(e);
    },
    addError: function(e) {
        var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "CustomError";
        t.addError(e, n);
    },
    reportMKMessage: function(e, n) {
        t.reportMKMessage(e, n);
    },
    setGlobalTags: function(e) {
        t.setGlobalTags(e);
    },
    perf: t,
    request: e.request,
    page: d,
    app: i
};