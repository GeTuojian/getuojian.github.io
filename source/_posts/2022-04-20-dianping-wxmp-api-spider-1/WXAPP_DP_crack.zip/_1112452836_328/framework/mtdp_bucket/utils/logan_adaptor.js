var n = require("../../../induction/wxmp/@dp/logan-wxapp/build/wxlogan.js");

module.exports = {
    config: function(o) {
        n.config(o);
    },
    log: function(o) {
        var c = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, i = "【CockTail Log】:";
        n.log("".concat(i, " ").concat(o, " ").concat(c ? JSON.stringify(c) : ""));
    },
    warn: function(n, o) {},
    error: function(n, o) {}
};