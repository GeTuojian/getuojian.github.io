var n, i, u = [];

module.exports = function(t, r, o) {
    return function(e) {
        void 0 === i ? (e && u.push(e), n || (n = 1, require("../../../induction/wxmp/@mtfe/wx-jsguard/jsguard.js").init({
            appid: t,
            openid: o,
            unionid: r
        }).then(function(n) {
            n.finger.g(function(t) {
                i = t || "", u && (u.forEach(function(u) {
                    return u(n, i);
                }), u = null);
            });
        }))) : e && e(i);
    };
};