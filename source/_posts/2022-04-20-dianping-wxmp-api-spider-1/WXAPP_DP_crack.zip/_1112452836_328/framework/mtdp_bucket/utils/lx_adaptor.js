var e, t = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/helpers/defineProperty")), r = require("../../../induction/wxmp/@analytics/wechat-sdk/lib/index.js"), n = require("../../../dpmapp/utils/parse_url.js"), i = require("../../../dpmapp/utils/stringify_url.js"), a = require("../../../dpmapp/utils/page_url.js"), u = require("../../../dpmapp/config/app_config.js"), o = require("../../../framework/mtdp_bucket/async_data_provider/account_provider.js"), c = require("../../../framework/mtdp_bucket/async_data_provider/cityid_provider.js"), s = require("../../../framework/mtdp_bucket/async_data_provider/lbs_provider.js"), m = "", g = "";

module.exports = (e = {
    init: function(e) {
        r.init("https://report.meituan.com", Object.assign({}, e, {
            rtnm: "dianping_mina",
            category: "dianping_nova",
            minaVersion: u.VERSION
        }));
    },
    debug: function(e, t) {
        r.debug(e, t);
    },
    getUTM: function() {
        return r.get("utm");
    },
    setUTM: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, n = {};
        e && e.scene && this._setScene(e.scene), n = Object.assign({}, this._parseUTM(e, t), e), 
        r.setUTM(n);
    },
    startApp: function(e) {
        r.start(this._getLxCommon(e));
    },
    quitApp: function() {
        r.quit();
    },
    setCurrentCid: function(e) {
        r.setCurrentCid(e);
    },
    pageView: function(e, t) {
        var n = this, u = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, c = {}, s = "", p = "";
        try {
            var d = a.getCurrentPage();
            c = d.options, (s = d.route) && (p = i(s, c));
        } catch (e) {}
        var l = Object.assign({}, this._getLxCommon(t), c, u);
        p && (l.url = p), l = this.checkUuid(l);
        var _ = o.getDataSync() && o.getDataSync()[0].value;
        _ ? (this.set("wxid", _), r.presetGeolocation(g, m).pageView(e, l)) : o.getDataAsync(function(t) {
            t && t[0] && n.set("wxid", t[0].value), r.presetGeolocation(g, m).pageView(e, l);
        });
    },
    checkUuid: function(e) {
        var t = e, r = t.custom, n = t && (t.shopid || t.shopId || t.poi_id);
        return n && (t = Object.assign({}, e, {
            shopuuid: n
        })), r && (t.custom = this.checkUuid(r)), t || null;
    },
    pageDisappear: function(e) {
        r.pageDisappear(e);
    },
    moduleView: function(e, t) {
        var n = this._getLxCommon(t);
        n = this.checkUuid(n), r.presetGeolocation(g, m).moduleView(e, n);
    },
    moduleClick: function(e, t) {
        var n = this._getLxCommon(t);
        n = this.checkUuid(n), r.moduleClick(e, n);
    },
    moduleEdit: function(e, t) {
        var n = this._getLxCommon(t);
        r.moduleEdit(e, n);
    },
    get: function(e) {
        return r.get(e);
    },
    setTagWithCtx: function(e, t, n) {
        r.setTagWithCtx(e, t, n);
    },
    getUtmSource: function() {
        return r.get("utm") || {};
    },
    set: function(e, t) {
        r.set(e, t);
    },
    resetGeolocation: function(e, t) {
        r.resetGeolocation(e, t);
    },
    setCanaryReleaseVersion: function(e) {
        r.setCanaryReleaseVersion(e);
    },
    getLxData: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        m = s.getDataSync() && s.getDataSync()[0].value, g = s.getDataSync() && s.getDataSync()[1].value;
        var t = {
            minaVersion: u.APP_VERSION,
            scene: wx.getLaunchOptionsSync().scene
        };
        e.from && (t.from = e.from);
        try {
            t.openId = o.getDataSync() && o.getDataSync()[0].value, t.cityId = c.getDataSync() && c.getDataSync()[0].value;
        } catch (e) {}
        return t;
    },
    getLxCUID: function() {
        return r.get("lxcuid") || "";
    },
    getSharePath: function(e) {
        var t, r, a = {};
        if (e) {
            var o = n(e), c = o.uri, s = o.query, m = o.hash;
            try {
                var g = this.getUTM();
                g && g.utm_source ? (t = g.utm_source, r = g.utm_term, t == u.APP_NAME && r || (r = t, 
                t = u.APP_NAME), a = {
                    utm_source: t,
                    utm_term: r || t
                }) : a = {
                    utm_source: u.APP_NAME
                }, s = Object.assign({}, s, a);
            } catch (e) {}
            return i(c, s, m);
        }
    },
    order: function(e, t, n) {
        var i = this._getLxCommon(n);
        r.order(e, t, i);
    },
    collectParamsToWeb: function(e) {
        return r.collectParamsToWeb(e);
    },
    pay: function(e, t, n) {
        var i = this._getLxCommon(n);
        r.pay(e, t, i);
    },
    setLch: function(e) {
        return r.setLch(e);
    }
}, (0, t.default)(e, "setTagWithCtx", function(e, t, n) {
    return r.setTagWithCtx(e, t, n);
}), (0, t.default)(e, "setTag", function(e, t) {
    return r.setTag(e, t);
}), (0, t.default)(e, "clearTag", function(e) {
    return r.clearTag(e);
}), (0, t.default)(e, "_getLxCommon", function(e) {
    var t = this.getLxData();
    return e && "[object Object]" === Object.prototype.toString.call(e) && (t = Object.assign({}, t, e)), 
    t;
}), (0, t.default)(e, "_setScene", function(e) {
    e && r.set("scene", e);
}), (0, t.default)(e, "_parseUTM", function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 ? arguments[1] : void 0, r = {
        utm_source: u.APP_NAME
    }, i = e.query;
    try {
        if (i && i.q) {
            var a = decodeURIComponent(i.q), o = n(a), c = o.query;
            c && (c.utm_source || c.u_s) && (c.utm_source = c.utm_source || c.u_s, i = c);
        }
    } catch (e) {}
    var s = e.scene;
    if (1034 == s && (r.utm_source = "wxpay_order"), 1019 == s && (r.utm_source = "wx_wallet"), 
    i && i.serviceType) {
        var m = this._getUtmFromWxSearch(i.serviceType, t);
        m && (r.utm_source = m);
    }
    var g = [ "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content" ];
    return g.map(function(e) {
        i && i[e] && (r[e] = i[e]);
    }), r;
}), (0, t.default)(e, "_getUtmFromWxSearch", function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
    if (t && e) return t[e + ""] || "";
}), e);