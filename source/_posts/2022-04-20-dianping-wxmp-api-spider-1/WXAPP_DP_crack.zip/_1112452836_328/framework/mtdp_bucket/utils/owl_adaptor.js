var r = require("../../../induction/wxmp/@dp/owl-wxapp/es6/index.js"), e = r.owl;

var t = {
    start: function(r) {
        e.start(r);
    },
    setUnionId: function(r) {
        e.cfgManager.update("unionId", r);
    },
    pushError: function(r, t) {
        e.error.pushError(function(r) {
            return Object.assign({}, r || {}, {
                dynamicMetric: Object.assign({}, r.dynamicMetric || {}, {
                    pi: "wxmp"
                })
            });
        }(r), t);
    },
    reportError: function(r, t) {
        e.error.report(r, t);
    },
    appLaunch: function() {
        e && e.pageSpeed.appLaunch();
    },
    appError: function(r) {
        try {
            e && e.error.onError(r);
        } catch (r) {}
    },
    addError: function(r, t, n) {
        try {
            e && e.error.addError(r, t, n);
        } catch (r) {}
    },
    reportAll: function() {
        try {
            e.error.report(), e.resource.report(), e.pageSpeed.report();
        } catch (r) {}
    },
    pageLoad: function() {
        e && e.pageSpeed.pageLoad();
    },
    pageReady: function() {
        e && e.pageSpeed.pageReady();
    },
    addPoint: function(r) {
        var t = getCurrentPages(), n = t[t.length - 1];
        e && e.pageSpeed.addPoint(r, n.route || n.__route__);
    },
    addApi: function(r, t) {
        try {
            e && e.resource.addApi(r, t);
        } catch (r) {}
    },
    createFirstContentfulPaint: function(r, t) {
        e && e.pageSpeed.createFirstContentfulPaint(r, t);
    },
    addFirstContentfulPaint: function(r, t) {
        e && e.pageSpeed.addFirstContentfulPaint(r, t);
    },
    reportSpeed: function() {
        e && e.pageSpeed.report();
    },
    reportPv: function() {
        e && e.pvManager.report();
    },
    newMetric: e.newMetric,
    owl: e,
    request: r.request,
    page: r.page,
    app: r.app
};

module.exports = Object.assign({}, e, t);