// packages/product-shelf/pages/index.js
Page({data: {}})