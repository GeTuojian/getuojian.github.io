// packages/order/pages/coupondetail/coupondetail.js
Page({data: {}})