// packages/order/pages/mycoupon/mycoupon.js
Page({data: {}})