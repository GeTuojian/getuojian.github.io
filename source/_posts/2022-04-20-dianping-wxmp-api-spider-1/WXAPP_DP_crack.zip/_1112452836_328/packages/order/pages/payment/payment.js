// packages/order/pages/payment/payment.js
Page({data: {}})