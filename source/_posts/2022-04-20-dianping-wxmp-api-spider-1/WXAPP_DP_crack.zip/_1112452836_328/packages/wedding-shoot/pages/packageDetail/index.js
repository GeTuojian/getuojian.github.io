// packages/wedding-shoot/pages/packageDetail/index.js
Page({data: {}})