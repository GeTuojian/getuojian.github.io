// packages/wedding-shoot/pages/caseList/index.js
Page({data: {}})