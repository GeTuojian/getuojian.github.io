// packages/wedding-shoot/pages/caseDetail/index.js
Page({data: {}})