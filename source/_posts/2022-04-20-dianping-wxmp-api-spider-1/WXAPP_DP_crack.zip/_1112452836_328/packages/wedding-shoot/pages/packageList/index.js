// packages/wedding-shoot/pages/packageList/index.js
Page({data: {}})