// packages/wedding-shoot/pages/videoDetail/index.js
Page({data: {}})