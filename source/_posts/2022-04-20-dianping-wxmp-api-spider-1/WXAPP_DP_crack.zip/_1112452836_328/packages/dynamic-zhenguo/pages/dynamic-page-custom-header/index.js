// packages/dynamic-zhenguo/pages/dynamic-page-custom-header/index.js
Page({data: {}})