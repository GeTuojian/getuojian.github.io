// packages/dynamic-zhenguo/pages/dynamic-page/index.js
Page({data: {}})