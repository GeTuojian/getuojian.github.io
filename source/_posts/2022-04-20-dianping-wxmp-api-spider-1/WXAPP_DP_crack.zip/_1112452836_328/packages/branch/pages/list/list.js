// packages/branch/pages/list/list.js
Page({data: {}})