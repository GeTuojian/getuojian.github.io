// packages/hotel/pages/suggest/index.js
Page({data: {}})