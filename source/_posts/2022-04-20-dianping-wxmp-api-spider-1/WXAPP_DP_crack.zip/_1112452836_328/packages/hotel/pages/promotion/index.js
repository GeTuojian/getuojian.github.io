// packages/hotel/pages/promotion/index.js
Page({data: {}})