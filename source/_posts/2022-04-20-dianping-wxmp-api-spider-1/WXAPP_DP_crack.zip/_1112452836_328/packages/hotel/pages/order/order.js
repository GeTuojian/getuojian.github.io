// packages/hotel/pages/order/order.js
Page({data: {}})