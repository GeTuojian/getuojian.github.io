// packages/hotel/pages/middleware/index.js
Page({data: {}})