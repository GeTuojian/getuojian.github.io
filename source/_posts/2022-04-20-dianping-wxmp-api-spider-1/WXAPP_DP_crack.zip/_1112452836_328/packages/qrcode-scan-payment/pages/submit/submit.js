// packages/qrcode-scan-payment/pages/submit/submit.js
Page({data: {}})