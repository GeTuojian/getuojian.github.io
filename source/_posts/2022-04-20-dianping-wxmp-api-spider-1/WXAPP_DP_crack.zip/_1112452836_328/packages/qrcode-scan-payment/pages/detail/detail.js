// packages/qrcode-scan-payment/pages/detail/detail.js
Page({data: {}})