// packages/dache/pages/home/index.js
Page({data: {}})