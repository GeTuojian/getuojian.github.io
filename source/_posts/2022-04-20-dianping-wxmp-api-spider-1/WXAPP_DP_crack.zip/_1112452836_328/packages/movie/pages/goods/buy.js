// packages/movie/pages/goods/buy.js
Page({data: {}})