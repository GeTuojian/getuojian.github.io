// packages/movie/pages/cinema/cinema.js
Page({data: {}})