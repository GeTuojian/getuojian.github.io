// packages/movie/pages/order/refund/detail.js
Page({data: {}})