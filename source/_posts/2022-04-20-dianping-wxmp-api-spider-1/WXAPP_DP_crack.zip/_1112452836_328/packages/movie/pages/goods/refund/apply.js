// packages/movie/pages/goods/refund/apply.js
Page({data: {}})