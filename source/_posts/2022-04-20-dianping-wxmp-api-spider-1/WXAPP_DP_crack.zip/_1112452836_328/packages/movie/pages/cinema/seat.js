// packages/movie/pages/cinema/seat.js
Page({data: {}})