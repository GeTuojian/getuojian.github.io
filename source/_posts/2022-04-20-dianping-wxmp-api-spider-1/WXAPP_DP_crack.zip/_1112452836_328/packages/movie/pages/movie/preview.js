// packages/movie/pages/movie/preview.js
Page({data: {}})