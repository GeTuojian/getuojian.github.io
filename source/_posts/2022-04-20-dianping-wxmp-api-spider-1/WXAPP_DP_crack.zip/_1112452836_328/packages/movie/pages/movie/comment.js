// packages/movie/pages/movie/comment.js
Page({data: {}})