// packages/movie/pages/goods/order-detail.js
Page({data: {}})