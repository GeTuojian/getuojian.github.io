// packages/movie/pages/cinema/movie.js
Page({data: {}})