// packages/movie/pages/order/buy.js
Page({data: {}})