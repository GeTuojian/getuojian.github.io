// packages/movie/pages/goods/order-result.js
Page({data: {}})