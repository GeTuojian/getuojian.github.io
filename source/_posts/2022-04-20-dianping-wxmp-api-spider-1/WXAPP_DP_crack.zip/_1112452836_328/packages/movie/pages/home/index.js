// packages/movie/pages/home/index.js
Page({data: {}})