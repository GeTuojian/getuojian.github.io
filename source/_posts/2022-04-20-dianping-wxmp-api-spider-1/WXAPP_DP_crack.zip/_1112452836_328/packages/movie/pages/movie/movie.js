// packages/movie/pages/movie/movie.js
Page({data: {}})