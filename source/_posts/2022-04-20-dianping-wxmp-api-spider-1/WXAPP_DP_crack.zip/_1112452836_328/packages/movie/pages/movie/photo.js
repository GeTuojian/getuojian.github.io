// packages/movie/pages/movie/photo.js
Page({data: {}})