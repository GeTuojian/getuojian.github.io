// packages/movie/pages/goods/refund/detail.js
Page({data: {}})