// packages/ugc/pages/reviewlist/reviewlist.js
Page({data: {}})