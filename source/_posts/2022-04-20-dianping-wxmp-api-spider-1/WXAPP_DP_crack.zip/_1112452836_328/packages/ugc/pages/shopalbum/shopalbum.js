// packages/ugc/pages/shopalbum/shopalbum.js
Page({data: {}})