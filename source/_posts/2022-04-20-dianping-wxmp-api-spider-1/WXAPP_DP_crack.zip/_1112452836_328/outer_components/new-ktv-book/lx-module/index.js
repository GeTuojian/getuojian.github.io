var e = getApp().induction.LX;

Component({
    externalClasses: [ "lx-class" ],
    properties: {
        lxViewBid: {
            type: String,
            value: ""
        },
        lxClickBid: {
            type: String,
            value: ""
        },
        lxExtend: {
            type: String,
            value: "{}"
        },
        isObserver: {
            type: Boolean,
            value: !0
        },
        options: {
            type: Object,
            value: {}
        }
    },
    lifetimes: {
        ready: function() {
            this.data.lxViewBid && this.moduleView();
        }
    },
    methods: {
        moduleView: function() {
            var t = this, i = this.data, l = i.lxClickBid, s = i.lxViewBid, n = i.options;
            if (1 !== this.viewCount && s) if (this.setLxModule(), this.data.isObserver) {
                var o = this.createIntersectionObserver(this);
                o.relativeToViewport().observe("#lx-".concat(l || s), function(i) {
                    i.intersectionRatio > 0 ? (t.viewCount = 1, e.moduleView(s, t._lxExtend, n), o.disconnect()) : console.log("组件");
                });
            } else e.moduleView(s, this._lxExtend, n);
        },
        setLxModule: function() {
            if (!this._lxExtend) try {
                var e = this.data.lxExtend;
                if (-1 === e.indexOf("{")) {
                    var t = e.split("&"), i = {};
                    t && t.length && t.forEach(function(e) {
                        var t = e.split("=");
                        i[t[0]] = t[1];
                    }), this._lxExtend = i;
                } else e = e.replace(/'/g, '"'), e = JSON.parse(e), this._lxExtend = e;
            } catch (e) {
                console.log("lx-module:", e);
            }
        },
        moduleClick: function() {
            var t = this.data, i = t.lxClickBid, l = t.options;
            i && (this.setLxModule(), e.moduleClick(i, this._lxExtend, l), this.triggerEvent("click"));
        }
    }
});