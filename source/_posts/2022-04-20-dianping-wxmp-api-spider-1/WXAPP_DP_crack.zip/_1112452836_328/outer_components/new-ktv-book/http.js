Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getFetch = function(e, t) {
    return new Promise(function(n, r) {
        wx.request({
            url: e,
            data: t,
            method: "get",
            header: {
                "content-type": "application/x-www-form-urlencoded"
            },
            success: function(e) {
                return function(e) {
                    return e && e.data;
                }(e) ? n(e.data) : r(e.data);
            },
            fail: function(e) {
                r(res);
            }
        });
    });
};