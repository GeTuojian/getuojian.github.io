Component({
    properties: {
        item: {
            type: null
        }
    },
    attached: function() {
        console.log("pnload", this.data.item);
    }
});