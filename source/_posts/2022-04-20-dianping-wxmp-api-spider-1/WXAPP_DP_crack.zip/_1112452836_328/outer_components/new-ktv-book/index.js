var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../@babel/runtime/helpers/defineProperty")), a = t(require("../../@babel/runtime/regenerator")), i = t(require("../../@babel/runtime/helpers/asyncToGenerator")), n = require("./config"), o = require("./http");

function r(t, e) {
    var a = Object.keys(t);
    if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e && (i = i.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
        })), a.push.apply(a, i);
    }
    return a;
}

var s, c, d, l;

Component({
    properties: {
        shopid: {
            type: null,
            observer: "init"
        },
        cityid: {
            type: null,
            value: ""
        },
        isMT: {
            type: Boolean,
            default: !1
        }
    },
    data: {
        dpShopid: "",
        saleCountInfo: "",
        refundTip: "",
        showKtvShelf: !1,
        scrollLeft: 0,
        bookingTypeScrollLeft: 0,
        timeItemWidth: 80,
        timeItemDistance: 60,
        isShowMoreActivity: !1,
        CAN_NOT_BOOK_STATUS: 0,
        activityAnimationType: "",
        promoItems: [],
        activeDateIndex: 0,
        activeTypeIndex: 0,
        activePeriodIndex: "",
        isShowBookingModal: !1,
        bookAnimationType: "",
        showMore: !0,
        modalIntroductionConfig: {
            date: "",
            time: "",
            hour: ""
        },
        modalSelectTipsConfig: {
            text: "请选择开唱时间",
            isShow: !0
        },
        modalState: "",
        modalExtendInfo: {
            reductions: [],
            warning: "",
            discount: "",
            price: "",
            selectedDate: "",
            originalPrice: ""
        },
        clientType: "",
        platform: "",
        mainTitle: null,
        ktvBookDates: [],
        productItems: null,
        filterIdAndProductAreas: [],
        modalData: {},
        curModalItem: {},
        defaultModalItem: {},
        newKtvRoomView: "",
        moveParams: {
            scrollLeft: 0,
            screenHalfWidth: wx.getSystemInfoSync().screenWidth / 2
        }
    },
    lifetimes: {
        attached: function() {}
    },
    methods: {
        resetData: function() {
            return {
                activeTypeIndex: 0,
                activePeriodIndex: "",
                isShowBookingModal: !1,
                bookAnimationType: "",
                showMore: !0,
                bookingTypeScrollLeft: 0,
                modalIntroductionConfig: {
                    date: "",
                    time: "",
                    hour: ""
                },
                modalSelectTipsConfig: {
                    text: "请选择开唱时间",
                    isShow: !0
                },
                modalState: "",
                modalExtendInfo: {
                    reductions: [],
                    warning: "",
                    discount: "",
                    price: "",
                    selectedDate: "",
                    originalPrice: ""
                }
            };
        },
        getScrollLeft: function(t) {
            return 140 * t - 345;
        },
        stopScrolling: function() {
            return !1;
        },
        init: (l = (0, i.default)(a.default.mark(function t(e) {
            var i, o, r, s, c = this;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!e) {
                        t.next = 11;
                        break;
                    }
                    return this.setData(this.data.isMT ? n.MTCof : n.DPCof), t.next = 4, this.fetchKtvList(e);

                  case 4:
                    if ((i = t.sent) && i.shelfComponent && i.shelfComponent.filter) {
                        t.next = 7;
                        break;
                    }
                    return t.abrupt("return");

                  case 7:
                    o = i.shelfComponent.filter.filterBtns || [], r = i.shelfComponent.mainTitle, s = i.shelfComponent.filterIdAndProductAreas || [], 
                    this.setData({
                        ktvBookDates: o,
                        mainTitle: r,
                        filterIdAndProductAreas: s
                    }, function() {
                        c.setData({
                            productItems: c.getItemByFilterBtnId()
                        });
                    });

                  case 11:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function(t) {
            return l.apply(this, arguments);
        }),
        handleDateChange: function(t) {
            var a = this, i = t.currentTarget.dataset.index || 0;
            this.data.activeDateIndex !== i && this.setData(function(t) {
                for (var a = 1; a < arguments.length; a++) {
                    var i = null != arguments[a] ? arguments[a] : {};
                    a % 2 ? r(Object(i), !0).forEach(function(a) {
                        (0, e.default)(t, a, i[a]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(i)) : r(Object(i)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(i, e));
                    });
                }
                return t;
            }({
                scrollLeft: this.getScrollLeft(i),
                activeDateIndex: i
            }, this.resetData()), function() {
                a.setData({
                    productItems: a.getItemByFilterBtnId()
                });
            });
        },
        handleBookTypeSelect: function(t) {
            var e = this, a = t.currentTarget.dataset.index || 0;
            this.getRect("#new-ktv-room-" + a), this.setData({
                activeTypeIndex: a,
                showMore: !0
            }, function() {
                e.setData({
                    productItems: e.getItemByFilterBtnId()
                });
            });
        },
        showBookingModal: (d = (0, i.default)(a.default.mark(function t(e) {
            var i, n, o, r, s, c = this;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (e.available) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return");

                  case 2:
                    return this.setData({
                        isShowBookingModal: !0,
                        modalState: "loading"
                    }), i = this.data, n = i.ktvBookDates, o = i.activeDateIndex, n[o], r = JSON.parse(e.jumpUrl || ""), 
                    t.next = 8, this.getModalData(r).catch(function(t) {
                        c.setData({
                            modalState: "error"
                        }), console.error("获取ktv弹窗信息失败：", t);
                    });

                  case 8:
                    (s = (s = t.sent).dzPopupComponent) && this.setData({
                        modalState: "normal",
                        bookAnimationType: "flyin",
                        modalData: s,
                        curModalItem: s.defaultItem,
                        defaultModalItem: s.defaultItem
                    });

                  case 11:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function(t) {
            return d.apply(this, arguments);
        }),
        handleSelectPeriod: function(t) {
            var e = t.currentTarget.dataset.index, a = this.data.modalData.filterComponent.filterBtns[e].filterBtnId, i = this.findItemByKey(this.data.modalData.filterIdAndItemAreas, "filterBtnId", a);
            this.setData({
                activePeriodIndex: e,
                curModalItem: i.itemArea.itemList[0]
            });
        },
        handleNextStep: function(t) {
            var e = t.currentTarget.dataset.url;
            wx.navigateTo({
                url: e
            });
        },
        fetchKtvList: (c = (0, i.default)(a.default.mark(function t(e) {
            var i, r, s;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return i = "".concat(n.HOST).concat(n.PATH.DATE_FILTER), r = {
                        shopid: e,
                        sceneCode: "joy_poi_ktv_book_shelf",
                        clientType: this.data.clientType,
                        platform: this.data.platform
                    }, t.prev = 2, t.next = 5, (0, o.getFetch)(i, r);

                  case 5:
                    if (200 === (s = t.sent).code) {
                        t.next = 8;
                        break;
                    }
                    return t.abrupt("return");

                  case 8:
                    return t.abrupt("return", s.msg);

                  case 11:
                    t.prev = 11, t.t0 = t.catch(2), console.log("获取新 KTV 货架失败");

                  case 14:
                  case "end":
                    return t.stop();
                }
            }, t, this, [ [ 2, 11 ] ]);
        })), function(t) {
            return c.apply(this, arguments);
        }),
        getModalData: (s = (0, i.default)(a.default.mark(function t(e) {
            var i, r, s;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return i = Object.assign({
                        platform: this.data.platform,
                        clientType: this.data.clientType
                    }, e), r = "".concat(n.HOST).concat(n.PATH.TIME_FILTER), t.prev = 2, t.next = 5, 
                    (0, o.getFetch)(r, i);

                  case 5:
                    if (200 === (s = t.sent).code) {
                        t.next = 8;
                        break;
                    }
                    return t.abrupt("return");

                  case 8:
                    return t.abrupt("return", s.msg);

                  case 11:
                    t.prev = 11, t.t0 = t.catch(2), console.log("获取新 KTV 货架失败");

                  case 14:
                  case "end":
                    return t.stop();
                }
            }, t, this, [ [ 2, 11 ] ]);
        })), function(t) {
            return s.apply(this, arguments);
        }),
        getBookingReportCommonParams: function(t, e) {
            return {
                poi_id: this.properties.shopid,
                product_id: t.defaultItemId,
                index: e + 1
            };
        },
        handleBookItemClick: function(t) {
            var e = t.currentTarget.dataset, a = e.roomitem, i = void 0 === a ? {} : a;
            e.index;
            this.showBookingModal(i);
        },
        findItemByKey: function(t, e, a) {
            var i = t.filter(function(t) {
                return t[e] === a;
            }), n = null;
            return i.length && (n = i[0]), n;
        },
        showMoreActivity: function() {
            this.setData({
                isShowMoreActivity: !0,
                activityAnimationType: "fadein"
            });
        },
        hideMoreActivity: function() {
            this.setData({
                activityAnimationType: "fadeout"
            });
        },
        handleActivityAnimationEnd: function() {
            "fadeout" === this.data.activityAnimationType && this.setData({
                activityAnimationType: "",
                isShowMoreActivity: !1
            });
        },
        toggleViewMore: function() {
            this.handleViewMoreClick(this.data.showMore), this.setData({
                showMore: !this.data.showMore
            });
        },
        closeBookingDialog: function() {
            this.setData({
                bookAnimationType: "flyout",
                activePeriodIndex: "",
                modalSelectTipsConfig: {
                    text: "请选择开唱时间",
                    isShow: !0
                }
            });
        },
        handleAnimationend: function() {
            "flyout" === this.data.bookAnimationType && this.setData({
                isShowBookingModal: !1,
                bookAnimationType: ""
            });
        },
        handleViewMoreClick: function(t) {},
        handleBtnClick: function(t) {
            var e = t.currentTarget.dataset, a = e.roomitem, i = (e.index, this.data);
            i.ktvBookDates, i.activeDateIndex;
            this.showBookingModal(a);
        },
        handleBookingItemView: function(t) {
            var e = t.currentTarget.dataset;
            e.roomitem, e.index;
        },
        handleBookingTypeView: function(t) {
            t.currentTarget.dataset.index;
            var e = this.data;
            e.ktvBookDates, e.activeDateIndex;
        },
        getItemByFilterBtnId: function() {
            var t = this.data.ktvBookDates && this.data.ktvBookDates[this.data.activeDateIndex] && this.data.ktvBookDates[this.data.activeDateIndex].children && this.data.ktvBookDates[this.data.activeDateIndex].children[this.data.activeTypeIndex] && this.data.ktvBookDates[this.data.activeDateIndex].children[this.data.activeTypeIndex].filterBtnId, e = (this.data.filterIdAndProductAreas || []).filter(function(e) {
                return e.filterBtnId === t;
            }), a = {};
            return e.length && (a = e[0].productAreas && e[0].productAreas[0] && e[0].productAreas[0].itemArea && e[0].productAreas[0].itemArea.productItems), 
            a;
        },
        getRect: function(t) {
            var e = this;
            this.createSelectorQuery().select(t).boundingClientRect(function(t) {
                var a = e.data.moveParams;
                a.subLeft = t.left, a.subHalfWidth = t.width / 2, e.moveTo();
            }).exec();
        },
        moveTo: function() {
            var t = this.data.moveParams.subLeft, e = this.data.moveParams.screenHalfWidth, a = this.data.moveParams.subHalfWidth, i = this.data.moveParams.scrollLeft;
            i += t - e + a, this.setData({
                bookingTypeScrollLeft: i
            });
        },
        scrollMove: function(t) {
            var e = this.data.moveParams;
            e.scrollLeft = t.detail.scrollLeft, this.setData({
                moveParams: e
            });
        }
    }
});