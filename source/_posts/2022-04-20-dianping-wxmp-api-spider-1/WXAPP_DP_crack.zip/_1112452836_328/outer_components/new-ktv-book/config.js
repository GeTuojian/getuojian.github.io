Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.PATH = exports.HOST = exports.DPCof = exports.MTCof = void 0;

exports.MTCof = {
    platform: 2,
    clientType: 202
};

exports.DPCof = {
    platform: 1,
    clientType: 102
};

exports.HOST = "https://mapi.dianping.com";

exports.PATH = {
    DATE_FILTER: "/api/dzviewscene/productshelf/dzbookshelf",
    TIME_FILTER: "/api/dzviewscene/other/dzpopup"
};