Component({
    properties: {
        moduleConfig: {
            type: Object
        }
    }
});