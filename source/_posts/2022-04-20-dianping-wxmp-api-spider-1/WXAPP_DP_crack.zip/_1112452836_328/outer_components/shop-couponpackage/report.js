var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/defineProperty"));

function r(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
        })), t.push.apply(t, o);
    }
    return t;
}

function t(t) {
    for (var o = 1; o < arguments.length; o++) {
        var n = null != arguments[o] ? arguments[o] : {};
        o % 2 ? r(Object(n), !0).forEach(function(r) {
            (0, e.default)(t, r, n[r]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : r(Object(n)).forEach(function(e) {
            Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
        });
    }
    return t;
}

var o = require("../../framework/mtdp_bucket/utils/owl_adaptor.js");

module.exports = {
    diyReport: function(e, r, t) {
        var n = o.newMetric();
        n.setMetric(e, r), n.setTags(t || {}), n.report();
    },
    errorReport: function(e, r, n) {
        if (e && r) {
            var c = n || {}, i = c.category, s = c.level, a = c.tags, p = "", u = "", b = function(e) {
                var r = Object.prototype.toString.call(e);
                return /\[object\s(\w+)\]/.test(r), RegExp.$1;
            }(r);
            "Object" === b && (p = JSON.stringify(r)), "Error" === b && (p = r.message || "", 
            u = r.stack || ""), "String" === b && (p = r);
            var l = {
                sec_category: e,
                category: i || "jsError",
                level: s || "info",
                tags: t(t({}, a), {}, {
                    message: p,
                    stack: u,
                    bizCategory: "meishi"
                }),
                content: p
            };
            o && o.error.pushError(l, !0);
        }
    }
};