var e = require("./report.js"), o = "";

Component({
    properties: {
        shopOptions: {
            type: Object,
            observer: "onPropertyChange"
        },
        moduleConfig: {
            type: Object
        },
        lxData: {
            type: Object
        }
    },
    lifetimes: {
        attached: function() {}
    },
    data: {
        showMore: !1
    },
    methods: {
        onPropertyChange: function(o, t) {
            var s = this, r = require("../../framework/class_define/http_protocol.js"), a = require("../../framework/class_define/http_request_task.js"), i = t || {}, n = i.shopId, p = void 0 === n ? "" : n, d = i.shopUuid, u = void 0 === d ? "" : d, c = o || {}, h = c.shopId, m = void 0 === h ? "" : h, l = c.shopUuid, g = void 0 === l ? "" : l, f = getApp().userData.wxmpEncryptedOpenId || "";
            if ((p !== m || u !== g) && (g || m)) {
                this.shopId = g || m;
                var v = {
                    utm_term: "10.44.5",
                    version_name: "10.44.5",
                    req_source: "wx",
                    utm_medium: this.getMedium(),
                    dpid: f,
                    poiid: m,
                    shopuuid: g,
                    token: getApp().userData.dpAccessToken
                };
                getApp().h.request(new a(new r("".concat("/meishi/dppoi/v1/poi/couponPackage/").concat(g ? 0 : m), {
                    domain: "https://apimeishi.meituan.com",
                    data: v
                }), {
                    callback: function() {
                        var o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = o.serverData || {}, r = t && t.data || {}, a = r.data, i = r.error, n = void 0 === i ? {} : i;
                        n && n.code && (e.diyReport("food-coupon-package-show", 0, {
                            message: "异常"
                        }), e.errorReport("poi-detail-couponpackage-request-fail-business", n, {
                            tags: {
                                params: JSON.stringify(v)
                            }
                        })), a && s.startRender(a), 200 != +t.statusCode && (e.diyReport("food-coupon-package-show", 0, {
                            message: "状态码异常"
                        }), e.errorReport("poi-detail-couponpackage-request-fail-system", t, {
                            tags: {
                                params: JSON.stringify(v)
                            }
                        }));
                    }
                }));
            }
        },
        getMedium: function() {
            if (o) return o;
            var e = (wx.getSystemInfoSync() || {}).system, t = void 0 === e ? "" : e;
            return t && (o = "ios" === (t.split(" ")[0] || "").toLocaleLowerCase() ? "iphone" : "android"), 
            o;
        },
        startRender: function(o) {
            var t = o.moduleTitle, s = o.moduleIcon, r = o.purchaseStatus, a = o.purchasedList, i = void 0 === a ? [] : a, n = o.noPurchaseList, p = void 0 === n ? [] : n;
            p && p.length > 1 && (p.length = 1);
            var d = (r ? i : p) || [];
            d = d.filter(function(e) {
                var o = !!e.jumpUrl, t = e.couponList.some(function(e) {
                    return !e.title || !e.threshold;
                });
                return e.couponList && e.couponList.length && !t || (o = !1), o;
            }), this.setData({
                moduleTitle: t,
                moduleIcon: s,
                purchaseStatus: r,
                counponPackage: d,
                shopId: this.shopId,
                showMore: r && d.length > 1
            });
            var u = d && d.length > 0;
            e.diyReport("food-coupon-package-show", u ? 1 : 0, {
                message: u ? "商户无商家券" : ""
            });
        },
        eventShowMore: function() {
            this.setData({
                showMore: !1
            });
        }
    }
});