module.exports = {
    MILLISECONDS_A_SECOND: 1e3,
    SECONDS_A_MINUTE: 60,
    SECONDS_A_HOUR: 3600,
    MILLISECONDS_A_DAY: 864e5,
    WEBVIEWURL: "/packages/msdeal/pages/webview/webview"
};