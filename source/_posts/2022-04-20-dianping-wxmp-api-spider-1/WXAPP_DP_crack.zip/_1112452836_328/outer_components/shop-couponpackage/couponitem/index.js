var t = require("../report.js"), e = require("./constants.js"), i = (getApp() || {}).induction, n = (void 0 === i ? {} : i).LX, a = "moduleView", o = "moduleClick", c = "b_dianping_nova_1zyc67qv_mv", s = "b_dianping_nova_1zyc67qv_mc", r = [ {
    text: "部分时段可用"
} ];

Component({
    properties: {
        packageItem: {
            type: Object,
            observer: "eventPackageChange"
        },
        purchaseStatus: {
            type: Number
        },
        shopId: {
            type: String
        }
    },
    lifetimes: {
        detached: function() {
            this.countDownTimer && clearTimeout(this.countDownTimer), this.observer && this.observer.disconnect();
        }
    },
    data: {
        overTime: !1,
        timeText: "",
        timing: !1,
        needHide: !1,
        textHide: !1,
        packRules: null
    },
    methods: {
        eventPackageChange: function() {
            var t = this, i = this.data || {}, n = i.purchaseStatus, o = i.packageItem, s = o.expiredTime, r = void 0 === s ? 0 : s, u = o.productId, d = void 0 === u ? "" : u, p = o.available, h = void 0 === p || p, l = o.packageUseRules, v = void 0 === l ? [] : l, m = i.shopId, f = void 0 === m ? "" : m;
            if (this.lxReport(a, c, {
                deal_id: d,
                poi_id: f,
                status: n
            }), this.setData({
                packRules: v.map(function(t) {
                    return {
                        text: t,
                        needHide: !1
                    };
                })
            }, function() {
                t.checkRules(n, h);
            }), r > 0 && n) {
                var g = Date.now(), D = new Date(1e3 * r), R = parseInt((D - g) / e.MILLISECONDS_A_DAY, 10), T = "";
                if (R > 30) {
                    var k = D.getFullYear(), I = D.getMonth() + 1, _ = D.getDate();
                    T = "有效期至".concat(k, ".").concat(I, ".").concat(_);
                }
                if (R > 7 && R <= 30 && (T = "".concat(R, "天后过期")), R >= 2 && R <= 7 && (T = "仅剩".concat(R, "天过期")), 
                R >= 1 && R < 2 && (T = "明天过期"), T) return void this.setData({
                    timeText: T
                });
                R < 1 && this.timeCountDown(r);
            }
        },
        checkRules: function(t, e) {
            var i = this;
            if (t && !e) {
                var n = this.createSelectorQuery();
                return n.select("#tags").boundingClientRect(), void n.exec(function(t) {
                    t && (t[0].height > 18 && (i.setData({
                        packRules: r
                    }), i.setRuleHide()));
                });
            }
            this.setRuleHide();
        },
        setRuleHide: function() {
            var t = this;
            this.setData({
                textHide: !0
            }, function() {
                t.checkDomCanShow();
            });
        },
        lxReport: function(t, e, i) {
            n && n[t] && n[t](e, i, {
                category: "dianping_nova"
            });
        },
        checkDomCanShow: function() {
            var t = this, e = (this.data || {}).packRules;
            (void 0 === e ? [] : e).forEach(function(e, i) {
                var n = t.createIntersectionObserver();
                n.relativeTo("#tags"), n.observe(".tags".concat(i), function(e) {
                    var a = e.intersectionRect;
                    if (((void 0 === a ? {
                        width: 0
                    } : a) || {}).width < 36) {
                        var o = {};
                        o["packRules[".concat(i, "].needHide")] = !0, t.setData(o);
                    }
                    n.disconnect(), n = null;
                });
            });
        },
        fillZero: function(t) {
            return t > 9 ? t : "0".concat(t);
        },
        timeCountDown: function(t) {
            var i = this, n = Date.now(), a = parseInt(t - n / 1e3, 10);
            if (this.countDownTimer && clearTimeout(this.countDownTimer), a <= 0) this.setData({
                timeText: "仅剩00:00:00过期",
                timing: !0
            }, function() {
                i.setData({
                    timing: !1,
                    overTime: !0,
                    timeText: "已过期"
                });
            }); else {
                var o = this.fillZero(parseInt(a / e.SECONDS_A_HOUR, 10)), c = this.fillZero(parseInt(a / 60, 10) % 60), s = this.fillZero(parseInt(a % 60, 10));
                this.setData({
                    timeText: "仅剩".concat(o, ":").concat(c, ":").concat(s, "过期"),
                    timing: !0
                }, function() {
                    i.countDownTimer = setTimeout(function() {
                        i.timeCountDown(t);
                    }, 1e3);
                });
            }
        },
        eventJump: function(i) {
            var n = i.currentTarget.dataset || {}, a = n.jumpurl, c = n.button, r = void 0 === c ? "1" : c, u = this.data || {}, d = u.purchaseStatus, p = void 0 === d ? 0 : d, h = u.packageItem, l = void 0 === h ? {} : h, v = u.shopId, m = void 0 === v ? "" : v, f = (l || {}).productId;
            if (a) {
                var g = /^http/g.test(a) ? "".concat(e.WEBVIEWURL, "?url=").concat(encodeURIComponent(a)) : a;
                getApp().navigation.forwardTo({
                    url: g,
                    fail: function(e) {
                        t.errorReport("poi-detail-couponpackage-jump-fail", e);
                    }
                });
            }
            this.lxReport(o, s, {
                deal_id: f,
                poi_id: m,
                status: p,
                custom: {
                    button_name: r
                }
            }), t.diyReport("dp-couponpackage-jump", 1, {
                status: p ? "已购" : "未购"
            });
        }
    }
});