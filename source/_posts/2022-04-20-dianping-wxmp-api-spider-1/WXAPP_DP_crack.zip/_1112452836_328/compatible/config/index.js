var e = require("../../@babel/runtime/helpers/interopRequireDefault"), r = e(require("../../@babel/runtime/helpers/classCallCheck")), i = e(require("../../@babel/runtime/helpers/createClass")), t = require("./api.js"), n = require("../../dpmapp/config/app_config.js"), u = function() {
    function e() {
        (0, r.default)(this, e), console.warn("using old api, use getApp().appConfig or /config/app_config.js instead"), 
        this.VERSION = n.APP_VERSION, this.DEBUG = !1, this.API = t, this.APP_NAME = n.APP_NAME, 
        this.APPID = n.APP_ID;
    }
    return (0, i.default)(e, [ {
        key: "DOMAIN",
        get: function() {
            return n.DOMAIN;
        }
    }, {
        key: "MAPI_DOMAIN",
        get: function() {
            return n.MAPI_DOMAIN;
        }
    }, {
        key: "ENV",
        get: function() {
            return n.ENV;
        }
    } ]), e;
}();

module.exports = new u();