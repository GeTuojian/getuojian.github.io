var r = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/slicedToArray"));

function e(r, e) {
    var n = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (!n) {
        if (Array.isArray(r) || (n = function(r, e) {
            if (!r) return;
            if ("string" == typeof r) return t(r, e);
            var n = Object.prototype.toString.call(r).slice(8, -1);
            "Object" === n && r.constructor && (n = r.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(r);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return t(r, e);
        }(r)) || e && r && "number" == typeof r.length) {
            n && (r = n);
            var o = 0, u = function() {};
            return {
                s: u,
                n: function() {
                    return o >= r.length ? {
                        done: !0
                    } : {
                        done: !1,
                        value: r[o++]
                    };
                },
                e: function(r) {
                    throw r;
                },
                f: u
            };
        }
        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }
    var i, a = !0, l = !1;
    return {
        s: function() {
            n = n.call(r);
        },
        n: function() {
            var r = n.next();
            return a = r.done, r;
        },
        e: function(r) {
            l = !0, i = r;
        },
        f: function() {
            try {
                a || null == n.return || n.return();
            } finally {
                if (l) throw i;
            }
        }
    };
}

function t(r, e) {
    (null == e || e > r.length) && (e = r.length);
    for (var t = 0, n = new Array(e); t < e; t++) n[t] = r[t];
    return n;
}

function n(r, t) {
    var n, o = !1, u = e(r);
    try {
        for (u.s(); !(n = u.n()).done; ) {
            if (n.value.userId === t) {
                o = !0;
                break;
            }
        }
    } catch (r) {
        u.e(r);
    } finally {
        u.f();
    }
    return o;
}

function o(r, e, t) {
    return r.unshift({
        userId: e,
        userFace: t
    }), r;
}

function u(r, e) {
    var t = r.findIndex(function(r) {
        return r.userId === e;
    });
    return t > -1 && r.splice(t, 1), r;
}

module.exports = function(t, i) {
    var a, l = t.noteId, f = t.userId, s = t.userFace, c = t.isLike, d = e(function r(e, t) {
        return e && Array.isArray(t) ? 0 === t.length ? null : 1 === t.length ? e[t] : r(e[t[0]], t.slice(1)) : null;
    }(this.data, i.split(".")).entries());
    try {
        for (d.s(); !(a = d.n()).done; ) {
            var y = (0, r.default)(a.value, 2), h = y[0], b = y[1];
            if (b.noteId === l) {
                var v = "".concat(i, "[").concat(h, "]"), p = {}, m = n(b.flowerUsers, f);
                p[v] = m != c ? Object.assign(b, {
                    isSendFlower: c,
                    flowerCount: c ? b.flowerCount + 1 : b.flowerCount - 1,
                    flowerUsers: c ? o(b.flowerUsers, f, s) : u(b.flowerUsers, f)
                }) : b, this.setData(p);
                break;
            }
        }
    } catch (r) {
        d.e(r);
    } finally {
        d.f();
    }
};