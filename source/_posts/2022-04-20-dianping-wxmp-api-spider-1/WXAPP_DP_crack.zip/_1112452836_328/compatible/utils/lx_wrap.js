var r = require("../lib/sparrow.js");

module.exports = r.lxmina;