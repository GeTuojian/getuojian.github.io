var e = require("../../compatible/lib/sparrow.js").request;

module.exports = function(r, s) {
    return s && s.isMapiRequest ? e.mapi(r, s) : e.custom(r, s);
};