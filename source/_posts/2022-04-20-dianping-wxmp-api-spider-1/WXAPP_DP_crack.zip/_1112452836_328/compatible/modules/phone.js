module.exports = function(e) {
    var n;
    1 === e.length ? wx.makePhoneCall({
        phoneNumber: e[0]
    }) : wx.showActionSheet({
        itemList: e,
        success: function(t) {
            t.cancel || (n = e[t.tapIndex], wx.makePhoneCall({
                phoneNumber: n
            }));
        }
    });
};