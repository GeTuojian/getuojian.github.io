var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/typeof")), r = getApp().bridge.request, t = require("../config/index.js"), i = {};

module.exports = function(a) {
    if (a) {
        var o, s = a.shopId, n = a.shopUuid;
        "object" === (0, e.default)(a) && a.lat && (o = a);
        var u = function(e) {
            wx.openLocation({
                latitude: e.lat,
                longitude: e.lng,
                name: e.shopName,
                address: e.address
            });
        };
        if (o) u(o); else if (n || s) if (i[s] || i[n]) u(i[s] || i[n]); else {
            var d = {};
            n ? d.shopUuid = n : d.shopId = s, a.mtsiReferrer && (d.mtsiReferrer = a.mtsiReferrer);
            var f = t.API.SHOP_MAP;
            r({
                url: t.DOMAIN + f,
                data: d
            }).then(function(e) {
                if (e && 200 == e.statusCode && 200 == e.data.code) {
                    var r = e.data.shopInfo;
                    i = {}, n ? i[n] = r : i[s] = r, u(r);
                }
            }).catch(function(e) {
                console.error("Detail Map", e);
            });
        }
    }
};