var t, e = require("../../lib/owl.js"), o = (t = e) && t.__esModule ? t : {
    default: t
};

var a = require("../../lib/logan.js"), i = require("../../lib/sparrow.js").request.mina, r = require("../../config/index.js"), n = "/wxmapi/uploadformid";

Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        bizType: {
            type: String,
            observer: "_bizTypeChange"
        },
        zIndex: {
            type: Number
        },
        categoryId: {
            type: Number,
            value: null
        }
    },
    data: {},
    ready: function() {},
    methods: {
        formSubmit: function(t) {
            a.log("form表单提交数据==>".concat(JSON.stringify(t.detail)));
            var e = t.detail.formId, r = this.data.bizType || "", d = null === this.data.categoryId ? "" : this.data.categoryId;
            a.log("formId:".concat(e)), a.log("bizType:".concat(r)), a.log("categoryId:".concat(d)), 
            i({
                url: this._getDomain() + n,
                data: {
                    formId: e,
                    bizType: r,
                    categoryId: d
                }
            }).then(function(t) {
                t && t.data && 200 == t.data.code ? a.log("formId上报成功") : (o.default.resource.addApi({
                    name: "formId上报失败",
                    statusCode: t.data.code
                }), a.log("formId上报失败==>".concat(JSON.stringify(t.data))));
            }).catch(function(t) {
                a.log("formId上报异常==>".concat(JSON.stringify(t)));
            });
        },
        _getDomain: function() {
            return r.DOMAIN.indexOf("51ping") > 0 ? "https://m.51ping.com" : "https://m.dianping.com";
        }
    }
});