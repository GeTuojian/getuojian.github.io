var e = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var o = arguments[t];
        for (var r in o) Object.prototype.hasOwnProperty.call(o, r) && (e[r] = o[r]);
    }
    return e;
}, t = require("../../lib/sparrow.js"), o = require("../../lib/sparrow.js").login, r = require("../../lib/sparrow.js").navigation.navigateTo, i = require("../../lib/sparrow.js").request.mina, a = require("../../config/index.js"), n = require("../../lib/sparrow.js").lxmina, s = require("../../lib/logan.js"), d = getApp(), l = "/wxmapi/follow/switchIsSendFlower", u = "/wxmapi/follow/addFollow", c = "/wxmapi/follow/cancelAttention";

Component({
    options: {
        multipleSlots: !0
    },
    externalClasses: [ "my-class" ],
    data: {
        conWidth: 375
    },
    properties: {
        config: {
            type: Object,
            value: {}
        },
        carditem: {
            type: Object,
            value: {}
        },
        cardidx: {
            type: Number
        },
        pageType: {
            type: Number
        },
        cityId: {
            type: Number
        },
        isNearby: {
            value: !1,
            type: Boolean
        }
    },
    attached: function() {
        var e = 690 * wx.getSystemInfoSync().windowWidth / 375;
        this.setData({
            conWidth: e
        });
    },
    moved: function() {},
    detached: function() {},
    methods: {
        preventTap: function(e) {},
        addFollow: function(e) {
            var t = this.data.carditem, o = e.currentTarget.dataset.addFollow || !1, r = o ? a.DOMAIN + u : a.DOMAIN + c;
            if (t.user && t.user.userId) {
                var i = {
                    friendUserId: t.user.userId,
                    source: "SMP"
                };
                if (o) this.addFollowFn(e, r, i, o); else {
                    i = {
                        friendUserId: t.user.userId,
                        friendRelationType: 1
                    };
                    var n = this;
                    wx.showModal({
                        content: "确定不再关注TA吗？",
                        success: function(t) {
                            t.confirm && n.addFollowFn(e, r, i, o);
                        }
                    });
                }
            }
        },
        addFollowFn: function(e, t, r, a) {
            var n = this, d = this.data.carditem, l = this.data.pageType;
            o.ensure().then(function(e) {
                s.log("[card]addfollowloginensure:" + JSON.stringify(e)), i({
                    url: t,
                    data: r,
                    method: "GET"
                }).then(function(e) {
                    if ((e && e.data ? e.data : {}).result) {
                        a = a && 5 === l ? "temp" : a, d.user.isFollow = a;
                        var t = a ? "关注成功" : "取消关注成功";
                        wx.showToast({
                            icon: "none",
                            title: t,
                            duration: 3e3
                        }), n.triggerEvent("followuser", {
                            isFollow: a,
                            userId: d.user.userId
                        }), n.setData({
                            carditem: d
                        });
                    } else {
                        var o = a ? "关注失败，请稍后再试" : "取消关注失败，请稍后再试";
                        wx.showToast({
                            icon: "none",
                            title: o,
                            duration: 3e3
                        });
                    }
                }).catch(function(e) {
                    s.log("[card]addfollowerr:" + JSON.stringify(e));
                    var t = a ? "关注失败，请稍后再试" : "取消关注失败，请稍后再试";
                    wx.showToast({
                        icon: "none",
                        title: t,
                        duration: 3e3
                    });
                });
            }).catch(function(e) {
                wx.showToast({
                    icon: "none",
                    title: "登录失败，请稍后再试",
                    duration: 3e3
                }), s.log("[card]addfollowlogin err:" + JSON.stringify(e));
            });
        },
        doSendFlower: function() {
            var e = this;
            if (!this.isFlowering) {
                n.moduleView("b_nu733p6m"), this.isFlowering = !0;
                var t = this.data.carditem;
                o.ensure().then(function() {
                    d.getFigure().then(function(o) {
                        s.log("[card-".concat(t.noteId, "]doSendFlower: ").concat(o)), i({
                            url: a.DOMAIN + l,
                            method: "POST",
                            header: {
                                "Content-Type": "application/x-www-form-urlencoded"
                            },
                            data: {
                                cx: o,
                                bizType: t.bizType || "",
                                isSendFlower: !t.isSendFlower,
                                mainId: t.noteId,
                                originUserId: t.user ? t.user.userId : t.anonymous && t.anonymousUser && t.anonymousUser.userId ? t.anonymousUser.userId : ""
                            }
                        }).then(function(o) {
                            e.isFlowering = !1;
                            var r = o && o.data ? o.data : {}, i = r.loginUser || {};
                            if (r && r.result) {
                                if (t.flowerCount = t.flowerCount + (t.isSendFlower ? -1 : 1), t.isSendFlower = !t.isSendFlower, 
                                t.flowerUsers || (t.flowerUsers = []), t.isSendFlower) t.flowerUsers.unshift({
                                    userFace: i.userFace || "",
                                    userId: i.userId
                                }); else {
                                    for (var a = t.flowerUsers, n = 0; n < 3; n++) if (i.userId === a[n].userId) {
                                        a.splice(n, 1);
                                        break;
                                    }
                                    t.flowerUsers = a;
                                }
                                e.setData({
                                    carditem: t
                                });
                            } else wx.showToast({
                                icon: "none",
                                title: "点赞失败，请稍后再试",
                                duration: 3e3
                            });
                        }).catch(function(o) {
                            e.isFlowering = !1, s.log("[card-".concat(t.noteId, "]doSendFlower err: ").concat(o));
                        });
                    }).catch(function() {
                        wx.showToast({
                            icon: "none",
                            title: "点赞失败，稍后再试",
                            duration: 3e3
                        });
                    });
                }).catch(function(e) {
                    wx.showToast({
                        icon: "none",
                        title: "登录失败，请稍后再试",
                        duration: 3e3
                    }), s.log("[card]doSendFlowerlogin err:" + JSON.stringify(e));
                });
            }
        },
        onPhotoTap: function(e) {
            var t = this.data.carditem.pics;
            if (t && t.length) {
                var o = t.map(function(e) {
                    return e.url;
                }), r = e.currentTarget.dataset.itemIndex;
                wx.previewImage({
                    current: o[r],
                    urls: o
                }), this.triggerEvent("cardpreview", {
                    cardidx: this.data.cardidx,
                    index: r
                });
            }
        },
        onVideoPreviewTap: function(e) {
            var t = this.data.carditem;
            t.video && t.video.url ? r({
                url: "/packages/video-preview/pages/index/index?video=" + t.video.url
            }) : wx.showToast({
                icon: "none",
                title: "预览失败，请稍后再试",
                duration: 3e3
            });
        },
        gotoShop: function(t) {
            var o = (this.data && this.data.carditem).target;
            if (n.moduleView("b_3y47vdqx"), o) if ("internal" === o.type) {
                var i = o.url;
                i && r({
                    url: i
                });
            } else {
                var a = o.externalInfo;
                wx.navigateToMiniProgram(e({}, a));
            }
            n.moduleClick("b_51hc4oo9");
        },
        gotoNote: function(e) {
            var t = this.data.carditem, o = t.noteId, i = t.bizType, a = e.currentTarget.dataset.comment;
            o && (n.moduleView("b_5u4ctkbr"), r({
                url: "/packages/notedetail/pages/index/index?noteId=" + o + "&bizType=" + i + (a ? "&comment=true" : "") + (this.data.isNearby ? "&isNearby=true" : "&cityId=" + this.data.cityId) + "&rMode=0&bType=" + i + "&fType=" + {
                    110: 29,
                    10: 1,
                    40: 3
                }[i + ""]
            }));
        },
        gotoUser: function() {
            var e = this.data.carditem.user, t = "/pages/mine-center/mine-center?userId=" + e.userId;
            if (4 !== this.data.pageType && e && e.userId) {
                if (5 === this.data.pageType) {
                    if (!this.data.config.gotoPersonal) return;
                    t = "/packages/user/pages/personal/personal?offuserId=" + e.userId;
                }
                r({
                    url: t
                });
            }
        },
        goToContributionPage: function() {
            var e = this.data.carditem;
            e && (e.isMaster ? e.target && t.navigation.navigateTo({
                url: e.target
            }) : e.toast && wx.showToast({
                title: e.toast,
                icon: "none"
            }));
        }
    }
});