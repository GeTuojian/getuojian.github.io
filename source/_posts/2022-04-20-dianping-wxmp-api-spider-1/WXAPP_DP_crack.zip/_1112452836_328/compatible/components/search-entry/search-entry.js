Component({
    properties: {
        keyword: {
            type: String,
            value: ""
        },
        isNew: {
            type: Boolean,
            value: !1
        }
    },
    methods: {
        onSearchShow: function(e) {
            var r = e.currentTarget.dataset.keyword;
            console.log("search-entry keyword: ", r), this.triggerEvent("searchshow", {
                keyword: r
            });
        }
    }
});