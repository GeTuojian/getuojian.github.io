var t = Object.assign || function(t) {
    for (var e = 1; e < arguments.length; e++) {
        var a = arguments[e];
        for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (t[r] = a[r]);
    }
    return t;
}, e = require("../../../compatible/lib/sparrow.js"), a = require("../../config/business.js").DEFAULT_PIC;

Component({
    properties: {
        card: {
            type: Object
        },
        active: {
            type: Boolean
        },
        needbottom: {
            type: Boolean,
            value: !0
        },
        needborderbottom: {
            type: Boolean,
            value: !1
        },
        lxdata: {
            type: Object,
            value: {}
        }
    },
    data: {
        defaultPic: a,
        lxData: {
            custom: {}
        }
    },
    methods: {
        tapGroupCard: function(t) {
            console.log("trigger event tapGroupCard");
            var e = t.currentTarget.dataset.url, a = t.currentTarget.dataset.cardId, r = t.currentTarget.dataset.groupId;
            this.triggerEvent("mygrouptap", {
                url: e,
                cardId: a,
                groupId: r,
                index: this.data.idx
            });
        },
        promoTap: function(t) {
            var e = t.detail, a = e.cardId, r = e.url, o = e.shopData, s = e.index, d = e.subindex, i = e.liststart;
            this.triggerEvent("promotap", {
                shopUuid: a,
                shopData: o,
                url: r,
                subindex: d,
                index: s,
                liststart: i
            });
        },
        cardIntersectionObserver: function() {
            var a = this, r = this.observer;
            try {
                r || (r = this.createIntersectionObserver().relativeToViewport(), this.observer = r), 
                this.haveObserved || (r.observe(".shop-container", function(r) {
                    if (r && r.boundingClientRect.top > 0 && !a.haveSendMV) {
                        a.haveSendMV = !0;
                        var o = a.data.card.shopInfo, s = t({}, a.data.lxdata, {
                            custom: t({}, a.data.lxdata && a.data.lxdata.custom, {
                                shop_id: o.shopUuid || o.shop_uuid
                            }),
                            index: a.data.card.shopInfo.shopIndex,
                            start: a.data.card.shopInfo.listStart
                        });
                        a.setData({
                            lxData: s
                        }), e.lxmina.moduleView(a.data.lxdata.cardView, t({}, s));
                    }
                }), this.haveObserved = !0);
            } catch (t) {
                console.log("Observer 失败:", t);
            }
        }
    },
    ready: function() {
        1 === this.data.card.type && this.cardIntersectionObserver();
    }
});