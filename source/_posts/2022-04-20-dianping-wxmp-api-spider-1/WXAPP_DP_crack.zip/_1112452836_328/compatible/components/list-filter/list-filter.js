Component({
    properties: {
        selector: {
            type: Array,
            value: [],
            observer: function(e) {
                this.data && e.length && (this.data.showmetro && 0 === this.data.firstId || this.data.activeMetro ? this.computeMetroSelector(!0) : this.computeSelector(this.data.firstId));
            }
        },
        trigger: {
            type: Array,
            value: []
        },
        hasmetro: {
            type: Boolean,
            value: !1
        },
        showmetro: {
            type: Boolean,
            value: !1
        },
        isNew: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        firstTap: !0,
        activeIndex: -1,
        isSearching: !1,
        trigger: [ {
            id: "0",
            name: "全部地区",
            parentId: "0"
        }, {
            id: "0",
            name: "全部分类",
            parentId: "0"
        }, {
            id: "0",
            name: "按时间"
        }, {
            id: "0",
            name: "筛选"
        } ],
        mainSelector: [],
        subSelector: [],
        choiceSelectors: [],
        activeSubSelector: {},
        activeMainSelectorId: 0,
        INDEX_REGION: 0,
        INDEX_CATEGORY: 1,
        INDEX_SORT: 2,
        INDEX_CHOICE: 3,
        INDEX_METRO: 4,
        customeChoice: [],
        mainToView: 0,
        subToView: 0,
        activeMetro: !1
    },
    methods: {
        parseSelector: function(e, t, i) {
            if (e && e.length) {
                for (var a = {
                    mainSelector: [],
                    subSelector: []
                }, r = 0; r < e.length; r++) {
                    var c = e[r];
                    if (t == this.data.INDEX_SORT) return {
                        subSelector: e
                    };
                    0 === c.parentId || null == c.parentId ? a.mainSelector.push(c) : c.parentId == i && 0 != c.categoryId && a.subSelector.push(c);
                }
                return a;
            }
        },
        parseChoice: function(e) {
            var t = [];
            return e && e.length && e.map(function(e) {
                var i = e.filters;
                i && i.length && i.map(function(e) {
                    !0 === e.selected && e.id && t.push(e.id);
                });
            }), t;
        },
        findSelectorById: function(e) {
            var t = this.data.selector[this.data.activeIndex];
            return (t = t.filter(function(t) {
                return t.id == e;
            }))[0];
        },
        handleTrigger: function(e) {
            var t = this;
            this.setData({
                firstId: e.currentTarget.dataset.index,
                activeMetro: !1
            }, function() {
                t.triggerEvent("handletrigger", {
                    setSelector: !0
                });
            });
        },
        computeSelector: function(e) {
            var t, i, a, r = this, c = parseInt(e), o = {}, s = [], n = this.data.trigger, h = this.data.customeChoice || [];
            if (c === this.data.activeIndex) t = -1; else {
                t = c;
                var d = "" + ((i = n[c]) && i.id) || i && i.type;
                i && void 0 !== d && (a = t === this.data.INDEX_CATEGORY && 0 == i.parentId ? d : i.parentId || 0, 
                t !== this.data.INDEX_CHOICE ? o = this.parseSelector(this.data.selector[c], t, a) : (s = this.data.selector[c], 
                h = this.parseChoice(s)));
            }
            this.setData({
                activeIndex: t,
                activeSubSelector: i || {},
                activeMainSelectorId: a || this.data.activeMainSelectorId || 0,
                mainSelector: o && o.mainSelector || [],
                subSelector: o && o.subSelector || [],
                choiceSelectors: s || [],
                customeChoice: h || [],
                mainToView: a ? "main-".concat(a) : "main-0",
                subToView: i && i.id ? "sub-".concat(i.id) : "sub-0"
            }, function() {
                r.triggerEvent("handletrigger", {
                    activeIndex: t
                });
            });
        },
        handleMainSelector: function(e) {
            var t = parseInt(e.currentTarget.dataset.itemid), i = [];
            try {
                i = (i = this.data.selector[this.data.activeIndex]) && i.filter(function(e) {
                    return e.parentId == t;
                });
            } catch (e) {
                console.log("list page => handle main selector error: ", e);
            }
            if (0 === i.length) {
                var a = this.findSelectorById(t);
                this.updateSelector(a, 0);
            }
            this.setData({
                activeMainSelectorId: t,
                subSelector: i
            });
        },
        handleSubSelector: function(e) {
            try {
                var t = e.currentTarget.dataset.itemid, i = e.currentTarget.dataset.parentid || 0, a = this.data.selector[this.data.activeIndex], r = a && a.filter(function(e) {
                    return e.id == t;
                });
                this.updateSelector(r[0], i);
            } catch (e) {
                console.log("handle sub selector error: ", e);
            }
        },
        updateSelector: function(e, t) {
            var i = this.data.trigger, a = this.data.activeIndex;
            this.data.showmetro ? i[0] = e : i[a] = e, this.setData({
                activeSubSelector: e,
                trigger: i
            }), this.triggerEvent("filterlist", {
                activeIndex: a,
                selectorId: e.id,
                parentId: t
            }), this.hideTrigger();
        },
        hideTrigger: function() {
            this.triggerEvent("handletrigger", {
                activeIndex: -1
            }), this.setData({
                activeIndex: -1
            });
        },
        tapChoice: function(e) {
            var t = e.currentTarget.dataset, i = t.name, a = t.choiceid, r = t.ismulti;
            if (i && a) {
                var c = e.currentTarget.dataset.parent, o = this.dealChoice(this.data.choiceSelectors, c, a, r), s = this.parseChoice(o);
                this.setData({
                    customeChoice: s,
                    choiceSelectors: o
                });
            }
        },
        resetChoice: function() {
            var e = this.data.choiceSelectors;
            e && e.length && e.map(function(e) {
                var t = e.filters;
                t && t.length && t.map(function(e) {
                    e.selected = !1;
                });
            }), this.setData({
                customeChoice: [],
                choiceSelectors: e
            });
        },
        dealChoice: function(e, t, i, a) {
            return e && e.length && e.map(function(e) {
                if (e.name === t) {
                    var r = e.filters;
                    r && r.length && r.map(function(e) {
                        a || e.id !== i && (e.selected = !1), e.id === i && (e.selected = !e.selected);
                    });
                }
            }), e;
        },
        sureChoice: function() {
            var e = this.data.customeChoice;
            console.log("trigger custome choice event", e), this.triggerEvent("surechoice", {
                customeChoice: e
            }), this.hideTrigger();
        },
        preventScroll: function() {},
        openMetro: function() {
            this.data.activeMetro || this.computeMetroSelector(!0);
        },
        closeMetro: function() {
            this.data.activeMetro && this.computeMetroSelector(!1);
        },
        computeMetroSelector: function(e) {
            var t;
            t = e ? 4 : 0;
            var i = this.data.trigger, a = this.data.selector[t], r = [], c = [], o = i[0], s = this.data.showmetro ? o.parentId : a[0].id;
            t !== this.data.INDEX_CHOICE ? a = this.parseSelector(a, t, s) : (r = this.data.selector[3], 
            c = this.parseChoice(r)), this.data.showmetro || (o = a && a.subSelector[0]), this.setData({
                activeSubSelector: o || {},
                activeMainSelectorId: s || this.data.activeMainSelectorId || 0,
                mainSelector: a && a.mainSelector || [],
                subSelector: a && a.subSelector || [],
                activeMetro: e,
                activeIndex: t,
                showmetro: !0,
                mainToView: s ? "main-".concat(s) : "main-0",
                subToView: o && o.id ? "sub-".concat(o.id) : "sub-0",
                choiceSelectors: r || [],
                customeChoice: c || []
            });
        }
    }
});