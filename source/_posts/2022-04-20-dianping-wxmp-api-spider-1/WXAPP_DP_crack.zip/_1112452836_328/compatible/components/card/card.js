var t = Object.assign || function(t) {
    for (var a = 1; a < arguments.length; a++) {
        var e = arguments[a];
        for (var s in e) Object.prototype.hasOwnProperty.call(e, s) && (t[s] = e[s]);
    }
    return t;
}, a = require("../../lib/sparrow.js"), e = require("../../config/business.js").DEFAULT_PIC;

Component({
    properties: {
        shopinfo: {
            type: Object
        },
        showtag: {
            type: Boolean,
            value: !1
        },
        starStyle: {
            type: Object,
            value: {
                width: "26rpx",
                height: "26rpx"
            }
        },
        textStyle: {
            type: Object,
            value: {
                fontSize: "26rpx",
                marginRight: "4rpx"
            }
        },
        lxdata: {
            type: Object,
            value: {}
        }
    },
    data: {
        defaultPic: e,
        ios: !1,
        haveSendMV: {}
    },
    attached: function() {
        var t = getApp().runtimeInfo || new (require("../../../framework/class_define/runtime_info.js"))();
        try {
            t && t.deviceSystem && 0 === t.deviceSystem.toLowerCase().search("ios") && this.setData({
                ios: !0
            });
        } catch (t) {
            console.log("get system error: ", t);
        }
    },
    methods: {
        tapCard: function(e) {
            console.log("trigger event tapCard");
            var s = e.currentTarget.dataset.cardid, i = e.currentTarget.dataset.shopdata, o = e.currentTarget.dataset.scopedatalist;
            this.data.lxdata && this.data.lxdata.cardClick && a.lxmina.moduleClick(this.data.lxdata.cardClick, t({}, this.data.lxdata, {
                index: this.data.shopinfo.shopIndex,
                start: this.data.shopinfo.listStart,
                poi_id: this.data.shopinfo.shopUuid || this.data.shopinfo.shop_uuid
            })), this.triggerEvent("mytap", {
                cardId: s,
                shopData: i,
                scopeDataList: o,
                shopIndex: this.data.shopinfo.shopIndex,
                listStart: this.data.shopinfo.listStart
            }, {
                bubbles: !0,
                composed: !0
            });
        },
        tapPromo: function(e) {
            console.log("trigger event tapPromo");
            var s = e.currentTarget.dataset, i = s.url, o = s.subindex, r = e.currentTarget.dataset.cardid, d = e.currentTarget.dataset.shopdata, n = this.data.shopinfo, h = n.shopIndex, p = n.listStart;
            this.data.lxdata && this.data.lxdata.promoClick && a.lxmina.moduleClick(this.data.lxdata.promoClick, t({}, this.data.lxdata, {
                index: this.data.shopinfo.shopIndex,
                start: this.data.shopinfo.listStart,
                sub_index: o,
                poi_id: this.data.shopinfo.shopUuid || this.data.shopinfo.shop_uuid
            })), this.triggerEvent("promotap", {
                cardId: r,
                shopData: d,
                url: i,
                subindex: o,
                index: h,
                liststart: p
            });
        },
        cardIntersectionObserver: function() {
            var e = this, s = this.observer;
            try {
                s || (s = this.createIntersectionObserver({
                    observeAll: !0
                }).relativeToViewport(), this.observer = s), this.haveObserved || (s.observe(".promoListItem", function(s) {
                    var i = s.dataset.subindex, o = e.data.haveSendMV;
                    s && s.boundingClientRect.top > 0 && !o[i] && (o[i] = !0, e.setData({
                        haveSendMV: o
                    }), e.data.lxdata && e.data.lxdata.promoView && a.lxmina.moduleView(e.data.lxdata.promoView, t({}, e.data.lxdata, {
                        index: e.data.shopinfo.shopIndex,
                        start: e.data.shopinfo.listStart,
                        sub_index: i,
                        poi_id: e.data.shopinfo.shopUuid || e.data.shopinfo.shop_uuid
                    })));
                }), this.haveObserved = !0);
            } catch (t) {
                console.log("Observer 失败:", t);
            }
        }
    },
    ready: function() {
        this.cardIntersectionObserver();
    }
});