var e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/helpers/defineProperty")), t = require("../../lib/sparrow.js"), a = require("../../config/index.js"), r = require("../../utils/lx_wrap.js"), n = require("../../../common/components/midas/midas.outlet.js");

Component({
    properties: {
        dealGroupId: {
            type: null,
            observer: "_dealGroupIdChange"
        },
        slotId: {
            type: null
        },
        shopId: {
            type: null
        },
        shopUuid: {
            type: null
        },
        shopCityId: {
            type: null
        },
        shopType: {
            type: null
        },
        categoryIds: {
            type: null
        },
        needStarAd: {
            type: null
        }
    },
    data: {
        moduleTitle: "",
        adMark: "",
        adItems: [],
        defaultImgUrl: "https://p1.meituan.net/emidasmanage/7191b02a0f5f012592eed992a29c37324108.png%40672w_330h_2e_1c_1l_85q%7Cwatermark%3D0",
        imgClass: "width:160rpx;height:160rpx;",
        starImgClass: "width:250rpx;height:250rpx;"
    },
    methods: {
        _dealGroupIdChange: function(e) {
            e && this.getData();
        },
        triggerScroll: function() {
            n.triggerScroll();
        },
        getData: function() {
            var n = this, d = a.VERSION, i = getApp().bridge.getLbsSync(), s = getApp().bridge.getCitySync(), o = getApp().bridge.getIdSync().openId, p = r.get("lxcuid") || "", l = wx.getSystemInfoSync(), c = l.system.split(" ")[0] || "android", u = l.system.split(" ")[1], g = !0, I = {
                openid: o,
                cuid: p,
                cityId: s && s.cityId ? s.cityId : 0,
                lat: i && i.latitude ? i.latitude : 0,
                lng: i && i.longitude ? i.longitude : 0,
                appType: "DP_MAIN_WEIXIN",
                appVersion: d,
                osType: c.toUpperCase(),
                osVersion: u,
                ext: JSON.stringify({
                    needStarAd: n.data.needStarAd || !1
                })
            };
            [ "slotId", "dealGroupId", "shopId", "shopUuid", "shopCityId", "shopType", "categoryIds" ].forEach(function(t) {
                ("slotId" === t && !n.data[t] || "dealGroupId" === t && !n.data[t]) && (console.warn("缺少必填参数".concat(t)), 
                g = !1), n.data[t] && Object.assign(I, (0, e.default)({}, t, n.data[t]));
            }), g && (wx.getNetworkType({
                success: function(e) {
                    Object.assign(I, {
                        connectionType: e.networkType.toUpperCase()
                    });
                }
            }), t.request.custom({
                url: a.MAPI_DOMAIN + "/baymax/getSlotAds",
                data: I
            }).then(function(e) {
                e.data && e.data.ads && e.data.ads.length > 0 ? (e.data.ads[0].adItems && e.data.ads[0].adItems.length > 0 && e.data.ads[0].adItems.forEach(function(e) {
                    e.jumpLink = e.creative.newLandingPage, e.creative.starAd || (parseInt(e.creative.currentPrice) % 1 == 0 && (e.creative.currentPrice = parseInt(e.creative.currentPrice)), 
                    parseInt(e.creative.marketPrice) % 1 == 0 && (e.creative.marketPrice = parseInt(e.creative.marketPrice)));
                }), n.setData(e.data.ads[0])) : console.warn("推荐广告模块 获取广告数据为空！");
            }).catch(function(e) {
                console.warn(e || "推荐广告模块 获取广告数据失败！");
            }));
        }
    }
});