var e, t, a = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var a = arguments[t];
        for (var i in a) Object.prototype.hasOwnProperty.call(a, i) && (e[i] = a[i]);
    }
    return e;
}, i = require("../../lib/sparrow.js"), n = require("../../config/index.js"), o = require("../../lib/sparrow.js").lxmina, s = (getApp(), 
{
    "pages/index/index": {
        type: 1,
        cacheKey: "dp_index_myminitip_time",
        viewBid: "b_ox9z2s4t",
        clickBid: "b_4fplonic"
    },
    "pages/detail/detail": {
        type: 2,
        cacheKey: "dp_detail_myminitip_time",
        viewBid: "b_bvgxe98r",
        clickBid: "b_30dyb6h8"
    },
    "packages/order/pages/payment/payment": {
        type: 2,
        cacheKey: "dp_pay_myminitip_time",
        viewBid: "b_4d5xruq9",
        clickBid: "b_t5tftz31"
    }
}), c = [ "dp_defaultbubble_times", "dp_myminitipbubble_times" ], r = 0, p = null;

Component({
    properties: {
        pageUrl: {
            type: String,
            value: "",
            observer: "_dataChange"
        },
        hasPopup: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        showModule: !1
    },
    attached: function() {
        r = getApp().bridge.getShowOptions() && getApp().bridge.getShowOptions().scene ? parseInt(getApp().bridge.getShowOptions().scene) : 0;
    },
    methods: {
        _dataChange: function(e, t) {
            var a = this;
            e && ("packages/order/pages/payment/payment" == e && i.event.on("popupClose", function() {
                p = a.setDisappear();
            }), this.checkCache(e) ? this.getSystemInfo().then(function(t) {
                a.checkShow(t, e);
            }) : this.triggerEvent("nominitip"));
        },
        checkCache: function(a) {
            var n = !1, o = s[a], r = o.type, p = o.cacheKey, h = i.cache.getStorageSync(p);
            return e = i.cache.getStorageSync(c[0]) || 0, t = i.cache.getStorageSync(c[1]) || 0, 
            (!h || 2 == r && Date.now() - h >= 864e6 && (e < 3 || t < 3)) && (n = !0), n;
        },
        checkShow: function(c, h) {
            var d = this, u = s[h];
            i.request.custom({
                url: n.DOMAIN + n.API.MYMINI_TIP,
                data: a({}, c, {
                    pageUrl: h,
                    scene: r
                })
            }).then(function(a) {
                if (a && 200 == a.statusCode && a.data && 200 == a.data.code && a.data.canShow) {
                    var n = a.data.bubbleType, s = 0;
                    0 == n && (s = e), 1 == n && (s = t), (1 == u.type || s < 3) && (d.setData({
                        showModule: !0,
                        type: u.type,
                        text: a.data.text || "",
                        navCustom: 1 == u.type && -1 !== i.semver.compare(c.wxversion, "7.0.0")
                    }), 1 == u.type && d.triggerEvent("noscroll", {
                        isMyMiniTip: !0
                    }), d.setTipCache(u, a.data), 2 == u.type && (p = d.setDisappear()), o.moduleView(u.viewBid));
                } else d.setData({
                    showModule: !1
                }), 1 == u.type && d.triggerEvent("nominitip");
            }).catch(function(e) {
                console.log("获取提示数据出错", e);
            });
        },
        setDisappear: function() {
            var e = this;
            return this.data.showModule || this.setData({
                showModule: !0
            }), p && clearTimeout(p), setTimeout(function() {
                e.setData({
                    showModule: !1
                });
            }, 5e3);
        },
        setTipCache: function(a, n) {
            var o = a.type, s = a.cacheKey;
            if (i.cache.setStorage(s, Date.now()), 2 == o) {
                var r = n.bubbleType, p = r ? ++t : ++e;
                i.cache.setStorage(c[r], p);
            }
        },
        getSystemInfo: function() {
            return new Promise(function(e, t) {
                i.wxp.getSystemInfo().then(function(a) {
                    a && a.version && a.platform ? e({
                        wxversion: a.version,
                        system: a.platform
                    }) : t({
                        err: "无相关系统信息"
                    });
                }).catch(function(e) {
                    console.log("获取手机系统信息失败", e), t({
                        err: e
                    });
                });
            });
        },
        closeTap: function() {
            var e = s[this.data.pageUrl];
            this.setData({
                showModule: !1
            }), 1 == e.type && this.triggerEvent("close"), o.moduleClick(e.clickBid);
        }
    }
});