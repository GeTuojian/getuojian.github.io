Component({
    properties: {
        navData: {
            type: Object
        },
        isListPage: {
            type: Boolean
        }
    },
    data: {},
    methods: {},
    ready: function() {}
});