Object.defineProperty(exports, "__esModule", {
    value: !0
});

exports.platformMap = {
    DP_WX_MINI: "dp_wx_mini",
    MT_WX_MINI: "mt_wx_mini"
}, exports.clientTypeMap = {
    dp_wx_mini: 100400,
    mt_wx_mini: 200400
};