var a = require("../../lib/sparrow.js"), t = require("../../lib/logan.js"), i = require("../../config/index.js"), e = "COMMAND-CARD-COMPONENT", n = getApp(), o = "b_dianping_nova_7irvyyqd_mv", s = "b_dianping_nova_r0jmdgal_mv", l = "b_dianping_nova_r0jmdgal_mc", d = "/wxmapi/bonus/download";

Component({
    properties: {
        popData: {
            type: Object,
            observer: "_popDataChange"
        },
        barQuery: {
            type: Object
        }
    },
    data: {
        popType: "",
        showBig: !1,
        smallImgUrl: ""
    },
    ready: function() {
        this.init();
    },
    methods: {
        _popDataChange: function(a) {
            var t = a || {}, i = t.smallImgUrl, e = t.showBig, n = t.cardData;
            i && e && this.setData({
                smallImgUrl: i,
                showBig: e,
                cardData: JSON.stringify(n)
            });
        },
        fetchConfig: function(s, l) {
            var r = this, c = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
            this.pageRoute = l;
            var g = a.geo.getCitySync();
            t.log("".concat(e, ": 获取引导app下载信息"));
            var p = c || {}, h = p.type, u = p.smallImgStyle, m = {
                pageRoute: l,
                scene: s,
                type: h,
                cityId: g && g.cityId
            }, v = this.data.barQuery && (this.data.barQuery.shopId || this.data.barQuery.shopUuid), y = this.data.barQuery && this.data.barQuery.dealGroupId;
            return v && (m.shopUuid = v), y && (m.dealGroupId = y), getCurrentPages() && 1 == getCurrentPages().length && (m.isDirect = 1), 
            a.request.mina({
                url: i.DOMAIN + d,
                data: m
            }).then(function(i) {
                if (i && i.data && 200 === i.data.code && i.data.popData) {
                    var s = i && i.data && i.data.popData, l = s.lxBid || "", d = s.isActivity || "pop_activity" === s.popType || !1;
                    if (s && s.smallImgUrl) {
                        var c = u || s.smallImgStyle, g = s.smallImgStyle, p = s.type;
                        console.log("fetch, ".concat(p, "红包渲染ready"));
                        var h = !1, v = n.runtimeInfo || new (require("../../../framework/class_define/runtime_info.js"))();
                        v.deviceModel && -1 != v.deviceModel.indexOf("iPhone X") && (h = !0);
                        var y = {
                            isIpx: h,
                            isActivity: d,
                            smallImgStyle: c,
                            imgText: g,
                            type: p,
                            cardData: JSON.stringify(s.cardData || {}),
                            smallImgUrl: s.smallImgUrl,
                            popData: s,
                            bonusLxBid: l
                        };
                        if (d) {
                            var f = r.needPopActivity();
                            y.bigImgUrl = m.bigImgUrl, y.link = s.link, y.showBig = f, y.cardData = JSON.stringify(s && s.cardData);
                        }
                        r.setData(y, function() {
                            l && a.lxmina.moduleView(r.data.showBig ? o : l.mvBid, l.valLab);
                        });
                    } else r.setData({
                        showBig: !1,
                        smallImgUrl: ""
                    }), t.log("".concat(e, ":无引导app下载信息===>").concat(JSON.stringify(i.data)));
                } else r.setData({
                    showBig: !1,
                    smallImgUrl: ""
                }), t.log("".concat(e, ":无引导app下载信息===>").concat(JSON.stringify(i.data)));
            }).catch(function(a) {
                r.setData({
                    showBig: !1,
                    smallImgUrl: ""
                }), t.log("获取引导app下载信息err:".concat(JSON.stringify(a)));
            });
        },
        onMiniTap: function() {
            this.data.link ? (a.lxmina.moduleClick(l), a.navigation.navigateTo({
                url: this.data.link
            })) : (this.setData({
                showBig: !0
            }), this.triggerEvent("noscroll"), a.lxmina.moduleView(o, this.data.bonusLxBid && this.data.bonusLxBid.valLab)), 
            this.data.bonusLxBid && this.data.bonusLxBid.mcBid && a.lxmina.moduleClick(this.data.bonusLxBid.mcBid, this.data.bonusLxBid.valLab);
        },
        onActivityTap: function() {
            this.data.link && a.navigation.navigateTo({
                url: this.data.link
            }), this.setData({
                showBig: !1
            }), this.triggerEvent("close"), a.lxmina.moduleClick("b_dianping_nova_7irvyyqd_mc", this.data.bonusLxBid && this.data.bonusLxBid.valLab || "");
        },
        needPopRedPocket: function(t) {
            var i = !1;
            if (t) {
                var e = a.cache.getStorageSync("dp_wallet_day");
                if (!e) return this.updateWalletPopDayCache(), !0;
                var n = new Date().getTime();
                (i = this.calcPop(n, e)) && this.updateWalletPopDayCache();
            }
            return i;
        },
        updateWalletPopDayCache: function() {
            var t = Date.now();
            a.cache.setStorage("dp_wallet_day", t);
        },
        onCloseTap: function(t) {
            console.log("<command-card> closeBtnTap", t), this.setData({
                showBig: !1
            }), this.triggerEvent("close", t), this.triggerEvent("closeBtnTap", t), a.lxmina.moduleClick("b_dianping_nova_y3lf4rqx_mc", this.data.bonusLxBid && this.data.bonusLxBid.valLab), 
            this.data.bonusLxBid && a.lxmina.moduleView(this.data.bonusLxBid.mvBid, this.data.bonusLxBid && this.data.bonusLxBid.valLab);
        },
        cardBtnTap: function(t) {
            console.log("<command-card> cardBtnTap", t), this.setData({
                showBig: !1
            }), wx.setClipboardData({
                data: this.data.popData.commandText
            }), this.triggerEvent("close", t), this.triggerEvent("cardBtnTap", t), a.lxmina.moduleClick("b_dianping_nova_7irvyyqd_mc", {
                activity_id: this.data.popData.activityId
            });
        },
        calcPop: function(a, t) {
            return parseInt((a - t) / 864e5) - 2 > 0;
        },
        needPopActivity: function() {
            var t, i = a.cache.getStorageSync("dp_index_activity_pop_day");
            if (!i) return this.updateActivityPopDayCache(), this.triggerEvent("noscroll"), 
            !0;
            var e = new Date().getTime();
            return (t = this.calcAcPop(e, i)) && (this.updateActivityPopDayCache(), this.triggerEvent("noscroll")), 
            t;
        },
        handleContact: function() {
            this.setData({
                showBig: !1
            }), console.log("hongbao 携带card信息", this.data.cardData), this.triggerEvent("close"), 
            a.lxmina.moduleClick("b_dianping_nova_7irvyyqd_mc", this.data.bonusLxBid && this.data.bonusLxBid.valLab);
        },
        updateActivityPopDayCache: function() {
            var t = Date.now();
            a.cache.setStorage("dp_index_activity_pop_day", t);
        },
        calcAcPop: function(a, t) {
            return parseInt((a - t) / 864e5) > 0;
        },
        init: function() {
            var i = this, e = getApp().bridge.getShowOptions() && getApp().bridge.getShowOptions().scene ? parseInt(getApp().bridge.getShowOptions().scene) : null, n = a.pageUtil.getCurrentPage() && a.pageUtil.getCurrentPage().__route__;
            a.login.niceToHave().then(function() {
                i.pageRoute = n;
                var t = i.data.popData || {}, l = t.smallImgUrl, d = t.showBig, r = t.type, c = t.imgText, g = t.cardData, p = t.smallImgStyle, h = t.button_content;
                if (l) {
                    var u = i.data.popData && i.data.popData.needPop || i.needPopRedPocket(d);
                    console.log("".concat(r, "红包渲染ready")), i.setData({
                        type: r,
                        imgText: c,
                        cardData: JSON.stringify(g),
                        showBig: u,
                        smallImgUrl: l,
                        smallImgStyle: p
                    }, function() {
                        a.lxmina.moduleView(o, {
                            activity_id: i.data.popData.activityId
                        });
                    });
                } else i.fetchConfig(e, n, i.data.popData);
                h && -1 !== h.indexOf("only-nav") && i.setData({
                    link: i.data.popData.link
                }, function() {
                    a.lxmina.moduleView(s);
                });
            }).catch(function(a) {
                i.fetchConfig(e, n), t.log("静默登录失败" + JSON.stringify(a));
            });
        }
    }
});