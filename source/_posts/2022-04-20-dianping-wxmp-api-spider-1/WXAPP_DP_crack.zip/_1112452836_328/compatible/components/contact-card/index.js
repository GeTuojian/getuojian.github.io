var a, t = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/helpers/typeof")), e = require("../../lib/sparrow.js"), o = require("../../lib/logan.js"), i = (a = o) && a.__esModule ? a : {
    default: a
};

var n = "b_dianping_nova_zra9qt87_mc", s = "b_dianping_nova_bqp6fjqw_mc", r = "b_dianping_nova_nrlckqxr_mc", d = "b_dianping_nova_8b7tmpt1_mv", l = "b_dianping_nova_8r7tvr48_mv", p = "b_dianping_nova_8r7tvr48_mc";

Component({
    properties: {
        lxData: {
            type: Object
        },
        gotoApp: {
            type: Boolean,
            observer: "_gotoAppChange"
        },
        cardData: {
            type: Object,
            observer: "_cardDataChange"
        }
    },
    methods: {
        _gotoAppChange: function(a, t) {
            if (a) {
                var o = this.needShowPop();
                this.triggerEvent("showpop", {
                    showPop: o
                }), o && e.lxmina.moduleView(d, this.data.lxData);
            }
        },
        _cardDataChange: function(a) {
            if (a && a.popData && a.cardData) {
                this.lxData = Object.assign({}, this.data.lxData, a.cardData.valLab || a.popData.valLab || {});
                var o = this.dealPopData(this.data.cardData.popData);
                Date.now() > 1577807999e3 && (o.side = null), this.setData({
                    showPop: a.showPop,
                    popData: o,
                    _cardData: "object" == (0, t.default)(this.data.cardData.cardData) ? JSON.stringify(this.data.cardData.cardData) : this.data.cardData.cardData
                }), a.showPop && e.lxmina.moduleView(d, this.lxData), a.popData.side && e.lxmina.moduleView(l, this.lxData);
            }
        },
        handleContact: function(a) {
            console.log("abtest 携带card信息", this.data._cardData), this.setData({
                showPop: !1
            }), e.lxmina.moduleClick(s, this.lxData), i.default.log("gotoContact, path: ".concat(JSON.stringify(a.path)));
        },
        dealPopData: function(a) {
            var t = a.title, e = a.subtitle;
            return "string" == typeof t && (t = [ {
                text: t
            } ]), "string" == typeof e && (e = {
                text: e
            }), a.title = t, a.subtitle = e, a.img = a.img || "https://p0.meituan.net/scarlett/dfeb53c2b0902113fc200fa000f8e6a2826711.gif", 
            a.shareImg = a.shareImg || "https://p0.meituan.net/scarlett/49a0fd8564ca1dc8b02f3690b2be6bd212606.png", 
            a;
        },
        close: function() {
            e.lxmina.moduleClick(n, this.lxData), this.setData({
                showPop: !1
            }), i.default.log("Custom-Card close");
        },
        refuseTap: function() {
            var a = this.data.popData;
            if (e.lxmina.moduleClick(r, this.lxData), a && a.silentTime) {
                this.triggerEvent("showpop", {
                    showPop: !1,
                    gotoMina: !0
                });
                var t = Date.now();
                this.setData({
                    showPop: !1
                }), e.cache.setStorage("dp_contact_card_day", {
                    hasRefused: !0,
                    addTime: t
                });
            }
        },
        openPop: function() {
            this.setData({
                showPop: !0
            }), e.lxmina.moduleView(d, this.lxData), e.lxmina.moduleClick(p, this.lxData);
        },
        needShowPop: function() {
            var a = !0, t = e.cache.getStorageSync("dp_contact_card_day");
            t && t.hasRefused && t.addTime && (Math.floor((Date.now() - t.addTime) / 1728e5) < 1 && (a = !1));
            return console.log("是否出弹窗", a), a;
        }
    }
});