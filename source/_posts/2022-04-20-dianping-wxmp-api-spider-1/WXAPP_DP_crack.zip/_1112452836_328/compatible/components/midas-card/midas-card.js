var t = Object.assign || function(t) {
    for (var a = 1; a < arguments.length; a++) {
        var o = arguments[a];
        for (var e in o) Object.prototype.hasOwnProperty.call(o, e) && (t[e] = o[e]);
    }
    return t;
}, a = require("../../lib/sparrow.js"), o = require("../../config/business.js").DEFAULT_PIC;

Component({
    properties: {
        card: {
            type: Object
        },
        needborderbottom: {
            type: Boolean
        },
        idx: {
            type: Number
        },
        needbottom: {
            type: Boolean,
            value: !0
        },
        showtag: {
            type: Boolean,
            value: !0
        },
        lxdata: {
            type: Object,
            value: {}
        }
    },
    data: {
        defaultPic: o,
        env: "product" === a.env.get() ? "product" : "beta",
        tapPromo: !1,
        lxData: {
            custom: {}
        },
        extraInfo: ""
    },
    methods: {
        midasCB: function(t) {
            if (!this.data.tapPromo) {
                console.log("trigger midas callback function"), this.triggerEvent("midascb", {
                    shopIndex: this.data.card.shopInfo.shopIndex,
                    listStart: this.data.card.shopInfo.listStart,
                    shopUuid: t.detail
                });
                var o = t.currentTarget.dataset.url || "/pages/detail/detail?shopUuid=".concat(t.detail), e = this.data.card;
                try {
                    var s = JSON.parse(e.shopInfo && e.shopInfo.shopStyle) || {}, i = e.shopInfo && e.shopInfo.scopeDataList;
                    o && (o += "&from=list&shopStyle=".concat(s.picMode, "&scopeDataList=").concat(i), 
                    wx.setStorage({
                        key: "dp_shop",
                        data: this.data.card,
                        complete: function() {
                            a.navigation.navigateTo({
                                url: o
                            });
                        }
                    }));
                } catch (t) {
                    a.navigation.navigateTo({
                        url: o
                    });
                }
            }
        },
        promoTap: function(t) {
            this.setData({
                tapPromo: !0
            });
            var a = t.detail, o = a.cardId, e = a.url, s = a.shopData, i = a.index, r = a.subindex, n = a.liststart;
            this.triggerEvent("promotap", {
                shopUuid: o,
                shopData: s,
                url: e,
                subindex: r,
                index: i,
                liststart: n
            });
        },
        catchTap: function() {}
    },
    attached: function() {
        if (1 === this.data.card.type) {
            var a = this.data.card.shopInfo, o = t({}, this.data.lxdata, {
                custom: t({}, this.data.lxdata && this.data.lxdata.custom, {
                    shop_id: a.shopUuid || a.shop_uuid
                }),
                index: a.shopIndex,
                start: a.listStart
            }), e = "lat=".concat(a.myLat, "&lng=").concat(a.myLng);
            this.setData({
                lxData: o,
                extraInfo: e
            });
        }
    }
});