module.exports = {
    setApp: function(r) {
        r.env.register(30005, function(r, e) {
            if (0 === e.errorCode && e.serverData) {
                var o = e.serverData.data;
                o ? (void 0 !== o.errorCode && (e.errorCode = o.errorCode), void 0 !== o.data && (e.data = o.data), 
                o.hasOwnProperty("resultCode") ? 200 === o.resultCode ? e.errorCode = 0 : e.errorCode = 1400 : o.hasOwnProperty("code") && (200 === o.code || 0 === o.code ? e.errorCode = 0 : 302 === o.code ? e.errorCode = -5001 : 400 === o.code ? e.errorCode = 15e3 : (o.code, 
                e.errorCode = 1400))) : e.errorCode = 1e3;
            }
        });
    }
};