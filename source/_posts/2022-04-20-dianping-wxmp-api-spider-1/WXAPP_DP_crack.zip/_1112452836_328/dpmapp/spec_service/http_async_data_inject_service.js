function e(e) {
    var a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
    e.taskInfo["_block_" + a] && (e.url = e.taskInfo["_block_" + a].url, e.protocol = e.taskInfo["_block_" + a].protocol, 
    e.callback = e.taskInfo["_block_" + a].callback, getApp().env.notify(30001, e));
}

module.exports = {
    setApp: function(a, r) {
        var o = function(e, a) {
            var r = {
                token: require("../../framework/mtdp_bucket/async_data_provider/token_provider.js"),
                cx: require("../../framework/mtdp_bucket/async_data_provider/cx_provider.js"),
                userid: require("../../framework/mtdp_bucket/async_data_provider/userid_provider.js"),
                cityId: require("../../framework/mtdp_bucket/async_data_provider/cityid_provider.js")
            };
            for (var o in r) r[o].setApp(e, a), r[o].name = o;
            return r.longitude = r.latitude = require("../../framework/mtdp_bucket/async_data_provider/lbs_provider.js"), 
            r.longitude.setApp(e, a), r.longitude.name = "lbs", r.openid = r.openidPlt = require("../../framework/mtdp_bucket/async_data_provider/account_provider.js"), 
            r.openid.setApp(e, a), r.openid.name = "account", r.cityId = r.cityName = r.isOverseasCity = require("../../framework/mtdp_bucket/async_data_provider/cityid_provider.js"), 
            r.cityId.setApp(e, a), r.cityId.name = "city", r.locCityId = r.locCityName = r.locIsOverseasCity = require("../../framework/mtdp_bucket/async_data_provider/loc_cityid_provider.js"), 
            r.locCityId.setApp(e, a), r.locCityId.name = "locCity", r;
        }(a, r);
        a.env.register(30002, function(a, r) {
            if (!r || !r.protocol) return;
            !function(e) {
                e.data || (e.data = {});
                e.taskInfo || (e.taskInfo = {});
                e.protocol && (e.data.token || (e.protocol.needAccessToken ? e.data.token = "!" : e.protocol.betterAccessToken && (e.data.token = "!*")));
                e.header || (e.header = {});
                void 0 === e.header.openidPlt && (e.header.openid = e.header.openidPlt = "!");
            }(r);
            var t, c = [], i = [], n = function(e, a) {
                var r, t = e.data || {}, c = e.header || {}, i = {};
                return Object.keys(t).forEach(function(e) {
                    var c, n, d;
                    switch (t[e]) {
                      case "!":
                        n = 3, d = e;
                        break;

                      case "*":
                        t[e] = void 0, n = 2, c = e;
                        break;

                      case "*!":
                      case "!*":
                        n = 1, c = e;
                    }
                    if (n) {
                        if (!(r = o[e])) return;
                        a.push("data.".concat(e));
                        var s = i[r.name];
                        s || ((s = i[r.name] = {
                            provider: r,
                            mode: n,
                            optionalKeys: null
                        }).provider.scope = [ "data" ]), s.mode < n && (s.mode = n), c && (s.optionalKeys || (s.optionalKeys = []), 
                        s.optionalKeys.push(c)), d && (s.lackedKeys || (s.lackedKeys = []), s.lackedKeys.push(d));
                    }
                }), Object.keys(c).forEach(function(e) {
                    var t, n, d;
                    switch (c[e]) {
                      case "!":
                        n = 3, d = e;
                        break;

                      case "*":
                        c[e] = void 0, n = 2, t = e;
                        break;

                      case "*!":
                      case "!*":
                        n = 1, t = e;
                    }
                    if (n) {
                        if (!(r = o[e])) return;
                        a.push("header.".concat(e));
                        var s = i[r.name];
                        s ? s.provider.scope && s.provider.scope.push("header") : (s = i[r.name] = {
                            provider: r,
                            mode: n,
                            optionalKeys: null
                        }).provider.scope = [ "header" ], s.mode < n && (s.mode = n), t && (s.optionalKeys || (s.optionalKeys = []), 
                        s.optionalKeys.push(t)), d && (s.lackedKeys || (s.lackedKeys = []), s.lackedKeys.push(d));
                    }
                }), i;
            }(r, c);
            if (0 === c.length) return;
            for (var d in n) {
                var s = n[d], p = s.provider, l = s.mode, u = s.lackedKeys;
                switch (l) {
                  case 3:
                    _(p, u, i);
                }
            }
            if (i.length > 0) return r.taskInfo.__lackDataField = i, void function(e) {
                var a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                e.taskInfo["_block_" + a] = {
                    url: e.url,
                    protocol: e.protocol,
                    callback: e.callback
                }, e.url = null, e.callback = null;
            }(r, "lack_data");
            for (var d in n) {
                var v = n[d], k = v.provider, f = v.mode, y = v.optionalKeys;
                switch (f) {
                  case 2:
                    m(k);
                    break;

                  case 1:
                    h(k, y);
                }
            }
            t && getApp().env.notify(30001, t);
            return;
            function _(e, a, o) {
                if (e.isDataPrepared()) {
                    var t = e.getDataSync();
                    b(r, e, t);
                } else {
                    var c = a[0];
                    o.push(e.name);
                    var i = r.data && "!" === r.data[c] || r.header && "!" === r.header[c];
                    e.getDataAsync(function(a) {
                        b(r, e, a, !0);
                    }, !i);
                }
            }
            function m(e, a) {
                if (e.isDataPrepared()) {
                    var o = e.getDataSync();
                    b(r, e, o);
                } else Array.isArray(e.scope) && e.scope.forEach(function(a) {
                    r[a] = r[a] || {}, r[a].hasOwnProperty(e.name) && void 0 === r[a][e.name] && delete r[a][e.name];
                });
            }
            function h(e, a) {
                if (e.isDataPrepared()) {
                    var o = e.getDataSync();
                    b(r, e, o);
                } else t || ((i = new (0, (c = r).__proto__.constructor)()).data = Object.assign({}, c.data), 
                i.callback = c.callback, i.protocol = Object.assign({}, i.protocol), t = i), a.forEach(function(e) {
                    t.data[e] = "!";
                });
                var c, i;
            }
            function b(a, r, o) {
                var t = arguments.length > 3 && void 0 !== arguments[3] && arguments[3], c = r.name, n = r.scope;
                if (Array.isArray(o) || (o = [ {
                    key: c,
                    value: o
                } ]), o.forEach(function(e) {
                    var r = e.key, o = e.value;
                    void 0 === o ? delete a.data[r] : Array.isArray(n) && n.forEach(function(e) {
                        a[e] = a[e] || {}, a[e].hasOwnProperty(r) && (a[e][r] = o), "openid" === r && "header" === e ? a[e].dpid = o : "openid" === r && "data" === e && (a[e].openId = o);
                    });
                }), t) {
                    for (var d = i.indexOf(c); d > -1; ) i.splice(d, 1), d = i.indexOf(c);
                    0 === i.length && e(a, "lack_data");
                }
            }
        });
    }
};