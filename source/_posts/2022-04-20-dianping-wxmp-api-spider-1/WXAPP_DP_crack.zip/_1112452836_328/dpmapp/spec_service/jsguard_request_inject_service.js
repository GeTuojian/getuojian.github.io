var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/typeof"));

module.exports = {
    setApp: function(r) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, u = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null, i = require("../../framework/utils/http_request.js"), n = i.request;
        i.request = function(i) {
            var s, f = !1;
            if (t) {
                var l = (s = i.url.substr(i.url.indexOf("/"), i.url.indexOf("://") + 3)).indexOf("?");
                if (-1 !== l && (s = s.substr(0, l)), -1 !== t.indexOf(s) && (f = !0), !f) for (var a = 0; a < t.length; a++) if ("object" === (0, 
                e.default)(t[a]) && t[a].exec && t[a].exec(i.url)) {
                    f = !0;
                    break;
                }
            } else f = !0;
            if (f && !t && u) {
                if (!s) {
                    var d = (s = i.url.substr(i.url.indexOf("/"), i.url.indexOf("://") + 3)).indexOf("?");
                    -1 !== d && (s = s.substr(0, d));
                }
                if (-1 !== u.indexOf(s) && (f = !1), f) for (var o = 0; o < u.length; o++) if ("object" === (0, 
                e.default)(u[o]) && u[o].exec && u[o].exec(i.url)) {
                    f = !1;
                    break;
                }
            }
            f ? require("../../framework/mtdp_bucket/async_data_provider/cx_provider.js").getDataAsync(function() {
                r.userData.jsguardInstance.request(i, n);
            }) : n(i);
        };
    }
};