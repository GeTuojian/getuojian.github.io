var e = require("../utils/wxp.js");

module.exports = {
    setApp: function(t) {
        setTimeout(function() {
            !function() {
                var n = {
                    actionType: 1,
                    openId: "",
                    net: "",
                    os: "",
                    lng: "",
                    lat: "",
                    coordinate: "WGS-84",
                    addTime: Date.now()
                }, o = [ e.getNetworkType(), e.getSystemInfo(), t.bridge.getIdAsync(), t.bridge.getLbsAsync() ];
                try {
                    Promise.all(o).then(function(e) {
                        var o = function(e) {
                            var t = (e[0] || {}).networkType, n = (e[1] || {}).platform, o = (e[2].openId || {}).openId, i = e[3] || {}, r = i.latitude, s = i.longitude;
                            return {
                                os: /ios/gi.test(n) ? "iOS" : "Android",
                                openId: o,
                                net: t,
                                lng: s,
                                lat: r
                            };
                        }(e), i = o.os, r = o.openId, s = o.net, a = o.lng, d = o.lat;
                        n = Object.assign({}, n, {
                            os: i,
                            openId: r,
                            net: s,
                            lng: a,
                            lat: d
                        }), t.bridge.request({
                            url: t.getConfig().DOMAIN + "/wxmapi/base/lbsreport",
                            data: n,
                            method: "POST"
                        }).then(function(e) {
                            e && e.code;
                        }).catch(function(e) {});
                    });
                } catch (e) {}
            }(), null;
        }, 2e3);
    }
};