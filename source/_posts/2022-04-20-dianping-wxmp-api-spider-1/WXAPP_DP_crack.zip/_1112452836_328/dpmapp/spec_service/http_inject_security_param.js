var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../@babel/runtime/helpers/createClass")), a = require("../../framework/mtdp_bucket/utils/owl_adaptor.js"), i = require("../../framework/mtdp_bucket/utils/lx_adaptor.js"), s = require("../../framework/mtdp_bucket/utils/rohr_adaptor.js"), u = function() {
    function e() {
        (0, t.default)(this, e), this.hasRedirected = !1;
    }
    return (0, r.default)(e, [ {
        key: "setRedirectStatus",
        value: function(e) {
            this.hasRedirected = e;
        }
    }, {
        key: "getRedirectStatus",
        value: function() {
            return this.hasRedirected;
        }
    }, {
        key: "initRedirectStatus",
        value: function() {
            this.hasRedirected = !1;
        }
    } ]), e;
}(), o = new u();

o.RedirectStatusManager = u, module.exports = {
    setApp: function(e, t) {
        e.env.register(30003, function(e, t) {
            t.data && -1 === Object.keys(t.data).indexOf("_token") && (t.data._token = s.r(t.data));
        }), e.env.register(30002, function(e, t) {
            var r = {};
            if ("function" == typeof getCurrentPages) {
                var a = getCurrentPages();
                r = a[a.length - 1] || {};
            }
            r.hasRedirectStatusInited || (o.initRedirectStatus(), r.hasRedirectStatusInited = !0);
            t && t.data && t.data.mtsiReferrer && (t.data = Object.assign({
                optimus_uuid: i.get("lxcuid"),
                optimus_platform: 13,
                optimus_partner: 203,
                optimus_risk_level: 71,
                optimus_code: 10
            }, t.data));
        }), e.env.register(30008, function(e, t) {
            try {
                var r = t.serverData;
                if (r && 200 == r.statusCode) {
                    var a = r.data.loginCode;
                    void 0 !== a && 200 !== a && 100 !== a && (getApp().userData.dpAccessToken = null);
                }
            } catch (e) {}
        }), e.env.register(30008, function(e, t) {
            try {
                var r = t.serverData, i = t.task;
                if (r && 200 == r.statusCode && r.data && 406 === r.data.code) {
                    var s = decodeURIComponent(i.data.mtsiReferrer);
                    s = (0 === s.indexOf("/") ? "" : "/") + s;
                    var u = getApp().tools.url.parseUrl(s).uri;
                    a.error.pushError({
                        sec_category: "【interceptor responseyoda dp-wxapp】",
                        level: "info",
                        category: "ajaxError",
                        resourceUrl: u,
                        content: JSON.stringify(s)
                    }, !0);
                    var o = r.data.customData, n = "packages/mtsi/pages/yoda/yoda", d = getApp() && getApp().redirectStatusMgr;
                    !(d && d.getRedirectStatus(n)) && o && o.requestCode && (d && d.setRedirectStatus(n, !0), 
                    getApp().navigation.redirectTo({
                        url: "/packages/mtsi/pages/yoda/yoda?returl=" + encodeURIComponent(s) + "&requestCode=".concat(o.requestCode, "&apiurl=").concat(encodeURIComponent(i.url)),
                        fail: function() {
                            d && d.setRedirectStatus(n, !1);
                        }
                    }));
                }
            } catch (e) {}
        });
    }
};