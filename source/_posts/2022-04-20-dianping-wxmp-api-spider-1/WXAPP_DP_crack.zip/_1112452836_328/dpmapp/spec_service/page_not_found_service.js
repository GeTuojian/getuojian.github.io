module.exports = {
    setApp: function(e) {
        e.env.register(20019, function(e, n) {
            if (o) {
                var t = Object.keys(n.query).map(function(e) {
                    return encodeURIComponent(e) + "=" + encodeURIComponent(n.query[e]);
                }).join("&");
                o.redirectTo({
                    url: n.path + (t ? "?" + t : ""),
                    _fromPageNotFound: 1
                });
            }
        });
        var n, o = null;
        (o = e.navigation) && (o.redirectTo = (n = o.redirectTo, function(e) {
            n.call(o, e);
        }));
    }
};