module.exports = {
    setApp: function(e) {
        var r = require("../config/app_config.js"), n = require("../utils/get_request_type_by_url.js"), o = {}, i = e.runtimeInfo, a = i.wxAppVersion, t = i.brand, s = i.model, l = i.platform, p = i.wxmpVersion, d = i.deviceSystem, m = i.networkType, f = i.deviceSystemVersion;
        ~(o = {
            version: a,
            SDKVersion: p,
            brand: t,
            model: s,
            platform: (l || "").indexOf("IOS") > -1 ? "iOS" : "Android",
            system: d,
            networkType: m,
            platformVersion: f
        }).platform.indexOf("WINDOWS") && (o.platformVersion = (o.platformVersion || "").replace(/[^0-9]/gi, ""), 
        o.platform = "windows"), e.env.register(30002, function(i, a) {
            var t = r.DOMAIN;
            if (!(a.data = a.data || {}, a.url && -1 !== a.url.indexOf("://") || -1 !== a.protocol.path.indexOf("://"))) if (a.protocol.domain) {
                if (!a.url) return;
                if ("//" === a.url.substr(0, 2)) {
                    a.url = "https:" + a.url;
                }
            } else a.url = t + a.protocol.path;
            var s = n(a.url);
            "mapi" === s ? a.header = Object.assign({}, {
                token: "*",
                appVersion: r.APP_VERSION,
                appName: r.APP_NAME,
                isMicroMessenger: "true",
                channel: r.APP_CHANNEL,
                microMsgVersion: o.version,
                "network-type": e.runtimeInfo.networkType,
                "phone-brand": o.brand,
                "phone-model": o.model,
                minaname: r.APP_NAME,
                minaversion: r.APP_VERSION,
                channelversion: o.version,
                wechatversion: o.version,
                sdkversion: o.SDKVersion,
                platform: o.platform,
                platformVersion: o.platformVersion
            }, a.header) : "mina" === s && (a.header = Object.assign({}, {
                token: "*",
                minaname: r.APP_NAME,
                minaversion: r.APP_VERSION,
                channel: r.APP_CHANNEL,
                channelversion: o.version,
                wechatversion: o.version,
                sdkversion: o.SDKVersion,
                platform: o.platform,
                platformversion: o.platformVersion
            }, a.header));
            a.data.device_system = e.runtimeInfo.deviceSystem, a.data.wxmp_version = r.APP_VERSION, 
            -1 !== a.url.indexOf("ping.com/editor/readLionConfig") && (a.header ? a.header.openid = a.header.openidPlt = null : a.header = {
                openid: null,
                openidPlt: null
            });
        });
    }
};