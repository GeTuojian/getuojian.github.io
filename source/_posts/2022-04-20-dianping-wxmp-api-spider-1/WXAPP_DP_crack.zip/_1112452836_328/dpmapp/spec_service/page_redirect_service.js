var e = [ [ "movie/pages/", "/packages/movie/pages/" ], [ "dynamic-zhenguo-hybrid/", "/packages/dynamic-zhenguo-hybrid/" ], [ "dynamic-zhenguo/", "/packages/dynamic-zhenguo/" ] ], a = {
    "pages/debug/debug": "/pages/mvvm/mvvm?gear=debugpanel",
    "pages/debugpanel/debugpanel": "/pages/mvvm/mvvm?gear=debugpanel",
    "pages/mobile/mobile": "/pages/login/login",
    "pages/index/index": "/pages/home/home",
    "pages/search/search": "/packages/search/pages/search/search",
    "pages/list/list": "/packages/search/pages/searchresultlist/searchresultlist",
    "my/favorite/favorite": "/packages/my/pages/usercollection/usercollection",
    "pages/tuandetail/tuandetail": "/packages/tuan/pages/tuandetail/tuandetail",
    "pages/reviewlist/reviewlist": "/packages/ugc/pages/reviewlist/reviewlist",
    "pages/branchlist/branchlist": "/packages/branch/pages/list/list",
    "pages/ordersubmit/ordersubmit": "/packages/tuan/pages/ordersubmit/ordersubmit",
    "pages/orderdetail/orderdetail": "/packages/tuan/pages/orderdetail/orderdetail",
    "pages/shopablum/shopablum": "/packages/ugc/pages/shopalbum/shopalbum",
    "pages/coupondetail/coupondetail": "/packages/order/pages/coupondetail/coupondetail",
    "packages/basic/pages/city/city": "/pages/city/city",
    "packages/ranklist/pages/index/index": "/pages/ranklist/ranklist",
    "packages/customized-poi/pages/index/index": null,
    "packages/video-preview/pages/index/index": null,
    "packages/pages/search/search": "/pages/websearch/websearch",
    "dynamic-page/index": "/packages/dynamic-zhenguo-hybrid/subpackage/dynamic-page/index"
};

module.exports = {
    setApp: function(s) {
        s.env.register(34002, function(r, i) {
            var g, p = i.url, n = p.indexOf("?");
            -1 !== n && (p = p.substring(0, n));
            47 === p.charCodeAt(0) && (p = p.substring(1));
            for (var t = 0; t < e.length; t++) {
                var o = e[t][0], c = o.length;
                if (p.substring(0, c) === o) {
                    g = e[t][1] + p.substring(c);
                    break;
                }
            }
            g || ("pages/myorder/myorder" === p ? newUlr = -1 !== i.url.indexOf("currentDetail=order") ? "/packages/order/pages/myorder/myorder" : "/packages/order/pages/mycoupon/mycoupon" : g = a[p]);
            "pages/detail/detail" === p && s.userData.usePoiNew && (g = "/pages/poi/poi");
            g && (g += (-1 === g.indexOf("?") ? "?" : "&") + "redirect_from=" + encodeURIComponent(p), 
            -1 !== n && (g += "&" + i.url.substring(n + 1)), i.url = g, i._fromPageNotFound && getApp().env.notify(35001, {
                content: "外部失效页面：" + p,
                reason: "URL_ERROR",
                level: "warn"
            }));
        });
    }
};