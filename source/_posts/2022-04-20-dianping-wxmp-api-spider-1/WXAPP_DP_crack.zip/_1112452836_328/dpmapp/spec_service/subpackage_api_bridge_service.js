var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/slicedToArray"));

module.exports = {
    setApp: function(t) {
        var r = require("../../framework/mtdp_bucket/async_data_provider/lbs_provider.js"), n = require("../../framework/mtdp_bucket/async_data_provider/loc_cityid_provider.js"), a = require("../../framework/mtdp_bucket/async_data_provider/cityid_provider.js"), i = require("../../framework/mtdp_bucket/async_data_provider/token_provider.js"), o = require("../../framework/mtdp_bucket/async_data_provider/account_provider.js"), s = require("../../framework/mtdp_bucket/async_data_provider/cx_provider.js"), u = require("../../framework/mtdp_bucket/async_data_provider/userid_provider.js"), d = require("../../framework/class_define/http_protocol.js"), c = require("../../framework/class_define/http_request_task.js"), g = require("../utils/wxp.js");
        t.bridge || (t.bridge = {}), t.bridge.getLbsAsync = function() {
            return new Promise(function(e, n) {
                r.getDataAsync(function() {
                    t.userData.latitude && t.userData.longitude ? e({
                        latitude: t.userData.latitude,
                        longitude: t.userData.longitude
                    }) : n({
                        latitude: "",
                        longitude: ""
                    });
                });
            });
        }, t.bridge.getLbsNoRejectAsync = function() {
            return new Promise(function(e) {
                r.getDataAsync(function() {
                    t.userData.latitude && t.userData.longitude ? e({
                        latitude: t.userData.latitude,
                        longitude: t.userData.longitude
                    }) : e();
                });
            });
        }, t.bridge.getLbsSync = function() {
            return t && t.userData && t.userData.latitude && t.userData.longitude ? {
                latitude: t.userData.latitude,
                longitude: t.userData.longitude
            } : {};
        }, t.bridge.getLocCityAsync = function() {
            return new Promise(function(e) {
                n.getDataAsync(function() {
                    e({
                        cityId: t.userData.dpLocCityId,
                        cityName: t.userData.dpLocCityName,
                        isOverseasCity: 1 === t.userData.dpLocIsOverseasCity
                    });
                });
            });
        }, t.bridge.getLocCitySync = function() {
            return t && t.userData && t.userData.dpLocCityId && t.userData.dpLocCityName ? {
                cityId: t.userData.dpLocCityId,
                cityName: t.userData.dpLocCityName,
                isOverseasCity: 1 === t.userData.dpLocIsOverseasCity
            } : {};
        }, t.bridge.getLocCityInfo = function() {
            return {
                city: t.bridge.getLocCitySync()
            };
        }, t.bridge.getCityAsync = function() {
            return new Promise(function(e) {
                a.getDataAsync(function() {
                    e({
                        cityId: t.userData.dpCityId,
                        cityName: t.userData.dpCityName,
                        isOverseasCity: 1 === t.userData.dpIsOverseasCity
                    });
                });
            });
        }, t.bridge.getCitySync = function() {
            return t && t.userData && t.userData.dpCityId && t.userData.dpCityName ? {
                cityId: t.userData.dpCityId,
                cityName: t.userData.dpCityName,
                isOverseasCity: 1 === t.userData.dpIsOverseasCity
            } : {};
        }, t.bridge.getCityInfo = function() {
            return {
                city: t.bridge.getCitySync()
            };
        }, t.bridge.setCitySync = function(e) {
            a.setDataSync(e.cityId, e.cityName, e.isOverseasCity);
        }, t.bridge.getIdAsync = function() {
            return new Promise(function(e) {
                o.getDataAsync(function() {
                    e({
                        openId: t.userData.wxmpEncryptedOpenId,
                        openIdPlt: t.userData.wxmpOpenId
                    });
                });
            });
        }, t.bridge.getIdSync = function() {
            return t && t.userData && t.userData.wxmpEncryptedOpenId && t.userData.wxmpOpenId ? {
                openId: t.userData.wxmpEncryptedOpenId,
                openIdPlt: t.userData.wxmpOpenId
            } : {};
        }, t.bridge.getGroupId = function(r) {
            var n = {
                openGId: void 0,
                msg: ""
            };
            return r ? Promise.all([ g.login(), g.getShareInfo({
                shareTicket: r
            }) ]).then(function(r) {
                var a = (0, e.default)(r, 2), i = a[0], o = a[1], s = i.code, u = o.encryptedData, g = o.iv;
                if (!s || !u || !g) return n.msg = "【login ｜ getShareInfo】API出错", Promise.resolve(n);
                t.h.request(new c(new d("/wxmapi/login/shareinfo", {
                    data: {
                        code: s,
                        encryptedData: u,
                        iv: g
                    }
                }), {
                    callback: function(e) {
                        var t = e.serverData || null;
                        return 200 == t.statusCode && t.data ? t.data.data && 200 == t.data.code ? n.openGId = t.data.data.openGId : n.msg = "服务出错" : n.msg = "网络出错", 
                        Promise.resolve(n);
                    }
                }));
            }) : (n.msg = "shareTicket不存在", Promise.resolve(n));
        }, t.bridge.getUserAsync = function() {
            return new Promise(function(e) {
                u.getDataAsync(function() {
                    e({
                        code: 200,
                        userId: t.userData.userid,
                        token: t.userData.dpAccessToken
                    });
                });
            });
        }, t.bridge.getUserSync = function() {
            return t && t.userData && t.userData.userid && t.userData.dpAccessToken ? {
                code: 200,
                userId: t.userData.userid,
                token: t.userData.dpAccessToken
            } : {};
        }, t.bridge.getUserInfo = function() {
            return new Promise(function(e) {
                t.userData.dpAccessToken ? e({
                    code: 200,
                    token: t.userData.dpAccessToken,
                    dpUser: t.bridge.getUserSync(),
                    openId: t.bridge.getIdSync().openId,
                    openIdPlt: t.bridge.getIdSync().openIdPlt,
                    unionId: t.userData.wxmpEncryptedUnionId
                }) : e({
                    code: 500,
                    msg: "未登录"
                });
            });
        }, t.bridge.getWxUser = function() {
            return {
                token: t.userData.dpAccessToken,
                userId: t.bridge.getUserSync().userId,
                openId: t.bridge.getIdSync().openId,
                unionId: t.userData.wxmpEncryptedUnionId
            };
        }, t.bridge.getToken = function() {
            return t.userData.dpAccessToken;
        }, t.bridge.login = function(e) {
            return new Promise(function(r, n) {
                i.getDataAsync(function(e, a) {
                    t.userData.dpAccessToken ? r({
                        code: 200,
                        token: t.userData.dpAccessToken,
                        userId: t.bridge.getUserSync().userId,
                        openId: t.bridge.getIdSync().openId,
                        openIdPlt: t.bridge.getIdSync().openIdPlt,
                        unionId: t.userData.wxmpEncryptedUnionId,
                        msg: "ok"
                    }) : n({
                        code: 500,
                        token: t.userData.dpAccessToken,
                        userId: t.bridge.getUserSync().userId,
                        openId: t.bridge.getIdSync().openId,
                        openIdPlt: t.bridge.getIdSync().openIdPlt,
                        unionId: t.userData.wxmpEncryptedUnionId,
                        msg: a || "fail"
                    });
                }, e);
            });
        }, t.bridge.loginout = function() {
            t.userData.dpAccessToken = null;
        }, t.bridge.request = function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            return new Promise(function(r, n) {
                var a, i = e.url, o = i.indexOf("://"), s = i.indexOf("?", o + 3);
                a = !e.method || "post" !== e.method && "POST" !== e.method ? i.substring(i.indexOf("/", o + 3), -1 === s ? void 0 : s) : i.substring(i.indexOf("/", o + 3));
                var u = i.substring(0, i.indexOf("/", o + 3)) || "";
                e.domain = e.domain ? e.domain : u, e.domain, t.h.request(new c(new d(a, e), {
                    callback: function(e) {
                        0 === e.errorCode ? r && r(e.serverData) : 10 == ~~(Math.abs(e.errorCode) / 100) ? n && n(e.serverData) : r && r(e.serverData);
                    }
                }));
            });
        }, t.bridge.jsguard = function() {
            return new Promise(function(e) {
                s.getDataAsync(function() {
                    var r = t.userData.jsguardInstance;
                    e(r);
                });
            });
        }, t.bridge.finger = function() {
            return new Promise(function(e) {
                s.getDataAsync(function() {
                    var r = t.userData.jsguardInstance && t.userData.jsguardInstance.finger;
                    e(r);
                });
            });
        }, t.bridge.getFingerprint = function() {
            return new Promise(function(e) {
                s.getDataAsync(function(t) {
                    e(t);
                });
            });
        }, t.bridge.getSystemInfo = function() {
            return new Promise(function(e) {
                var t = wx.getSystemInfoSync() || {};
                t.model && -1 != t.model.indexOf("iPhone X") && (t.isIpx = !0), wx.getNetworkType({
                    success: function(r) {
                        t.networkType = r.networkType, e(t);
                    },
                    fail: function() {
                        e(t);
                    }
                });
            });
        }, t.bridge.getShowOptions = function() {
            try {
                return wx.getLaunchOptionsSync();
            } catch (e) {
                return {};
            }
        }, t.bridge.getWxAuth = function() {
            return new Promise(function(e, t) {
                wx.getSetting({
                    success: function(r) {
                        if (r.authSetting["scope.userInfo"]) {
                            var n = wx.getUserProfile;
                            n || (n = wx.getUserInfo), n({
                                success: function(t) {
                                    e({
                                        userInfo: t.userInfo,
                                        code: 200,
                                        msg: "已微信授权,读取 userInfo 信息成功"
                                    });
                                },
                                fail: function() {
                                    t({
                                        code: 101,
                                        msg: "获取授权信息失败"
                                    });
                                }
                            });
                        } else t({
                            code: 102,
                            msg: "用户未授权"
                        });
                    },
                    fail: function() {
                        t({
                            code: 500,
                            msg: "读取微信配置失败"
                        });
                    }
                });
            });
        }, t.env.register(60001, function(e, r) {
            r.dpCityId && r.dpCityName && r.dpIsOverseasCity && t.env.notify("cityChange", {
                cityId: t.userData.dpCityId,
                cityName: t.userData.dpCityName,
                isOverseasCity: 1 === t.userData.dpIsOverseasCity
            });
        });
        var p = require("../../framework/mtdp_bucket/utils/lx_adaptor.js"), f = require("../../framework/mtdp_bucket/utils/owl_adaptor.js"), y = require("../../framework/mtdp_bucket/utils/logan_adaptor.js"), l = require("../../framework/mtdp_bucket/utils/rohr_adaptor.js"), m = require("../../framework/mtdp_bucket/utils/perf_adaptor.js");
        t.induction || (t.induction = {}), t.induction.LX = p, t.induction.OWL = f, t.induction.LOGAN = y, 
        t.induction.ROHR = l, t.induction.PERF = m;
        var I = require("../../framework/class_define/page_base.js");
        t.framework || (t.framework = {}), t.framework.pageBase = function(e) {
            e && e.pageName, I(e);
        }, t.tools || (t.tools = {}), t.tools.logger = function() {
            try {
                "dev" === t.appConfig.ENV && console && console.log && console.log.apply(console, arguments);
            } catch (e) {}
        }, t.tools.wxp = g, t.tools.url = {
            parseQuery: require("../../dpmapp/utils/query_util.js").queryStringToObject,
            parseUrl: require("../../dpmapp/utils/parse_url.js"),
            parse: function(e, t) {
                return this.parseUrl(e, t);
            },
            stringify: function(e, t, r) {
                var n = e, a = Object.keys(t).map(function(e) {
                    return "".concat(e, "=").concat(t[e]);
                }).join("&");
                return a && (n += "?" + a), r && (n += "#" + r), n;
            },
            rewrite: function(e) {
                return e && 0 === e.indexOf("http://") && (e = e.replace("http://", "https://")), 
                e;
            }
        };
        var D = require("../../framework/utils/storage.js");
        t.cache = {
            setStorage: function(e, t) {
                return D.setLocalStorageAsync(e, t);
            },
            setStorageSync: function(e, t) {
                return D.setLocalStorageSync(e, t);
            },
            getStorage: function(e) {
                return new Promise(function(t) {
                    t && t(D.getLocalStorageSync(e));
                });
            },
            getStorageSync: function(e) {
                return D.getLocalStorageSync(e);
            },
            removeStorage: function(e) {
                return D.setLocalStorageAsync(e, void 0);
            },
            removeStorageSync: function(e) {
                return D.setLocalStorageSync(e, void 0);
            }
        }, t.getConfig = function() {
            return t.appConfig;
        };
    }
};