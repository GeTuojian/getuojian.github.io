var e = require("../../framework/class_define/http_protocol.js"), a = require("../../framework/class_define/http_request_task.js");

module.exports = {
    setApp: function(t) {
        t.h.request(new a(new e("/an/gear/dpmapp/api/base/poi_ab_test", {
            domain: "https://m.dianping.com",
            data: {
                openId: t.userData.wxmpEncryptedOpenId
            }
        }), {
            callback: function(e) {
                var a = e.serverData && e.serverData.data && e.serverData.data.data || null;
                a.target && a.target.contents && "new" === a.target.contents.key && (t.userData.usePoiNew = !0);
            }
        }));
    }
};