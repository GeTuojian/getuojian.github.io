module.exports = {
    setApp: function(t, e, r, n) {
        var p = require("../utils/query_util.js");
        function u(t) {
            var e = t.type, r = t.url;
            if ("h5" === e || /^https:\/\//.test(r)) {
                var n = encodeURIComponent(r);
                r = "".concat("/pages/webview/webview", "?url=").concat(n);
            }
            return r;
        }
        function a(t) {
            return !!((t = t.split("?")[0]) && n && n.length) && n.some(function(e) {
                return e.indexOf(t.replace(/^\/+|\/+$/g, "")) > -1;
            });
        }
        t.env.register(34002, function(t, n) {
            n && n.url && function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = t.url, i = t.type;
                try {
                    if (0 === n.indexOf("dpmina://")) {
                        var o = n.substring(9), c = p.queryStringToObject(o), l = {}, s = [ "appId", "path", "type" ];
                        s.map(function(t) {
                            c[t] && (l[t] = decodeURIComponent(c[t]));
                        }), t.url = u({
                            url: l.path,
                            type: l.type
                        }), l.appId && l.appId !== e && (t.appId = appId, t.path = n, t.type = "miniprogram", 
                        t.extraData = {
                            utm_source: r
                        });
                    } else a(n) ? t.type = "tabbar" : (n = u({
                        url: n,
                        type: i
                    }), t.url = n);
                } catch (t) {}
            }(n);
        });
    }
};