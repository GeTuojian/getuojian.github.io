require("../../@babel/runtime/helpers/Arrayincludes"), module.exports = {
    setApp: function(e, r) {
        var i = require("../config/shorten_link_config.js");
        e.env.register(34002, function(r, n) {
            var t;
            if (n && (t = n.url) && "stlk://" === t.substring(0, 7)) {
                var s = t.indexOf("?", 7);
                -1 === s && (s = void 0);
                var a = t.substring(7, s), u = s ? t.substring(s) : "", l = i[a];
                if (l || (l = "/pages/webview/webview?url=".concat(e.appConfig.DOMAIN_A, "%2F").concat(a), 
                console.warn("unconfiged short link: " + a)), !l) return void (n.url = null);
                if (l.includes("#oversea#") && (l = l.replace("#oversea#", 1 === getApp().userData.dpIsOverseasCity ? "?_tab=oversea" : "")), 
                l.includes("#cityId#") && (l = l.replace("#cityId#", String.valueOf(getApp().userData.cityId))), 
                l.includes("%23cityId%23") && (l = l.replace("%23cityId%23", String.valueOf(getApp().userData.cityId))), 
                l.includes("#cityEnName#") && (l = l.replace("#cityEnName#", getApp().userData.cityEnName || "shanghai")), 
                l.includes("%23cityEnName%23") && (l = l.replace("%23cityEnName%23", getApp().userData.cityEnName)), 
                n.url = l, !u) return;
                if ("/pages/webview/webview?" === n.url.substring(0, 23)) {
                    for (var c = n.url.indexOf("?"), p = n.url.substring(c + 1).split("&"), g = 0; g < p.length; g++) if ("url=" === p[g].substring(0, 4)) {
                        var o = encodeURIComponent(u.substring(1));
                        -1 !== p[g].indexOf("%3F") ? p[g] += "%26" + o : p[g] += "%3F" + o;
                        break;
                    }
                    n.url = n.url.substring(0, c + 1) + p.join("&");
                } else -1 !== l.indexOf("?") ? n.url += "&" + u.substring(1) : n.url += u;
            }
        });
    }
};