module.exports = {
    setApp: function(e, i) {
        require("../config/app_config.js"), e.env.register(36002, function(e, a) {
            var r = getCurrentPages(), t = r[r.length - 1];
            if (a.pageName = t.pageName, i && "pageView" === a.behaviorType) {
                var g = i.cid[t.pageName];
                g ? a.cid = g : delete a.cid;
            }
        });
    }
};