module.exports = {
    setApp: function(t) {
        t.env.register(38001, function(e, n) {
            var r = getCurrentPages();
            r[r.length - 1].data.PAGE_CAN_HANDLE_TOKEN_REQUIRE || t.navigation.forwardTo({
                url: "stlk://login"
            });
        });
    }
};