var e = require("../../@babel/runtime/helpers/interopRequireDefault"), r = e(require("../../@babel/runtime/helpers/classCallCheck")), t = e(require("../../@babel/runtime/helpers/inherits")), n = e(require("../../@babel/runtime/helpers/possibleConstructorReturn")), o = e(require("../../@babel/runtime/helpers/getPrototypeOf"));

function i(e) {
    var r = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var t, i = (0, o.default)(e);
        if (r) {
            var u = (0, o.default)(this).constructor;
            t = Reflect.construct(i, arguments, u);
        } else t = i.apply(this, arguments);
        return (0, n.default)(this, t);
    };
}

var u = require("../../framework/class_define/http_request_task.js"), a = new (require("../../framework/class_define/http_protocol.js"))("/an/gear/dpmapp/api/readLionConfig/loadCity", {
    domain: require("../../dpmapp/config/app_config.js").DOMAIN,
    method: "GET",
    retryMax: 0,
    priority: 2,
    skipPreload: !1,
    header: {
        "content-type": "application/json"
    }
}), l = function(e) {
    (0, t.default)(o, e);
    var n = i(o);
    function o(e) {
        return (0, r.default)(this, o), n.call(this, o.defaultProtocol, e);
    }
    return o;
}(u);

l.defaultProtocol = a, module.exports = l;