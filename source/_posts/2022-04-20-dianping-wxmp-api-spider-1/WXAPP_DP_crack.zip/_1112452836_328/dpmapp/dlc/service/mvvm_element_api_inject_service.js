module.exports = {
    setApp: function(e) {
        var a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [], t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
        if (e.__service_block__.IS_SSR_BLOCKING || !e.__service_block__.__DPMAPP_MVVM_ELEMENT_AIP_INJECT_SERVICE_LOADED__) {
            e.__service_block__.__DPMAPP_MVVM_ELEMENT_AIP_INJECT_SERVICE_LOADED__ = 1, e.env.register(20012, l), 
            e.env.register(20014, s);
            var n = 1, i = 100, r = 200;
        }
        function s(s, l) {
            var o = l.page, m = l.pageName;
            function p(e) {
                var a, t, n, r, s, l, o = this, m = e ? o.pageMVVMS.filter(function(a) {
                    return a !== e;
                }) : o.pageMVVMS;
                if (m.forEach(function(e, i) {
                    var s = e.maskType;
                    if (s) {
                        var l, o, m, p = Math.floor((s - 1) / 20), u = (s - 20 * p) / 20;
                        if (0 === p ? (l = 0, o = 0, m = 0) : (l = 1, o = 1, m = 1), 0 === i) r = u, a = l, 
                        t = o, n = m; else {
                            var M = 1 - u;
                            a = l * u + M * a, t = o * u + M * t, n = m * u + M * n, r = 1 - (1 - u) * (1 - r);
                        }
                    }
                }), m.length ? (s = "#" + (16777216 + (Math.floor(255 * a) << 16) + (Math.floor(255 * t) << 8) + Math.floor(255 * n)).toString(16).substr(1), 
                l = r) : (s = o.data.maskColor, l = 0), "none" === o.data.maskAnime) {
                    o.setData({
                        maskColor: s,
                        maskAlpha: 0,
                        maskAnime: "fade"
                    });
                    var p = setTimeout(function() {
                        clearTimeout(p), u();
                    }, 0);
                } else u();
                function u() {
                    if (o.setData({
                        maskColor: s,
                        maskAlpha: l,
                        maskAnime: "fade"
                    }), !l) var e = setTimeout(function() {
                        clearTimeout(e), 0 === o.data.maskAlpha && o.setData({
                            maskAnime: "none"
                        });
                    }, i);
                }
            }
            function u() {
                var e = this, a = this.pageMVVMS.map(function(a) {
                    return {
                        widgets: a.cocktailNode._childNodes.map(function(a) {
                            return a._dirtyFlag && e.renderTime++, Object.assign({}, a.getBindedNode(), {
                                renderTime: e.renderTime
                            });
                        }),
                        inputs: Object.keys(a.inputs).map(function(e) {
                            return a.inputs[e];
                        }),
                        mvvmName: a.signalName,
                        dlcType: [ "", " pp", " float", " noti", " rise" ][a.animeType],
                        animeType: a.animeType ? a.isClosing ? " fade-out" : " fade-in" : ""
                    };
                });
                e.setData({
                    mvvmData: a
                });
            }
            a && -1 === a.indexOf(m) || t && -1 !== t.indexOf(m) || (o.pageMVVMS = [], o.renderTime = 0, 
            o.setData({
                MVVMLayerSupport: !0,
                mvvmData: [],
                maskColor: "#000",
                maskAlpha: 0,
                maskAnime: "none"
            }), o.$addMVVMElement = function(a) {
                var t = this, i = a.pageName + (a.isResident ? "" : "-s" + n++);
                e.env.notify("__ON_A_DLC_ELEMENT_LOADING_", {
                    signalName: i,
                    pageName: a.pageName,
                    pageMVVM: a
                }), a._$_init(i, u.bind(this), function(n, s) {
                    if (e.env.notify("__ON_A_DLC_ELEMENT_UNLOADING_", {
                        signalName: i,
                        pageName: a.pageName,
                        pageMVVM: a
                    }), n.animeType) {
                        n.isClosing = !0, n.maskType && p.call(t, n), u.call(t);
                        var l = setTimeout(function() {
                            clearTimeout(l), n.isClosing = !1, m(t);
                        }, r);
                    } else m(o);
                    function m(t) {
                        t.$removeMVVMElement && t.$removeMVVMElement(n, n.signalName), s && (s.apply(n), 
                        s = null), e.env.notify("__ON_A_DLC_ELEMENT_UNLOADED_", {
                            signalName: i,
                            pageName: a.pageName,
                            pageMVVM: n
                        });
                    }
                }), a.cocktailNode && (this.pageMVVMS.push(a), u.call(this), a.maskType && p.call(this), 
                e.env.notify("__ON_A_DLC_ELEMENT_LOADED_", {
                    signalName: i,
                    pageName: a.pageName,
                    pageMVVM: a
                }));
            }.bind(o), o.$removeMVVMElement = function(e, a, t) {
                for (var n = 0; n < this.pageMVVMS.length; n++) {
                    var i = this.pageMVVMS[n];
                    if (i === e || i.signalName === a || i.pageName === t) return this.pageMVVMS.splice(n, 1), 
                    void u.call(this);
                }
            }.bind(o), o.onTapMVVMElement = function(e) {
                for (var a, t, n = e.target.id, i = e.target.dataset.mvvmName, r = 0; r < this.pageMVVMS.length; r++) if ((t = this.pageMVVMS[r]).signalName === i) {
                    a = t.cocktailNode;
                    break;
                }
                if (a) {
                    var s = [ a ], l = s.length, o = null, m = n;
                    for (m.length >= 7 && "$iNPUT-" === m.substr(0, 7) && (m = m.substr(7)); l; ) {
                        var p = s[l - 1];
                        if (p.cocktailKey === m) {
                            o = p;
                            break;
                        }
                        s.pop(), p._childNodes && p._childNodes.length && (s = s.concat(p._childNodes)), 
                        l = s.length;
                    }
                    if (o) {
                        var u = require("../../../framework/utils/deep_clone.js"), M = {};
                        o.id && (M.id = o.id), o.dataset && (M.dataset = u(o.dataset));
                        var d = null;
                        if (o._eventMap && (d = o._eventMap.tap), d && (M.id && getApp().env.notify(37001, {
                            identity: "mvvm@" + t.signalName + "." + M.id
                        }), d.funcName)) {
                            var c = {
                                type: "tap",
                                target: M,
                                currentTarget: M
                            };
                            t[d.funcName] && t[d.funcName](c);
                        }
                        if (!d || !d.isCatch) for (var g = o; g.parentNodeMacro; ) {
                            var f = void 0;
                            if ((g = g.parentNodeMacro)._eventMap && (f = g._eventMap.tap)) {
                                if (f.page && f.funcName) {
                                    var _ = {};
                                    if (g.id && (_.id = g.id), g.dataset && (_.dataset = u(g.dataset)), _.id && getApp().env.notify(37001, {
                                        identity: "mvvm@" + t.signalName + "." + _.id
                                    }), t[f.funcName]) {
                                        var V = {
                                            type: "tap",
                                            target: M,
                                            currentTarget: _
                                        };
                                        t[f.funcName](V);
                                    }
                                }
                                if (f.isCatch) return;
                            }
                        }
                    }
                }
            }.bind(o), o.onMVVMElementInputEvent = function(e) {
                var a, t = e.currentTarget.dataset.inputEvent;
                if (t && (a = t[e.type])) {
                    for (var n, i, r = e.currentTarget.dataset.mvvmName, s = 0; s < this.pageMVVMS.length; s++) if ((i = this.pageMVVMS[s]).signalName === r) {
                        n = i.cocktailNode;
                        break;
                    }
                    if (n && a.funcName) {
                        if (!i[a.funcName]) return;
                        var l = {}, o = e.currentTarget.dataset.inputDomId;
                        if (o && (l.id = o), e.currentTarget.dataset.inputDataset) {
                            var m = require("../../../framework/utils/deep_clone.js");
                            l.dataset = m(e.currentTarget.dataset.inputDataset);
                        }
                        var p = {
                            type: e.type,
                            target: l,
                            currentTarget: l,
                            detail: e.detail
                        };
                        i.inputs[e.currentTarget.id].$inputValue = e.detail.value, i[a.funcName](p);
                    }
                }
            }.bind(o), o.onMVVMMask = function() {});
        }
        function l(e, a) {
            var t = a.page;
            t && t.$addMVVMElement && (t.$addMVVMElement = null, t.$removeMVVMElement = null, 
            this.pageMVVMS && (this.pageMVVMS.forEach(function(e) {
                e.widgets && (e.widgets.forEach(function(e) {
                    return e.dispose();
                }), e.widgets = null), e.inputs = null;
            }), this.pageMVVMS = null), this.renderTime = null, t.onTapMVVMElement = null, t.onMVVMElementInputEvent = null, 
            t.onMVVMMask = null);
        }
    }
};