module.exports = {
    setApp: function(e) {
        var r = require("../../../framework/utils/base64_encode.js"), a = require("../../../framework/utils/base64_decode.js"), t = require("../../../framework/utils/storage.js");
        module.exports.loadPDGear = function(e) {
            var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, a = "pd_" + e;
            _[a] ? _[a].refer++ : _[a] = {
                refer: 1,
                callbacks: []
            };
            r && _[a].callbacks.push(r);
            if (!n[a]) return;
            if (4 === n[a].status && n[a].gear) return void (_[a] && _[a].callbacks && (_[a].callbacks.forEach(function(e) {
                return e(n[a].gear);
            }), _[a].callbacks = []));
            n[a].url && f(n[a].url, a, n[a].version);
        }, module.exports.unloadPDGear = function(r) {
            _["pd_" + r] && (_["pd_" + r].refer--, _["pd_" + r].refer || (_["pd_" + r] = null, 
            d("pd_" + r, void 0, !1), e.env.notify("__ON_A_GEAR_SCRIPT_UNLOEADED_", {
                gearInfo: n["pd_" + r]
            })));
        }, module.exports.getGearInfo = function(e) {
            return n ? n[e] : void 0;
        };
        var o = t.getLocalStorageSync("__CACHE@APP:GEAR_LIST__"), n = {}, s = "";
        if (o) for (var i = 0; i < o.length; i++) {
            var l = o[i];
            if (l && l.name) {
                var c = t.getLocalStorageSync("__CACHE@APP:GEAR_SCRIT_" + l.name + "_" + l.version);
                if (c && (s += "#".concat(l.name, "@").concat(l.version), "pd_" !== l.name.substr(0, 3))) {
                    var u = e.gearEnv.decode(a(c), l.name);
                    e.workflow.runGearScript(u, !0), n[l.name] = {
                        gear: u,
                        status: 3,
                        version: l.version,
                        id: l.name
                    };
                }
            }
        }
        var _ = [];
        function d(r) {
            var a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : void 0, o = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
            if (void 0 === a && (a = n[r].version), n[r]) {
                var i = n[r].gear;
                e.workflow.unloadGearScript(i), e.gearEnv.disposeGear(i), n[r].status = 5, n[r].gear = null;
            }
            o && (t.setLocalStorageSync("__CACHE@APP:GEAR_SCRIT_" + r + "_" + a, void 0), s = s.replace("#".concat(r, "@").concat(a), ""));
        }
        function f(o) {
            var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : void 0, l = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0;
            if (!i) {
                var c = o.substring(o.lastIndexOf("/") + 1), u = c.lastIndexOf("_"), d = c.substring(u + 1, c.lastIndexOf(".gear.bin")), f = c.substring(0, u);
                n[f] || (n[f] = {
                    gear: null,
                    url: o,
                    version: d,
                    status: 0,
                    id: f
                });
            }
            if (i && (_[i] || "pd_" !== i.substr(0, 3))) if (0 === n[i].status || 5 === n[i].status) {
                var v = t.getLocalStorageSync("__CACHE@APP:GEAR_SCRIT_" + i + "_" + l);
                if (v) g(a(v), i); else {
                    n[i].status = 1;
                    getApp().runtimeInfo.platform;
                    e.h.request({
                        protocol: {
                            path: "https://" + o,
                            method: "GET",
                            dataType: "blob",
                            responseType: "arraybuffer",
                            retryMax: 3,
                            retryDelay: 200
                        },
                        callback: function(e) {
                            0 === e.errorCode && g(e.serverData.data, i);
                        },
                        dispose: function() {}
                    });
                }
            } else n[i].status;
            function g(a, o) {
                try {
                    var i, c;
                    i = r(c = a);
                    var u = e.gearEnv.decode(c, o);
                    t.setLocalStorageAsync("__CACHE@APP:GEAR_SCRIT_" + o + "_" + l, i), n[o].gear = u, 
                    e.workflow.runGearScript(u, !1), n[o].status = 4, _[o] && _[o].callbacks && (_[o].callbacks.forEach(function(e) {
                        return e(u);
                    }), _[o].callbacks = []), e.env.notify("__ON_A_GEAR_SCRIPT_LOEADED_", {
                        silentMode: !1,
                        gearInfo: n[o],
                        gear: u
                    }), s += "#".concat(o, "@").concat(l);
                } catch (e) {}
            }
        }
        e.h.request({
            protocol: {
                domain: "https://m.dianping.com",
                path: "/an/gear/dpmapp/api/readLionConfig/readLionConfig?key=com.sankuai.growthweb.editor.tsmbyrk",
                method: "GET",
                dataType: "json",
                retryMax: 3,
                retryDelay: 200,
                data: {
                    cached_gear_info: s.substr(1)
                }
            },
            callback: function(r) {
                if (0 === r.errorCode) {
                    var a = r.data, s = [];
                    for (var i in a) {
                        var l = a[i].url, c = l.substring(l.lastIndexOf("_") + 1, l.lastIndexOf(".gear.bin"));
                        s.push({
                            name: i,
                            version: c
                        });
                        var u = n[i];
                        u && 3 === u.status && (u.version === c ? (e.workflow.activateGearScript(u.gear), 
                        u.status = 4, e.env.notify("__ON_A_GEAR_SCRIPT_LOEADED_", {
                            silentMode: !1,
                            gearInfo: u,
                            gear: u.gear
                        })) : (d(i, u.version), u = null)), u && 5 !== u.status || (n[i] = {
                            gear: null,
                            url: l,
                            version: c,
                            status: 0,
                            id: i
                        }, f(l, i, c));
                    }
                    if (o && o.length) for (var _ = 0; _ < o.length; _++) {
                        var v = o[_];
                        a[v.name] || d(v.name, v.version);
                    }
                    t.setLocalStorageSync("__CACHE@APP:GEAR_LIST__", s), o = s, s = null;
                }
            },
            dispose: function() {}
        });
    }
};