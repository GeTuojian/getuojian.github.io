var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), r = e(require("../../../@babel/runtime/helpers/classCallCheck")), n = e(require("../../../@babel/runtime/helpers/createClass")), a = require("./GearScript.js"), t = function() {
    function e() {
        (0, r.default)(this, e), this.env_instancePool = {}, this.env_classDict = {}, this.env_gearNameMap = {}, 
        this.init.apply(this);
    }
    return (0, n.default)(e, [ {
        key: "init",
        value: function() {}
    }, {
        key: "dispose",
        value: function() {}
    }, {
        key: "getClassInstance",
        value: function(e, r) {
            if (r) return e.instancePool[r] || this.env_instancePool[r];
        }
    }, {
        key: "readFileHead",
        value: function(e, r) {
            if (71 == e.readByte() && 82 == e.readByte() && 83 == e.readByte() && 2 == e.readByte()) {
                var n = e.readUnsignedInt() + 1337613877248;
                r && (r.time = n);
                var a = e.readShort();
                return r && (r.version = a), !0;
            }
            return !1;
        }
    }, {
        key: "decode",
        value: function(e, r) {
            var n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
            if (r && this.env_gearNameMap[r]) return console.warn("dup load script id:" + r), 
            this.env_gearNameMap[r];
            var t = require("./utils/ByteArray.js"), i = new t(e), s = new a();
            i.position = 0;
            var o = require("./GearClassDefine.js"), l = require("./GearVariableStruct.js"), d = require("./GearClassInstanceDynamic.js");
            if (this.readFileHead(i, s)) {
                for (var c = i.readUnsignedByteOrShort(), u = 0; u < c; u++) {
                    var v = i.readUnsignedByteOrShort(), h = i.readUTFBytes(v);
                    s.m_stringPool.push(h);
                }
                var y = i.readUnsignedByteOrShort(), p = i.position;
                for (u = 0; u < y; u++) {
                    var g, f, _;
                    g = s.m_classPool[u] = new o(), f = i.readUnsignedByteOrShort(), _ = i.readUnsignedByteOrShort(), 
                    g.className = s.m_stringPool[f], g.variableArray.length = _;
                    for (var B = 0; B < _; B++) {
                        var m, P, U, S;
                        m = g.variableArray[B] = new l(), P = i.readUnsignedByteOrShort(), U = i.readByte(), 
                        m.variableName = s.m_stringPool[P], m.type = U, 42 !== U && 41 !== U || (S = i.readUnsignedByteOrShort());
                    }
                }
                for (i.position = p, u = 0; u < y; u++) for (g = s.m_classPool[u], f = i.readUnsignedByteOrShort(), 
                _ = i.readUnsignedByteOrShort(), B = 0; B < _; B++) P = i.readUnsignedByteOrShort(), 
                42 !== (U = i.readByte()) && 41 !== U || (S = i.readUnsignedByteOrShort()), 42 === (m = g.variableArray[B]).type && (m.type = s.m_classPool[S].variableArray[0].type);
                var O = i.readUnsignedByteOrShort();
                for (p = i.position, u = 0; u < O; u++) {
                    var b;
                    b = i.readUnsignedByteOrShort();
                    var k, q, N, w = i.position + b;
                    k = i.readUnsignedByteOrShort(), q = i.readUnsignedInt();
                    var I = s.m_classPool[k];
                    if (I) {
                        var j = this.env_classDict[I.className];
                        N = j && !n ? new j(q) : new d(q, I);
                    }
                    this.env_instancePool[q] = s.instancePool[q] = N, i.position = w;
                }
                for (i.position = p, u = 0; u < O; u++) b = i.readUnsignedByteOrShort(), w = i.position + b, 
                k = i.readUnsignedByteOrShort(), q = i.readUnsignedInt(), (N = s.instancePool[q]).decode && N.decode(this, s, i), 
                i.position = w;
                return i = null, r && (this.env_gearNameMap[r] = s, s._env_gear_id = r), s;
            }
            return i = null, s = null, null;
        }
    }, {
        key: "disposeGear",
        value: function(e) {
            var r = this;
            if (e.instancePool) {
                var n = Object.keys(e.instancePool).map(function(e) {
                    return parseInt(e);
                });
                n.forEach(function(n) {
                    var a = e.instancePool[n];
                    a && a.dispose(r, e);
                }), n.forEach(function(e) {
                    delete r.env_instancePool[e];
                }), e._env_gear_id && (delete this.env_gearNameMap[e._env_gear_id], e._env_gear_id = null), 
                e.dispose();
            }
        }
    }, {
        key: "disposeInstance",
        value: function(e, r) {
            e.instancePool[r].dispose(), delete this.env_instancePool[r], delete e.instancePool[r];
        }
    } ]), e;
}();

module.exports = t;