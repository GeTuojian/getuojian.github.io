var e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/helpers/classCallCheck"));

module.exports = function i() {
    (0, e.default)(this, i), this.variableNameId = void 0, this.variableName = void 0, 
    this.type = void 0, this.inlineClassId = void 0;
};