var t = require("../../../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../../../@babel/runtime/helpers/classCallCheck")), i = t(require("../../../../@babel/runtime/helpers/createClass")), n = require("../../../../framework/utils/utf8_decode.js"), r = function() {
    function t(i) {
        (0, e.default)(this, t), this.$setArrayBuffer(i || new ArrayBuffer(0)), this.endian = 2;
    }
    return (0, i.default)(t, [ {
        key: "buffer",
        get: function() {
            return this._data.buffer;
        }
    }, {
        key: "data",
        get: function() {
            return this._data;
        },
        set: function(t) {
            this._data = t;
        }
    }, {
        key: "bufferOffset",
        get: function() {
            return this._data.byteOffset;
        }
    }, {
        key: "position",
        get: function() {
            return this._position;
        },
        set: function(t) {
            this._position = Math.max(0, Math.min(t, this.length));
        }
    }, {
        key: "length",
        get: function() {
            return this._data.byteLength;
        },
        set: function(t) {
            if (this.length != t) {
                var e = new Uint8Array(new ArrayBuffer(t));
                e.set(new Uint8Array(this.buffer, 0 + this.bufferOffset, Math.min(this.length, t))), 
                this._data = new DataView(e.buffer), this._position = Math.min(this._position, t);
            }
        }
    }, {
        key: "bytesAvailable",
        get: function() {
            return this._data.byteLength - this._position;
        }
    }, {
        key: "clear",
        value: function() {
            this.$setArrayBuffer(new ArrayBuffer(0));
        }
    }, {
        key: "$setArrayBuffer",
        value: function(t) {
            this._data = new DataView(t), this._position = 0;
        }
    }, {
        key: "readBoolean",
        value: function() {
            return 0 != this._data.getUint8(this.position++);
        }
    }, {
        key: "readByte",
        value: function() {
            return this._data.getInt8(this.position++);
        }
    }, {
        key: "readBytes",
        value: function(t) {
            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
            i = i || this.bytesAvailable, t.position = e, t.writeUint8Array(new Uint8Array(this.buffer, this._position + this.bufferOffset, i)), 
            this.position += i;
        }
    }, {
        key: "readDouble",
        value: function() {
            var t = this._data.getFloat64(this.position, 1 == this.endian);
            return this.position += 8, t;
        }
    }, {
        key: "readFloat",
        value: function() {
            var t = this._data.getFloat32(this.position, 1 == this.endian);
            return this.position += 4, t;
        }
    }, {
        key: "readInt",
        value: function() {
            var t = this._data.getInt32(this.position, 1 == this.endian);
            return this.position += 4, t;
        }
    }, {
        key: "readShort",
        value: function() {
            var t = this._data.getInt16(this.position, 1 == this.endian);
            return this.position += 2, t;
        }
    }, {
        key: "readUnsignedByte",
        value: function() {
            return this._data.getUint8(this.position++);
        }
    }, {
        key: "readUnsignedInt",
        value: function() {
            var t = this._data.getUint32(this.position, 1 == this.endian);
            return this.position += 4, t;
        }
    }, {
        key: "readUnsignedShort",
        value: function() {
            var t = this._data.getUint16(this.position, 1 == this.endian);
            return this.position += 2, t;
        }
    }, {
        key: "readUTF",
        value: function() {
            var t = this.readUnsignedShort();
            return 0 == t ? "" : this.readUTFBytes(t);
        }
    }, {
        key: "readUTFBytes",
        value: function(t) {
            var e = new Uint8Array(this.buffer, this.bufferOffset + this.position, t);
            return this.position += t, this.decodeUTF8(e);
        }
    }, {
        key: "readUnsignedByteOrShort",
        value: function() {
            var t = this.readUnsignedByte();
            return 255 != t ? t : this.readUnsignedShort();
        }
    }, {
        key: "readByteOrShort",
        value: function() {
            var t = this.readByte();
            return 255 != (255 & t) ? t : this.readShort();
        }
    }, {
        key: "readShortOrInt",
        value: function() {
            var t = this.readShort();
            return 65535 != (65535 & t) ? t : this.readInt();
        }
    }, {
        key: "readByteOrShortOrInt",
        value: function() {
            var t = this.readByte();
            return 255 != (255 & t) ? t : this.readShortOrInt();
        }
    }, {
        key: "readUnsignedShortOrInt",
        value: function() {
            var t = this.readUnsignedShort();
            return 65535 != t ? t : this.readUnsignedInt();
        }
    }, {
        key: "readUnsignedByteOrShortOrInt",
        value: function() {
            var t = this.readUnsignedByte();
            return 255 != t ? t : this.readUnsignedShortOrInt();
        }
    }, {
        key: "decodeUTF8",
        value: function(t) {
            return n(t);
        }
    } ]), t;
}();

module.exports = r;