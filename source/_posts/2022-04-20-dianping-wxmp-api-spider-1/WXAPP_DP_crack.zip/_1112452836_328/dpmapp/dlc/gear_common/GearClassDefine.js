var e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/helpers/classCallCheck"));

module.exports = function r() {
    (0, e.default)(this, r), this.className = null, this.variableArray = [];
};