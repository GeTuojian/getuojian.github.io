var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../@babel/runtime/helpers/classCallCheck")), i = e(require("../../../@babel/runtime/helpers/createClass"));

module.exports = function() {
    function e(i) {
        (0, t.default)(this, e), this.instancePool = {}, this.time = 0, this.version = 0, 
        this.m_stringPool = [], this.m_classPool = [];
    }
    return (0, i.default)(e, [ {
        key: "getString",
        value: function(e) {
            return this.m_stringPool[e];
        }
    }, {
        key: "dispose",
        value: function() {
            this.instancePool = null, this.m_stringPool = null, this.m_classPool = null;
        }
    } ]), e;
}();