var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), s = e(require("../../../@babel/runtime/helpers/classCallCheck")), t = e(require("../../../@babel/runtime/helpers/createClass"));

module.exports = function() {
    function e(t) {
        (0, s.default)(this, e), this.instanceUID = t, this._className = null;
    }
    return (0, t.default)(e, [ {
        key: "className",
        get: function() {
            return this._className;
        }
    }, {
        key: "decode",
        value: function(e, s) {}
    }, {
        key: "dispose",
        value: function() {
            this._className = null;
        }
    } ]), e;
}();