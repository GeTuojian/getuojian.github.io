var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), r = e(require("../../../@babel/runtime/helpers/classCallCheck")), a = e(require("../../../@babel/runtime/helpers/createClass")), t = e(require("../../../@babel/runtime/helpers/get")), s = e(require("../../../@babel/runtime/helpers/inherits")), n = e(require("../../../@babel/runtime/helpers/possibleConstructorReturn")), i = e(require("../../../@babel/runtime/helpers/getPrototypeOf"));

function l(e) {
    var r = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var a, t = (0, i.default)(e);
        if (r) {
            var s = (0, i.default)(this).constructor;
            a = Reflect.construct(t, arguments, s);
        } else a = t.apply(this, arguments);
        return (0, n.default)(this, a);
    };
}

var c = function(e) {
    (0, s.default)(c, e);
    var n = l(c);
    function c(e, a) {
        var t;
        return (0, r.default)(this, c), (t = n.call(this, e)).m_cs = a, t._className = a.className, 
        t;
    }
    return (0, a.default)(c, [ {
        key: "dispose",
        value: function() {
            if (this.m_cs) {
                for (var e = 0; e < this.m_cs.variableArray.length; e++) {
                    var r = this.m_cs.variableArray[e];
                    r.type > 22 && (this[r.variableName] = null);
                }
                this.m_cs = null;
            }
            (0, t.default)((0, i.default)(c.prototype), "dispose", this).call(this);
        }
    }, {
        key: "decode",
        value: function(e, r, a) {
            for (var t = 0; t < this.m_cs.variableArray.length; t++) {
                var s = this.m_cs.variableArray[t], n = c.getVariableBinData(s, a, e, r);
                this[s.variableName] = n;
            }
        }
    } ]), c;
}(require("./GearClassInstanceBase.js"));

c.getVariableBinData = function(e, r, a, t) {
    var s;
    switch (e.type) {
      case 1:
        s = r.readByte();
        break;

      case 2:
        s = r.readShort();
        break;

      case 3:
        s = r.readInt();
        break;

      case 4:
        s = r.readByteOrShort();
        break;

      case 5:
        s = r.readByteOrShortOrInt();
        break;

      case 6:
        s = r.readShortOrInt();
        break;

      case 11:
        s = r.readUnsignedByte();
        break;

      case 12:
        s = r.readUnsignedShort();
        break;

      case 13:
        s = r.readUnsignedInt();
        break;

      case 14:
        s = r.readUnsignedByteOrShort();
        break;

      case 15:
        s = r.readUnsignedByteOrShortOrInt();
        break;

      case 16:
        s = r.readUnsignedShortOrInt();
        break;

      case 21:
        s = r.readFloat();
        break;

      case 22:
        s = r.readDouble();
        break;

      case 31:
        s = t.getString(r.readUnsignedByteOrShort());
        break;

      case 41:
        s = a.getClassInstance(t, r.readUnsignedInt());
    }
    return s;
}, module.exports = c;