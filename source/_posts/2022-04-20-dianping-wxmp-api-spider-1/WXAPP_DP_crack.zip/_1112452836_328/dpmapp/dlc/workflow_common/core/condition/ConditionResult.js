var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../../../@babel/runtime/helpers/classCallCheck"));

module.exports = function t() {
    var i = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], l = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
    (0, e.default)(this, t), this.bool = i, this.isComplete = l;
};