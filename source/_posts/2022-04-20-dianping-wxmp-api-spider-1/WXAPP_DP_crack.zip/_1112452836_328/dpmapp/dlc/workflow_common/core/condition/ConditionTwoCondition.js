var t = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../../../../@babel/runtime/helpers/classCallCheck")), i = t(require("../../../../../@babel/runtime/helpers/createClass")), o = t(require("../../../../../@babel/runtime/helpers/get")), n = t(require("../../../../../@babel/runtime/helpers/inherits")), s = t(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = t(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function m(t) {
    var e = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (t) {
            return !1;
        }
    }();
    return function() {
        var i, o = (0, l.default)(t);
        if (e) {
            var n = (0, l.default)(this).constructor;
            i = Reflect.construct(o, arguments, n);
        } else i = o.apply(this, arguments);
        return (0, s.default)(this, i);
    };
}

var u = require("./ConditionBase.js"), h = require("./ConditionResult.js");

module.exports = function(t) {
    (0, n.default)(u, t);
    var s = m(u);
    function u(t, i, o) {
        var n;
        return (0, e.default)(this, u), (n = s.call(this)).m_condition0Func = t, n.m_condition1Func = i, 
        n.m_computeType = o, n.m_selfComplete = !1, n.m_selfFit = void 0, n;
    }
    return (0, i.default)(u, [ {
        key: "dispose",
        value: function() {
            this.reference--, this.reference || (this.m_condition0 && (this.m_condition0.dispose(), 
            this.m_condition0 = null), this.m_condition1 && (this.m_condition1.dispose(), this.m_condition1 = null), 
            this.m_condition0Func = null, this.m_condition1Func = null, (0, o.default)((0, l.default)(u.prototype), "dispose", this).call(this));
        }
    }, {
        key: "getConditionResult",
        value: function() {
            var t, e;
            if (this.m_condition0 || this.m_condition0Func && (this.m_condition0 = this.m_condition0Func(), 
            this.m_condition0Func = null, this.m_condition0 && this.m_condition0.addCallBack(this.onSubConditionChanged, this)), 
            this.m_condition1 || this.m_condition1Func && (this.m_condition1 = this.m_condition1Func(), 
            this.m_condition1Func = null, this.m_condition1 && this.m_condition1.addCallBack(this.onSubConditionChanged, this)), 
            this.m_condition0 && (t = this.m_condition0.getConditionResult()), t || (0 === this.m_computeType ? t = new h(!1, !0) : 1 === this.m_computeType ? t = new h(void 0, !1) : 2 === this.m_computeType && (t = new h(!0, !0))), 
            t.isComplete) if (0 === this.m_computeType) {
                if (t.bool) return this.m_selfComplete = !0, this.m_selfFit = !0, new h(this.m_selfFit, this.m_selfComplete);
            } else if (2 === this.m_computeType && !t.bool) return this.m_selfComplete = !0, 
            this.m_selfFit = !1, new h(this.m_selfFit, this.m_selfComplete);
            if (this.m_condition1 && (e = this.m_condition1.getConditionResult()), e || (0 === this.m_computeType ? e = new h(!1, !0) : 1 === this.m_computeType ? e = new h(void 0, !1) : 2 === this.m_computeType && (e = new h(!0, !0))), 
            e.isComplete) if (0 === this.m_computeType) {
                if (e.bool) return this.m_selfComplete = !0, this.m_selfFit = !0, new h(this.m_selfFit, this.m_selfComplete);
            } else if (2 === this.m_computeType && !e.bool) return this.m_selfComplete = !0, 
            this.m_selfFit = !1, new h(this.m_selfFit, this.m_selfComplete);
            return t.isComplete && e.isComplete ? (this.m_selfComplete = !0, 0 === this.m_computeType ? this.m_selfFit = !1 : 2 === this.m_computeType ? this.m_selfFit = t.bool && e.bool : 1 === this.m_computeType && (this.m_selfFit = t.bool && !e.bool || !t.bool && e.bool), 
            new h(this.m_selfFit, this.m_selfComplete)) : (this.m_selfFit = void 0, this.m_selfComplete = !1, 
            new h(this.m_selfFit, this.m_selfComplete));
        }
    }, {
        key: "onSubConditionChanged",
        value: function(t) {
            var e = this.m_selfFit, i = this.m_selfComplete, o = this.getConditionResult();
            o.isComplete === i && o.bool === e || o.isComplete && this.onConditionChange();
        }
    } ]), u;
}(u);