var t = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), i = t(require("../../../../../@babel/runtime/helpers/classCallCheck")), n = t(require("../../../../../@babel/runtime/helpers/createClass")), e = t(require("../../../../../@babel/runtime/helpers/get")), o = t(require("../../../../../@babel/runtime/helpers/inherits")), l = t(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), s = t(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function c(t) {
    var i = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (t) {
            return !1;
        }
    }();
    return function() {
        var n, e = (0, s.default)(t);
        if (i) {
            var o = (0, s.default)(this).constructor;
            n = Reflect.construct(e, arguments, o);
        } else n = e.apply(this, arguments);
        return (0, l.default)(this, n);
    };
}

var u = require("./ActionBase.js"), r = require("./ActionResult.js");

require("../condition/ConditionBase.js"), require("../condition/ConditionResult.js");

module.exports = function(t) {
    (0, o.default)(u, t);
    var l = c(u);
    function u(t, n, e) {
        var o;
        return (0, i.default)(this, u), (o = l.call(this)).conditionImpl = t, o.conditionTrueActionImpl = n, 
        o.conditionFalseActionImpl = e, o;
    }
    return (0, n.default)(u, [ {
        key: "onConditionResult",
        value: function(t) {
            t == this.conditionImpl && null != this.conditionImpl && (this.conditionImpl.getConditionResult().isComplete && (this.conditionImpl.removeCallBack(this.onConditionResult, this), 
            this.doAction()));
        }
    }, {
        key: "onSubFunctionComplete",
        value: function(t) {
            !t.isComplete || t.actionBase !== this.conditionTrueActionImpl && t.actionBase !== this.conditionFalseActionImpl || (null != this.completeFunction && this.completeFunction(new r(this, !0)), 
            this.dispose());
        }
    }, {
        key: "doAction",
        value: function() {
            if (null != this.conditionImpl) {
                var t = this.conditionImpl.getConditionResult();
                t.isComplete ? t.bool ? this.conditionTrueActionImpl ? (this.conditionTrueActionImpl.completeFunction = this.onSubFunctionComplete.bind(this), 
                this.conditionTrueActionImpl.doAction()) : (null != this.completeFunction && this.completeFunction(new r(this, !0)), 
                this.dispose()) : this.conditionFalseActionImpl ? (this.conditionFalseActionImpl.completeFunction = this.onSubFunctionComplete.bind(this), 
                this.conditionFalseActionImpl.doAction()) : (null != this.completeFunction && this.completeFunction(new r(this, !0)), 
                this.dispose()) : this.conditionImpl.addCallBack(this.onConditionResult, this);
            }
        }
    }, {
        key: "dispose",
        value: function() {
            (0, e.default)((0, s.default)(u.prototype), "dispose", this).call(this), this.conditionImpl && (this.conditionImpl.dispose(), 
            this.conditionImpl = null), this.conditionTrueActionImpl && (this.conditionTrueActionImpl.dispose(), 
            this.conditionTrueActionImpl = null), this.conditionFalseActionImpl && (this.conditionFalseActionImpl.dispose(), 
            this.conditionFalseActionImpl = null);
        }
    } ]), u;
}(u);