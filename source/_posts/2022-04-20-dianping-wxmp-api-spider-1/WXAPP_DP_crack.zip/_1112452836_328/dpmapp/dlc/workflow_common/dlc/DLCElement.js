var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), i = e(require("../../../../@babel/runtime/helpers/createClass")), a = require("./PageMVVM.js");

module.exports = function() {
    function e(i, a) {
        var n = this;
        (0, t.default)(this, e);
        var s = i.json;
        try {
            s = JSON.parse(s);
        } catch (e) {
            s = null;
        }
        if (s) {
            var r = i.defaultData;
            try {
                r = JSON.parse(r);
            } catch (e) {
                r = {};
            }
            this._mvvmData = s, this._defaultData = r, this._funcDict = {}, this.globalId = i.globalId, 
            this._isResident = i.isResident;
            var l = a.instancePool, c = function(e) {
                var t = l[e];
                if (t && "ActionNamedFunction" === t.className) {
                    var i = !n._isResident;
                    n._funcDict[t.functionName] = function(e) {
                        1 === t.closePanel && e._$_close(i);
                        var a = t.triggerAction;
                        if (a) {
                            var n = require("../Workflow.js"), s = n.getSingleton().createGearImpl(a);
                            s.completeFunction = function(a) {
                                2 === t.closePanel && e._$_close(i);
                            };
                            for (var r = arguments.length, l = new Array(r > 1 ? r - 1 : 0), c = 1; c < r; c++) l[c - 1] = arguments[c];
                            s.doAction.apply(s, [ e ].concat(l));
                        } else 2 === t.closePanel && e._$_close(i);
                    };
                }
            };
            for (var u in l) c(u);
        }
    }
    return (0, i.default)(e, [ {
        key: "createPageMVVM",
        value: function() {
            if (this._mvvmData) {
                if (this._pageMVVM) return this._pageMVVM;
                var e = new a(this.globalId, this._mvvmData, this._defaultData, this._isResident);
                if (this._funcDict) for (var t in this._funcDict) e._$_addFunction(t, this._funcDict[t]);
                return e.onLoad && e.onLoad({}), this._isResident && (this._pageMVVM = e), e;
            }
        }
    }, {
        key: "dispose",
        value: function() {
            if (this._mvvmData = null, this._defaultData = null, this._funcDict) {
                for (var e in this._funcDict) delete this._funcDict[e];
                this._funcDict = null;
            }
            this._pageMVVM && (this._pageMVVM._$_dispose(), this._pageMVVM = null);
        }
    } ]), e;
}();