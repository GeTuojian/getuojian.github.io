var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), i = e(require("../../../../../@babel/runtime/helpers/createClass"));

module.exports = function() {
    function e() {
        var i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null, l = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        (0, t.default)(this, e), this.actionBase = i, this.isComplete = l;
    }
    return (0, i.default)(e, [ {
        key: "dispose",
        value: function() {
            this.actionBase = null;
        }
    } ]), e;
}();