var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), i = e(require("../../../../../@babel/runtime/helpers/createClass"));

module.exports = function() {
    function e() {
        (0, t.default)(this, e), this.m_isActive = !1;
    }
    return (0, i.default)(e, [ {
        key: "isActive",
        get: function() {
            return this.m_isActive;
        }
    }, {
        key: "dispose",
        value: function() {}
    }, {
        key: "activate",
        value: function() {
            this.m_isActive = !0;
        }
    }, {
        key: "trigger",
        value: function() {}
    } ]), e;
}();