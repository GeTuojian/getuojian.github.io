var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), i = e(require("../../../../@babel/runtime/helpers/createClass")), a = function() {
    function e(i, a, s, n) {
        (0, t.default)(this, e), this.layoutTid = 0, this.pageName = this.signalName = i, 
        this.isResident = n, this.mvvmData = a, this.data = require("../../../../framework/utils/deep_clone.js")(s), 
        this.data.pageProtocol && (this.data.pageProtocol = "https"), this.data.IS_WXMP = 1, 
        this._funcDict = {}, this.cssDomain = null, this.cocktailNode = null, this.maskType = 0, 
        this.animeType = 0, this._$_appFake = e.createAppFake();
    }
    return (0, i.default)(e, [ {
        key: "_$_init",
        value: function(e, t, i) {
            e && (this.signalName = e);
            var a = require("./lib/cocktail_node/cocktail_node_base.js"), s = require("./lib/cocktail_node_style/cocktail_node_style_domain.js");
            a.mappingBridge || (a.mappingBridge = require("./lib/cocktail_node_x_vm/cocktail_node_x_vm_bridge.js")), 
            this.mvvmData.css && (this.cssDomain = new s({
                css: this.mvvmData.css
            })), this._$_render(), t && (this.renderCallback = t), i && (this.closeCallback = i);
        }
    }, {
        key: "setData",
        value: function(e) {
            var t = this;
            Object.assign(this.data, e), this.cocktailNode && (this.layoutTid || (this.layoutTid = setTimeout(function() {
                clearTimeout(t.layoutTid), t.layoutTid = 0, t._$_render();
            }, 0)));
        }
    }, {
        key: "_$_addFunction",
        value: function(e, t) {
            var i = this;
            this._funcDict[e] = 1, this[e] = function() {
                for (var e = arguments.length, a = new Array(e), s = 0; s < e; s++) a[s] = arguments[s];
                t.apply(null, [ i ].concat(a));
            };
        }
    }, {
        key: "_$_close",
        value: function(e) {
            this.onHide && this.onHide({}), this.closeCallback ? this.closeCallback(this, e ? this._$_dispose : null) : e && this._$_dispose();
        }
    }, {
        key: "_$_render",
        value: function() {
            var e = this, t = require("./lib/cocktail_node/cocktail_node_diff.js"), i = require("./lib/cocktail_node_style/cocktail_node_style_calc_layout.js"), a = require("./lib/cocktail_node_x_vm/cocktail_node_x_vm_style_mapping.js");
            this.cocktailNode = t.getCocktailNodeRoot(this.data, {
                node: this.mvvmData.node
            }, this.cssDomain, !0, this.signalName);
            var s = 750 * getApp().runtimeInfo.windowHeight / getApp().runtimeInfo.windowWidth;
            i(this.cocktailNode, null, 750, s, function() {
                e.layoutTid || (e.layoutTid = setTimeout(function() {
                    clearTimeout(e.layoutTid), e.layoutTid = 0, e._$_render();
                }, 0));
            }, function(e, t) {
                return 1.14 * Math.max(32, e);
            }), this.inputs || (this.inputs = {}), a(this.cocktailNode, 750, s, this), this.renderCallback && this.renderCallback(this), 
            t.setCocktialNodeRendered(this.cocktailNode);
        }
    }, {
        key: "_$_dispose",
        value: function() {
            if (this.onUnload && this.onUnload({}), this._funcDict) {
                for (var e in this._funcDict) this[e] = null;
                this._funcDict = null;
            }
            this.cssDomain && (this.cssDomain.dispose(), this.cssDomain = null), this.mvvmData = null, 
            this.data = null, this.cocktailNode && (this.cocktailNode.dispose(!0), this.cocktailNode = null), 
            this.renderCallback = null, this.closeCallback = null, this.pageName = this.signalName = null, 
            this._$_appFake && (this._$_appFake.env && (this._$_appFake.env.dispose(), this._$_appFake.env = null), 
            this._$_appFake = null);
        }
    } ]), e;
}();

a.createAppFake = function() {
    var e = Object.assign({}, getApp());
    return e.env = {
        extraHold: [],
        register: function(t, i, a) {
            e.env.extraHold.push({
                evtId: t,
                callBackFunc: i,
                refer: a
            }), getApp().env.register(t, i, a);
        },
        notify: function(e, t, i) {
            getApp().env.notify(e, t, i);
        },
        unregister: function(t, i, a) {
            getApp().env.unregister(t, i, a);
            for (var s = e.env.extraHold, n = 0; n < s.length; n++) {
                var l = s[n];
                if (l.evtId === t && l.callBackFunc === i && l.refer === a) return void s.splice(n);
            }
        },
        dispose: function() {
            for (var t = e.env.extraHold, i = 0; i < t.length; i++) {
                var a = t[i];
                getApp().env.unregister(a.evtId, a.callBackFunc, a.refer), t[i] = null;
            }
            e.env.extraHold = null;
        }
    }, e;
}, module.exports = a;