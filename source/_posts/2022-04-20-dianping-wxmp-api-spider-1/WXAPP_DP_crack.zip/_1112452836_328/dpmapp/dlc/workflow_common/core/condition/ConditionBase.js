var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), a = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), l = e(require("../../../../../@babel/runtime/helpers/createClass"));

module.exports = function() {
    function e() {
        (0, a.default)(this, e), this.reference = 1, this.m_callBackArray = null;
    }
    return (0, l.default)(e, [ {
        key: "getInstance",
        value: function() {
            return this.reference++, this;
        }
    }, {
        key: "getConditionResult",
        value: function() {
            return null;
        }
    }, {
        key: "addCallBack",
        value: function(e, a) {
            -1 === this.getCallFuncIdx(e, a) && this.m_callBackArray.push({
                func: e,
                ref: a
            });
        }
    }, {
        key: "removeCallBack",
        value: function(e, a) {
            if (this.m_callBackArray) {
                var l = this.getCallFuncIdx(e, a);
                -1 !== l && this.m_callBackArray.splice(l, 1);
            }
        }
    }, {
        key: "getCallFuncIdx",
        value: function(e, a) {
            var l = -1;
            if (!this.m_callBackArray) return this.m_callBackArray = [], l;
            for (var r = 0; r < this.m_callBackArray.length; r++) {
                var t = this.m_callBackArray[r];
                if (t.func === e && t.ref === a) {
                    l = r;
                    break;
                }
            }
            return l;
        }
    }, {
        key: "onConditionChange",
        value: function() {
            var e = this;
            this.m_callBackArray && this.m_callBackArray.slice().forEach(function(a) {
                -1 != e.getCallFuncIdx(a.func, a.ref) && a.func.call(a.ref, e);
            });
        }
    }, {
        key: "dispose",
        value: function() {
            this.m_callBackArray = null;
        }
    } ]), e;
}();