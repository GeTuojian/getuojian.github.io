var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../../@babel/runtime/helpers/createClass")), u = e(require("../../../../../@babel/runtime/helpers/get")), n = e(require("../../../../../@babel/runtime/helpers/inherits")), i = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function s(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, u = (0, l.default)(e);
        if (t) {
            var n = (0, l.default)(this).constructor;
            r = Reflect.construct(u, arguments, n);
        } else r = u.apply(this, arguments);
        return (0, i.default)(this, r);
    };
}

var o = require("./ConditionBase.js"), a = require("./ConditionResult.js");

module.exports = function(e) {
    (0, n.default)(o, e);
    var i = s(o);
    function o() {
        return (0, t.default)(this, o), i.apply(this, arguments);
    }
    return (0, r.default)(o, [ {
        key: "getConditionResult",
        value: function() {
            return new a(!1, !0);
        }
    }, {
        key: "dispose",
        value: function() {
            this.reference--, this.reference || (0, u.default)((0, l.default)(o.prototype), "dispose", this).call(this);
        }
    } ]), o;
}(o);