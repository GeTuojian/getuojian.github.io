var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), a = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), l = e(require("../../../../../@babel/runtime/helpers/createClass"));

module.exports = function() {
    function e() {
        (0, a.default)(this, e), this.reference = 1, this.m_callBackArray = null;
    }
    return (0, l.default)(e, [ {
        key: "everSetValue",
        get: function() {
            return this._everSetValue;
        }
    }, {
        key: "value",
        get: function() {
            return this._everSetValue ? this._value : void 0;
        },
        set: function(e) {
            var a = !1;
            this._everSetValue ? a = this._value !== e : (a = !0, this._everSetValue = !0), 
            this._value = e, a && this.onVariableChange();
        }
    }, {
        key: "addCallBack",
        value: function(e) {
            this.m_callBackArray ? this.m_callBackArray.push(e) : this.m_callBackArray = [ e ];
        }
    }, {
        key: "removeCallBack",
        value: function(e) {
            this.m_callBackArray && (-1 !== this.m_callBackArray.indexOf(e) && this.m_callBackArray.splice(this.m_callBackArray.indexOf(e), 1));
        }
    }, {
        key: "onVariableChange",
        value: function() {
            var e = this;
            this.m_callBackArray && this.m_callBackArray.slice().forEach(function(a) {
                -1 != e.m_callBackArray.indexOf(a) && a(e);
            });
        }
    }, {
        key: "getInstance",
        value: function() {
            return this.reference++, this;
        }
    }, {
        key: "dispose",
        value: function() {
            this.m_callBackArray = null, this._value = null;
        }
    } ]), e;
}();