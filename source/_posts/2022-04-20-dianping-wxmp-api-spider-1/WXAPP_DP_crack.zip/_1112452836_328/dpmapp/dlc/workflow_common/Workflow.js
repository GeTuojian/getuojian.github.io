var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), n = e(require("../../../@babel/runtime/helpers/classCallCheck")), i = e(require("../../../@babel/runtime/helpers/createClass"));

module.exports = function() {
    function e(i, t) {
        var r = this;
        (0, n.default)(this, e), this._gearImplMap = {}, this._gearEnv = t, this._residentImplIns = {}, 
        this._app = i, e.getSingleton = function() {
            return r;
        }, this._runningScript = [], this.init.apply(this);
    }
    return (0, i.default)(e, [ {
        key: "dispose",
        value: function() {
            if (this._app = null, this._gearEnv = null, this.workflow = null, this._gearImplMap && (this._gearImplMap.forEach(function(e) {
                return e.dispose();
            }), this._gearImplMap = null), this._runningScript) {
                for (;this._runningScript.length; ) this.unloadGearScript(this._runningScript[this._runningScript.length - 1]);
                this._runningScript = null;
            }
            e.getSingleton = null;
        }
    }, {
        key: "init",
        value: function() {}
    }, {
        key: "activateGearScript",
        value: function(e) {
            var n = this, i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            e.__triggers.forEach(function(t) {
                var r = t.trigger, a = t.instanceUID;
                r.activate(), i && "TriggerOnScriptIninted" === e.instancePool[a].className && (r.dispose(), 
                n._gearEnv.disposeInstance(e, a));
            }), e.__triggers = null;
        }
    }, {
        key: "runGearScript",
        value: function(e) {
            var n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0;
            if (void 0 === i && (i = !0), -1 === this._runningScript.indexOf(e)) {
                this._runningScript.push(e);
                var t = e.instancePool, r = this._residentImplIns;
                e.__implInstancePool = {}, e.__triggers = [];
                var a = this;
                l(t, e.__triggers), c(t);
                var s = this._runningScript.indexOf(e);
                -1 !== s ? n || this.activateGearScript(e, i) : this._runningScript.splice(s, 1);
            }
            function l(n, i) {
                for (var t in n) {
                    var s = n[t];
                    if (s) {
                        var l = s.className, c = l.substring(0, 7);
                        if ("Trigger" === c) {
                            var o = a.createGearImpl(s, !0);
                            e.__implInstancePool[t] = o, i.push({
                                trigger: o,
                                instanceUID: s.instanceUID
                            });
                        } else if ("Variabl" === c || "Conditi" === c) if ("VariableGlobal" !== l) {
                            var u = a.createGearImpl(s, !0), p = r[t] = {
                                func: u.getInstance.bind(u),
                                instance: u
                            };
                            e.__implInstancePool[t] = p.func();
                        } else {
                            var _ = s.globalId;
                            for (var f in r) {
                                var g = r[f];
                                if (g.instance.globalId === _) {
                                    r[t] = g, e.__implInstancePool[t] = g.func();
                                    break;
                                }
                            }
                            if (!r[t]) {
                                a.createGearImpl(s, !0);
                                var v = r[t] = {
                                    func: implIns.getInstance.bind(implIns),
                                    instance: implIns
                                };
                                e.__implInstancePool[t] = v.func();
                            }
                        }
                    }
                }
            }
            function c(n) {
                for (var i in n) {
                    var t = n[i];
                    if (t) {
                        var s = t.className;
                        if ("View" === s.substring(0, 4)) {
                            var l = a.createGearImpl(t, !0);
                            e.__implInstancePool[i] = l;
                        } else if ("DLCElement" === s) {
                            var c = new (require("./dlc/DLCElement.js"))(t, e);
                            r[i] = {
                                func: null,
                                instance: c
                            }, e.__implInstancePool[i] = c;
                        }
                    }
                }
            }
        }
    }, {
        key: "unloadGearScript",
        value: function(e) {
            e.__triggers = null;
            var n = e.instancePool, i = this._residentImplIns;
            !function(n) {
                for (var t in n) {
                    var r = n[t];
                    if (r) {
                        var a = r.className;
                        if ("View" === a.substring(0, 4)) {
                            var s = e.__implInstancePool[t];
                            s && s.dispose(), delete e.__implInstancePool[t], delete e.__implInstancePool[t];
                        } else if ("DLCElement" === a) {
                            var l = e.__implInstancePool[t];
                            l && l.dispose(), delete i[t], delete e.__implInstancePool[t];
                        }
                    }
                }
            }(n), function(n) {
                for (var t in n) {
                    var r = n[t];
                    if (r) {
                        var a = r.className.substring(0, 7);
                        if ("Trigger" === a) {
                            var s = e.__implInstancePool[t];
                            s && s.dispose(), delete e.__implInstancePool[t];
                        } else if ("Variabl" === a || "Conditi" === a) {
                            var l = e.__implInstancePool[t];
                            l && l.dispose(), i[t].instance.dispose(), delete i[t], delete e.__implInstancePool[t];
                        }
                    }
                }
            }(n), delete e.__implInstancePool;
        }
    }, {
        key: "findResidentImpl",
        value: function(e) {
            for (var n in this._residentImplIns) {
                var i = this._residentImplIns[n];
                if (e(i.instance)) return i;
            }
            return null;
        }
    }, {
        key: "createGearImpl",
        value: function(e) {
            if (!e) return null;
            var n = this._residentImplIns[e.instanceUID];
            if (n && n.func) return n.func();
            var i = this._gearImplMap[e.className];
            return i ? new i(e, this._app) : null;
        }
    } ]), e;
}();

require("../gear_common/GearEnv.js");