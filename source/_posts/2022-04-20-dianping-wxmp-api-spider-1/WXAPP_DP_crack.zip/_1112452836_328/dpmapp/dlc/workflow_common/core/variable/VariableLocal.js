var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), r = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), t = e(require("../../../../../@babel/runtime/helpers/createClass")), u = e(require("../../../../../@babel/runtime/helpers/get")), l = e(require("../../../../../@babel/runtime/helpers/inherits")), n = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), a = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function i(e) {
    var r = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var t, u = (0, a.default)(e);
        if (r) {
            var l = (0, a.default)(this).constructor;
            t = Reflect.construct(u, arguments, l);
        } else t = u.apply(this, arguments);
        return (0, n.default)(this, t);
    };
}

var s = require("./VariableBase.js");

module.exports = function(e) {
    (0, l.default)(s, e);
    var n = i(s);
    function s(e) {
        var t;
        return (0, r.default)(this, s), t = n.call(this), e.hasDefaultValue && (t.value = e.defaultValue), 
        t;
    }
    return (0, t.default)(s, [ {
        key: "dispose",
        value: function() {
            this.reference--, this.reference || (0, u.default)((0, a.default)(s.prototype), "dispose", this).call(this);
        }
    } ]), s;
}(s);