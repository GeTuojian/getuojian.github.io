var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../@babel/runtime/helpers/classCallCheck")), i = e(require("../../../@babel/runtime/helpers/createClass"));

module.exports = function() {
    function e(i) {
        (0, t.default)(this, e), this.env = i, i.register("__ON_GEAR_VIEW_ADD__", this._onAddGear, this), 
        i.register("__ON_GEAR_VIEW_REMOVE__", this._onRemoveGear, this), this.dict = {};
    }
    return (0, i.default)(e, [ {
        key: "getExistGearView",
        value: function(e) {
            return this.dict[e];
        }
    }, {
        key: "_onAddGear",
        value: function(e, t, i, r) {
            if (t.gear) {
                var a = t.gear.className, n = t.gear.instanceUID;
                r.dict[a] || (r.dict[a] = {}, Object.defineProperty(r.dict[a], "forEach", {
                    value: function(e) {
                        var t = this;
                        Object.keys(this).forEach(function(i, r) {
                            e(t[i], r);
                        });
                    },
                    enumerable: !1
                })), r.dict[a][n] = t.gear;
            }
        }
    }, {
        key: "_onRemoveGear",
        value: function(e, t, i, r) {
            if (t.gear) {
                var a = t.gear.className, n = t.gear.instanceUID;
                if (!r.dict[a]) return;
                delete r.dict[a][n];
            }
        }
    }, {
        key: "dispose",
        value: function() {
            this.env && (this.env.unregister("__ON_GEAR_VIEW_ADD__", this._onAddGear, this), 
            this.env.unregister("__ON_GEAR_VIEW_REMOVE__", this._onRemoveGear, this));
        }
    } ]), e;
}();