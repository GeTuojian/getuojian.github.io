var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../../@babel/runtime/helpers/createClass")), i = e(require("../../../../../@babel/runtime/helpers/get")), s = e(require("../../../../../@babel/runtime/helpers/inherits")), a = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), o = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function n(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, i = (0, o.default)(e);
        if (t) {
            var s = (0, o.default)(this).constructor;
            r = Reflect.construct(i, arguments, s);
        } else r = i.apply(this, arguments);
        return (0, a.default)(this, r);
    };
}

var u = require("../../../workflow_common/core/variable/VariableBase.js"), l = require("../../../../../framework/utils/storage.js");

module.exports = function(e) {
    (0, s.default)(u, e);
    var a = n(u);
    function u(e) {
        var r;
        (0, t.default)(this, u), (r = a.call(this))._isFitDevUser = void 0, r._isActiveDevMode = void 0;
        var i = l.getLocalStorageSync("__GEAR_DEBUG_INFO__");
        if (i && i.enable && Math.floor(Date.now() / 1e3) < i.expireTime && (r._isFitDevUser = 1), 
        r.globalId = "__G_ENABLE_DEBUG__", void 0 === r._isFitDevUser) {
            var s = require("../../../../../framework/class_define/http_protocol.js"), o = require("../../../../../framework/class_define/http_request_task.js");
            e.h.request(new o(new s("/an/gear/dpmapp/api/readLionConfig/debugCheck", {
                domain: e.appConfig.DOMAIN,
                header: {
                    openidPlt: ""
                }
            }), {
                callback: function(e) {
                    if (0 === e.errorCode && e.data && e.data.i > -1) return i = {
                        enable: 1,
                        expireTime: Math.floor(Date.now() / 1e3) + 172800
                    }, l.setLocalStorageSync("__GEAR_DEBUG_INFO__", i), void (r.isFitDevUser = 1);
                    r.isFitDevUser = 0, r.value = 0;
                }
            }));
        }
        return r;
    }
    return (0, r.default)(u, [ {
        key: "isFitDevUser",
        set: function(e) {
            this._isFitDevUser = e, 0 === e ? this.value = 0 : this._isActiveDevMode && (this.value = 1);
        }
    }, {
        key: "isActiveDevMode",
        set: function(e) {
            this._isActiveDevMode = e, 0 === e ? this.value = 0 : this._isFitDevUser && (this.value = 1);
        }
    }, {
        key: "dispose",
        value: function() {
            this.reference--, this.reference || (0, i.default)((0, o.default)(u.prototype), "dispose", this).call(this);
        }
    } ]), u;
}(u);