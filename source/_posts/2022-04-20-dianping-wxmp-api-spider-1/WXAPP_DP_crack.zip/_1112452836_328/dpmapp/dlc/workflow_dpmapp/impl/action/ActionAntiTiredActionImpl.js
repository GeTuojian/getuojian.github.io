var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), i = e(require("../../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../../@babel/runtime/helpers/get")), r = e(require("../../../../../@babel/runtime/helpers/inherits")), o = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), c = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function a(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var i, n = (0, c.default)(e);
        if (t) {
            var r = (0, c.default)(this).constructor;
            i = Reflect.construct(n, arguments, r);
        } else i = n.apply(this, arguments);
        return (0, o.default)(this, i);
    };
}

var l = require("../../../workflow_common/core/action/ActionBase.js"), s = require("../../../workflow_common/core/action/ActionResult.js"), u = "__CONFIG@APP:ANTI_TIRED_UID_";

module.exports = function(e) {
    (0, r.default)(l, e);
    var o = a(l);
    function l(e) {
        var i;
        return (0, t.default)(this, l), (i = o.call(this)).m_actionAntiTiredActionVO = e, 
        i;
    }
    return (0, i.default)(l, [ {
        key: "doAction",
        value: function() {
            if (this.m_actionAntiTiredActionVO) {
                var e = this, t = !0;
                if (this.m_actionAntiTiredActionVO.antiTiredTime > 0) {
                    var i = require("../../../../../framework/utils/storage.js"), n = i.getLocalStorageSync(u + this.m_actionAntiTiredActionVO.instanceUID) || [], r = Date.now() / 1e3, o = this.m_actionAntiTiredActionVO.antiTiredTime, c = n.length, a = (n = n.filter(function(e) {
                        return r - e < o;
                    })).length;
                    if (a !== c && i.setLocalStorageSync(u + this.m_actionAntiTiredActionVO.instanceUID, n), 
                    a < this.m_actionAntiTiredActionVO.tiredTimes) t = !0; else if (t = !1, this.m_actionAntiTiredActionVO.clearOnDay) {
                        var l = new Date(lastTS).getDate();
                        new Date(nowTs).getDate() !== l && (t = !0, i.setLocalStorageSync(u + this.m_actionAntiTiredActionVO.instanceUID, []));
                    }
                }
                var f = t ? this.m_actionAntiTiredActionVO.commonAction : this.m_actionAntiTiredActionVO.tiredAction;
                if (f) {
                    var m = require("../../WorkflowDP.js").getSingleton().createGearImpl(f);
                    if (m) return m.completeFunction = function(t) {
                        if (e.m_actionAntiTiredActionVO.antiTiredTime > 0) {
                            var i = require("../../../../../framework/utils/storage.js"), n = i.getLocalStorageSync(u + e.m_actionAntiTiredActionVO.instanceUID) || [];
                            n.push(Math.floor(Date.now() / 1e3)), i.setLocalStorageSync(u + e.m_actionAntiTiredActionVO.instanceUID, n);
                        }
                        e.completeFunction && e.completeFunction(new s(e, t.isComplete)), e.dispose(), e = null;
                    }, void m.doAction();
                }
                e.completeFunction && e.completeFunction(new s(e, !0)), e.dispose(), e = null;
            }
        }
    }, {
        key: "dispose",
        value: function() {
            (0, n.default)((0, c.default)(l.prototype), "dispose", this).call(this), this.m_actionAntiTiredActionVO = null;
        }
    } ]), l;
}(l);