var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), i = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), t = e(require("../../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../../@babel/runtime/helpers/assertThisInitialized")), o = e(require("../../../../../@babel/runtime/helpers/get")), r = e(require("../../../../../@babel/runtime/helpers/inherits")), s = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function u(e) {
    var i = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var t, n = (0, l.default)(e);
        if (i) {
            var o = (0, l.default)(this).constructor;
            t = Reflect.construct(n, arguments, o);
        } else t = n.apply(this, arguments);
        return (0, s.default)(this, t);
    };
}

var m = require("../../../workflow_common/core/condition/ConditionBase.js"), h = require("../../../workflow_common/core/condition/ConditionResult.js");

module.exports = function(e) {
    (0, r.default)(m, e);
    var s = u(m);
    function m(e, t) {
        var o;
        return (0, i.default)(this, m), (o = s.call(this)).m_conditionMultiTimeZone8VO = e, 
        Object.defineProperty((0, n.default)(o), "_app", {
            value: t,
            enumerable: !1,
            writable: !0
        }), o._app.env.register(21007, o._timeChange, (0, n.default)(o)), o;
    }
    return (0, t.default)(m, [ {
        key: "_timeChange",
        value: function(e, i, t, n) {
            n.serverTime = i.serverTime;
            var o = n.recentConditionResult;
            n.getConditionResult(), n.recentConditionResult.isComplete && (o && o.isComplete && o.bool === n.recentConditionResult.bool || n.onConditionChange()), 
            o = null;
        }
    }, {
        key: "getConditionResult",
        value: function() {
            if (void 0 === this.serverTime) this.recentConditionResult = new h(!1, !1); else {
                var e = this.m_conditionMultiTimeZone8VO.t1 && 1e3 * this.m_conditionMultiTimeZone8VO.t0 < this.serverTime && 1e3 * this.m_conditionMultiTimeZone8VO.t1 > this.serverTime || this.m_conditionMultiTimeZone8VO.t3 && 1e3 * this.m_conditionMultiTimeZone8VO.t2 < this.serverTime && 1e3 * this.m_conditionMultiTimeZone8VO.t3 > this.serverTime || this.m_conditionMultiTimeZone8VO.t5 && 1e3 * this.m_conditionMultiTimeZone8VO.t4 < this.serverTime && 1e3 * this.m_conditionMultiTimeZone8VO.t5 > this.serverTime || this.m_conditionMultiTimeZone8VO.t7 && 1e3 * this.m_conditionMultiTimeZone8VO.t6 < this.serverTime && 1e3 * this.m_conditionMultiTimeZone8VO.t7 > this.serverTime || this.m_conditionMultiTimeZone8VO.t9 && 1e3 * this.m_conditionMultiTimeZone8VO.t8 < this.serverTime && 1e3 * this.m_conditionMultiTimeZone8VO.t9 > this.serverTime || this.m_conditionMultiTimeZone8VO.t11 && 1e3 * this.m_conditionMultiTimeZone8VO.t10 < this.serverTime && 1e3 * this.m_conditionMultiTimeZone8VO.t11 > this.serverTime || this.m_conditionMultiTimeZone8VO.t13 && 1e3 * this.m_conditionMultiTimeZone8VO.t12 < this.serverTime && 1e3 * this.m_conditionMultiTimeZone8VO.t13 > this.serverTime || this.m_conditionMultiTimeZone8VO.t15 && 1e3 * this.m_conditionMultiTimeZone8VO.t14 < this.serverTime && 1e3 * this.m_conditionMultiTimeZone8VO.t15 > this.serverTime;
                e = this.m_conditionMultiTimeZone8VO.reverseReturn ? !e : e, this.recentConditionResult = new h(e, !0);
            }
            return this.recentConditionResult;
        }
    }, {
        key: "dispose",
        value: function() {
            this.reference--, this.reference || (this._app && (this._app.env.unregister(21007, this._timeChange, this), 
            this._app = null), this.m_conditionMultiTimeZone8VO = null, this.recentConditionResult = null, 
            this.serverTime = null, (0, o.default)((0, l.default)(m.prototype), "dispose", this).call(this));
        }
    } ]), m;
}(m);