var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), r = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), t = e(require("../../../../../@babel/runtime/helpers/createClass")), i = e(require("../../../../../@babel/runtime/helpers/get")), a = e(require("../../../../../@babel/runtime/helpers/inherits")), n = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function o(e) {
    var r = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var t, i = (0, l.default)(e);
        if (r) {
            var a = (0, l.default)(this).constructor;
            t = Reflect.construct(i, arguments, a);
        } else t = i.apply(this, arguments);
        return (0, n.default)(this, t);
    };
}

var u = require("../../../workflow_common/core/trigger/TriggerBase.js");

require("../../../workflow_common/Workflow.js");

module.exports = function(e) {
    (0, a.default)(u, e);
    var n = o(u);
    function u(e, t) {
        var i;
        return (0, r.default)(this, u), (i = n.call(this)).m_triggerOnVariableChangedVO = e, 
        i;
    }
    return (0, t.default)(u, [ {
        key: "activate",
        value: function() {
            if ((0, i.default)((0, l.default)(u.prototype), "activate", this).call(this), !this.m_varImpl) {
                var e = require("../../WorkflowDP.js");
                this.m_varImpl = e.getSingleton().createGearImpl(this.m_triggerOnVariableChangedVO.variable), 
                this._onVarChanged = this.__onVarChanged.bind(this), this.m_varImpl.addCallBack(this._onVarChanged);
            }
        }
    }, {
        key: "__onVarChanged",
        value: function(e) {
            this.trigger();
        }
    }, {
        key: "trigger",
        value: function() {
            if (this.m_triggerOnVariableChangedVO && this.m_triggerOnVariableChangedVO.triggerAction) {
                var e = require("../../../workflow_common/Workflow.js"), r = e.getSingleton().createGearImpl(this.m_triggerOnVariableChangedVO.triggerAction);
                r && r.doAction();
            }
        }
    }, {
        key: "dispose",
        value: function() {
            this.m_varImpl && (this._onVarChanged && (this.m_varImpl.removeCallBack(this._onVarChanged), 
            this._onVarChanged = null), this.m_varImpl.dispose(), this.m_varImpl = null), this.m_triggerOnVariableChangedVO = null, 
            (0, i.default)((0, l.default)(u.prototype), "dispose", this).call(this);
        }
    } ]), u;
}(u);