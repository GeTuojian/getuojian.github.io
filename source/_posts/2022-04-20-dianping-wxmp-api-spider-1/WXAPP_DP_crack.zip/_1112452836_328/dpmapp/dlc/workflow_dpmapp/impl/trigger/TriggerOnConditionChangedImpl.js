var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), i = e(require("../../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../../@babel/runtime/helpers/get")), r = e(require("../../../../../@babel/runtime/helpers/inherits")), o = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function a(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var i, n = (0, l.default)(e);
        if (t) {
            var r = (0, l.default)(this).constructor;
            i = Reflect.construct(n, arguments, r);
        } else i = n.apply(this, arguments);
        return (0, o.default)(this, i);
    };
}

var u = require("../../../workflow_common/core/trigger/TriggerBase.js");

require("../../../workflow_common/Workflow.js");

module.exports = function(e) {
    (0, r.default)(u, e);
    var o = a(u);
    function u(e, i) {
        var n;
        return (0, t.default)(this, u), (n = o.call(this)).m_triggerOnConditionChangedVO = e, 
        n;
    }
    return (0, i.default)(u, [ {
        key: "activate",
        value: function() {
            if ((0, n.default)((0, l.default)(u.prototype), "activate", this).call(this), !this.m_conditionImpl) {
                var e = require("../../WorkflowDP.js");
                this.m_conditionImpl = e.getSingleton().createGearImpl(this.m_triggerOnConditionChangedVO.condition), 
                this._onConditionChanged = this.__onConditionChanged.bind(this), this.m_conditionImpl.addCallBack(this._onConditionChanged);
            }
        }
    }, {
        key: "__onConditionChanged",
        value: function(e) {
            this.trigger();
        }
    }, {
        key: "trigger",
        value: function() {
            if (this.m_triggerOnConditionChangedVO && this.m_triggerOnConditionChangedVO.triggerAction) {
                var e = require("../../../workflow_common/Workflow.js"), t = e.getSingleton().createGearImpl(this.m_triggerOnConditionChangedVO.triggerAction);
                t && t.doAction();
            }
        }
    }, {
        key: "dispose",
        value: function() {
            this.m_conditionImpl && (this._onConditionChanged && (this.m_conditionImpl.removeCallBack(this._onConditionChanged), 
            this._onConditionChanged = null), this.m_conditionImpl.dispose(), this.m_conditionImpl = null), 
            this.m_triggerOnConditionChangedVO = null, this._triggeredPages = null, (0, n.default)((0, 
            l.default)(u.prototype), "dispose", this).call(this);
        }
    } ]), u;
}(u);