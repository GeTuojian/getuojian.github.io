var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../../@babel/runtime/helpers/inherits")), n = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), o = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function i(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, i = (0, o.default)(e);
        if (t) {
            var u = (0, o.default)(this).constructor;
            r = Reflect.construct(i, arguments, u);
        } else r = i.apply(this, arguments);
        return (0, n.default)(this, r);
    };
}

var u = require("../../../workflow_common/core/action/ActionConditionBase.js");

module.exports = function(e) {
    (0, r.default)(o, e);
    var n = i(o);
    function o(e) {
        (0, t.default)(this, o);
        var r = require("../../WorkflowDP.js");
        return n.call(this, r.getSingleton().createGearImpl(e.condition), r.getSingleton().createGearImpl(e.conditionTrueAction), r.getSingleton().createGearImpl(e.conditionFalseAction));
    }
    return o;
}(u);