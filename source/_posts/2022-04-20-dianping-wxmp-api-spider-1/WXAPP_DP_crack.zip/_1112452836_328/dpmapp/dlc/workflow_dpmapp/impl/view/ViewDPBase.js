var i = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), e = i(require("../../../../../@babel/runtime/helpers/classCallCheck")), n = i(require("../../../../../@babel/runtime/helpers/createClass")), t = function() {
    function i(n, t) {
        (0, e.default)(this, i), this._app = t, this._visibleConditionImp = null, this.gearViewInfo = n;
        var r = n.commonConfig;
        if (i.checkPrecondition(r, this._app.runtimeInfo)) if (r.visibleCondition) if ("ConditionAlways" === r.visibleCondition.className) this.visibleConditionImp = null; else {
            if ("ConditionNever" === r.visibleCondition.className) return;
            var o = require("../../../workflow_common/Workflow.js");
            this.visibleConditionImp = o.getSingleton().createGearImpl(r.visibleCondition);
        } else this.visibleConditionImp = null;
    }
    return (0, n.default)(i, [ {
        key: "visibleConditionImp",
        set: function(i) {
            var e = this;
            if (this._visibleConditionImp = i, i) {
                var n = i.getConditionResult();
                n.isComplete && n.bool && (this.__alreadyAdd = !0, this._app.env.notify("__ON_GEAR_VIEW_ADD__", {
                    gear: this.gearViewInfo
                })), i && i.addCallBack(function(n) {
                    var t = i.getConditionResult();
                    t.isComplete && (t.bool ? e.__alreadyAdd || (e.__alreadyAdd = !0, e._app.env.notify("__ON_GEAR_VIEW_ADD__", {
                        gear: e.gearViewInfo
                    })) : e.__alreadyAdd && (e.__alreadyAdd = !1, e._app.env.notify("__ON_GEAR_VIEW_REMOVE__", {
                        gear: e.gearViewInfo
                    })));
                }, this);
            } else this.__alreadyAdd || (this.__alreadyAdd = !0, this._app.env.notify("__ON_GEAR_VIEW_ADD__", {
                gear: this.gearViewInfo
            }));
        }
    }, {
        key: "checkPrecondition",
        value: function(i) {
            if (i) {
                var e = !0, n = i.rtc;
                if (0 !== n && !(e = 1 & n)) return !1;
                var t = i.device;
                if (0 !== t) {
                    var r = this._app.runtimeInfo.deviceSystem;
                    if ("IOS" === r ? e = 2 & t : "ANDROID" === r ? e = 1 & t : "HARMONY" === r && (e = 4 & t), 
                    !e) return !1;
                }
            }
            return !0;
        }
    }, {
        key: "dispose",
        value: function() {
            this._visibleConditionImp && (this._visibleConditionImp.dispose(), this._visibleConditionImp = null), 
            this.__alreadyAdd && (this.__alreadyAdd = !1, this._app.env.notify("__ON_GEAR_VIEW_REMOVE__", {
                gear: this.gearViewInfo
            })), this._app = null, this.gearViewInfo = null;
        }
    } ]), i;
}();

t.checkPrecondition = function(i, e) {
    if (!i) return !1;
    e || (e = new (require("../../../../../framework/class_define/runtime_info.js"))());
    if (i) {
        var n = !0, t = i.rtc;
        if (0 !== t && !(n = 1 & t)) return !1;
        var r = i.device;
        if (0 !== r) {
            var o = e.deviceSystem;
            if ("IOS" === o ? n = 2 & r : "ANDROID" === o ? n = 1 & r : "HARMONY" === o && (n = 4 & r), 
            !n) return !1;
        }
    }
    return !0;
}, module.exports = t;