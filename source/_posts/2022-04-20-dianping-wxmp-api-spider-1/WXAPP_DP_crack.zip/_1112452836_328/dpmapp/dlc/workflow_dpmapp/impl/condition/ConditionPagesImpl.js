var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../../@babel/runtime/helpers/createClass")), i = e(require("../../../../../@babel/runtime/helpers/assertThisInitialized")), n = e(require("../../../../../@babel/runtime/helpers/get")), s = e(require("../../../../../@babel/runtime/helpers/inherits")), o = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), u = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function l(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, i = (0, u.default)(e);
        if (t) {
            var n = (0, u.default)(this).constructor;
            r = Reflect.construct(i, arguments, n);
        } else r = i.apply(this, arguments);
        return (0, o.default)(this, r);
    };
}

var a = require("../../../workflow_common/core/condition/ConditionBase.js"), c = require("../../../workflow_common/core/condition/ConditionResult.js");

module.exports = function(e) {
    (0, s.default)(a, e);
    var o = l(a);
    function a(e, r) {
        var n;
        (0, t.default)(this, a), n = o.call(this);
        var s = e.pageList || "";
        return 33 === s.charCodeAt(0) ? (s = s.substr(0), n.inPages = 0) : n.inPages = 1, 
        n.pageList = s.split(",").map(function(e) {
            return e.trim();
        }), n._app = r, n._app.env.register(20017, n._pageShow, (0, i.default)(n)), n;
    }
    return (0, r.default)(a, [ {
        key: "_pageShow",
        value: function(e, t, r, i) {
            i.serverTime = t.serverTime;
            var n = i.recentConditionResult;
            i.getConditionResult(), i.recentConditionResult.isComplete && (n && n.isComplete && n.bool === i.recentConditionResult.bool || i.onConditionChange()), 
            n = null;
        }
    }, {
        key: "getConditionResult",
        value: function() {
            var e = getCurrentPages();
            if (e && e.length) {
                var t = e[e.length - 1], r = t.pageName, i = -1 !== this.pageList.indexOf(r);
                i || "mvvm" !== r || (i = -1 !== this.pageList.indexOf(t.pageMVVMName)), this.recentConditionResult = new c(this.inPages ? i : !i, !0);
            } else this.recentConditionResult = new c(!1, !1);
            return this.recentConditionResult;
        }
    }, {
        key: "dispose",
        value: function() {
            this.reference--, this.reference || (this._app && (this._app.env.unregister(20017, this._pageShow, this), 
            this._app = null), this.pageList = null, this.recentConditionResult = null, this.serverTime = null, 
            (0, n.default)((0, u.default)(a.prototype), "dispose", this).call(this));
        }
    } ]), a;
}(a);