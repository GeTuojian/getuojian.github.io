var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), n = e(require("../../../../../@babel/runtime/helpers/createClass")), r = e(require("../../../../../@babel/runtime/helpers/inherits")), o = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), i = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function u(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var n, r = (0, i.default)(e);
        if (t) {
            var u = (0, i.default)(this).constructor;
            n = Reflect.construct(r, arguments, u);
        } else n = r.apply(this, arguments);
        return (0, o.default)(this, n);
    };
}

var l = require("../../../workflow_common/core/condition/ConditionBase.js"), s = require("../../../workflow_common/core/condition/ConditionResult.js");

module.exports = function(e) {
    (0, r.default)(l, e);
    var i = u(l);
    function l(e, n) {
        var r;
        return (0, t.default)(this, l), (r = i.call(this)).m_conditionCustomerTypeVO = e, 
        r.recentConditionResult = new s(!0, !0), (0, o.default)(r);
    }
    return (0, n.default)(l, [ {
        key: "_onNetwork",
        value: function(e) {
            var t = this.recentConditionResult;
            this.recentConditionResult = new s(!!(this.HOLDER._myCustomerType & this.m_conditionCustomerTypeVO.customerType), !0), 
            this.recentConditionResult.isComplete && (t && t.isComplete && t.bool === this.recentConditionResult.bool || this.onConditionChange());
        }
    }, {
        key: "getConditionResult",
        value: function() {
            return this.recentConditionResult;
        }
    }, {
        key: "dispose",
        value: function() {
            this.m_conditionCustomerTypeVO = null, this.HOLDER = null;
        }
    } ]), l;
}(l);