var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), i = e(require("../../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../../@babel/runtime/helpers/get")), o = e(require("../../../../../@babel/runtime/helpers/inherits")), r = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function s(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var i, n = (0, l.default)(e);
        if (t) {
            var o = (0, l.default)(this).constructor;
            i = Reflect.construct(n, arguments, o);
        } else i = n.apply(this, arguments);
        return (0, r.default)(this, i);
    };
}

var u = require("../../../workflow_common/core/action/ActionBase.js"), c = require("../../../workflow_common/core/action/ActionResult.js");

module.exports = function(e) {
    (0, o.default)(u, e);
    var r = s(u);
    function u(e) {
        var i;
        return (0, t.default)(this, u), (i = r.call(this)).m_actionShowHideDLCElementVO = e, 
        i;
    }
    return (0, i.default)(u, [ {
        key: "doAction",
        value: function(e) {
            if (!e) {
                var t = getCurrentPages();
                e = t[t.length - 1];
            }
            if (this.m_actionShowHideDLCElementVO.isOpen) {
                if (!e.data.MVVMLayerSupport) return this.completeFunction && this.completeFunction(new c(this, !0)), 
                void this.dispose();
                var i = this.m_actionShowHideDLCElementVO.elementGlobalId;
                if (!i) return this.completeFunction && this.completeFunction(new c(this, !0)), 
                void this.dispose();
                var n = require("../../../workflow_common/Workflow.js").getSingleton().findResidentImpl(function(e) {
                    return e && e.globalId === i;
                });
                if (n && (n = n.func ? n.func() : n.instance), !n) return this.completeFunction && this.completeFunction(new c(this, !0)), 
                void this.dispose();
                var o = n.createPageMVVM();
                return o.maskType = this.m_actionShowHideDLCElementVO.mask, o.animeType = this.m_actionShowHideDLCElementVO.animeType, 
                e.$addMVVMElement(o), this.completeFunction && this.completeFunction(new c(this, !0)), 
                this.dispose(), o;
            }
            return e.$removeMVVMElement && e.$removeMVVMElement(void 0, void 0, this.m_actionShowHideDLCElementVO.elementGlobalId), 
            this.completeFunction && this.completeFunction(new c(this, !0)), void this.dispose();
        }
    }, {
        key: "dispose",
        value: function() {
            (0, n.default)((0, l.default)(u.prototype), "dispose", this).call(this), this.m_actionShowHideDLCElementVO = null;
        }
    } ]), u;
}(u);