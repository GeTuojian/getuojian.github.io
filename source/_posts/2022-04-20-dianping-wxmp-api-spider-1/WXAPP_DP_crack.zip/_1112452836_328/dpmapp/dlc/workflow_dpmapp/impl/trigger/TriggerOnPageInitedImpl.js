var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../../@babel/runtime/helpers/createClass")), i = e(require("../../../../../@babel/runtime/helpers/assertThisInitialized")), n = e(require("../../../../../@babel/runtime/helpers/get")), a = e(require("../../../../../@babel/runtime/helpers/inherits")), l = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), u = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function s(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, i = (0, u.default)(e);
        if (t) {
            var n = (0, u.default)(this).constructor;
            r = Reflect.construct(i, arguments, n);
        } else r = i.apply(this, arguments);
        return (0, l.default)(this, r);
    };
}

var o = require("../../../workflow_common/core/trigger/TriggerBase.js"), g = require("../../../workflow_common/Workflow.js");

module.exports = function(e) {
    (0, a.default)(o, e);
    var l = s(o);
    function o(e, r) {
        var n;
        return (0, t.default)(this, o), (n = l.call(this)).m_triggerOnPageInitedVO = e, 
        n._triggeredPages = [], n._app || (n._app = r, n._app.env.register(20015, n.__onPageLoaded, (0, 
        i.default)(n))), n;
    }
    return (0, r.default)(o, [ {
        key: "__onPageLoaded",
        value: function(e, t, r, i) {
            i.trigger.call(i, [ t.page ]);
        }
    }, {
        key: "activate",
        value: function() {
            (0, n.default)((0, u.default)(o.prototype), "activate", this).call(this), this.trigger();
        }
    }, {
        key: "trigger",
        value: function() {
            var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
            if (this.isActive && this.m_triggerOnPageInitedVO.triggerAction) {
                t || (t = getCurrentPages());
                for (var r = t.length - 1; r >= 0; r--) {
                    var i = t[r];
                    if (-1 === this._triggeredPages.indexOf(i) && (i.pageName === this.m_triggerOnPageInitedVO.pageName || "mvvm" === i.pageName && i.pageMVVMName === this.m_triggerOnPageInitedVO.pageName)) {
                        this._triggeredPages.push(i);
                        var n = g.getSingleton().createGearImpl(this.m_triggerOnPageInitedVO.triggerAction);
                        n && (n.completeFunction = function(t) {
                            e.completeFunction && e.completeFunction(new ActionResult(e, t.isComplete));
                        }, n.doAction(i));
                    }
                    if (!this.m_triggerOnPageInitedVO.triggerStackPages) break;
                }
            }
        }
    }, {
        key: "dispose",
        value: function() {
            this._app && (this._app.env.unregister(20015, this.__onPageLoaded, this), this._app = null), 
            this.m_triggerOnPageInitedVO = null, this._triggeredPages = null, (0, n.default)((0, 
            u.default)(o.prototype), "dispose", this).call(this);
        }
    } ]), o;
}(o);