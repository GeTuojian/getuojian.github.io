var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../../@babel/runtime/helpers/get")), o = e(require("../../../../../@babel/runtime/helpers/inherits")), i = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function u(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, n = (0, l.default)(e);
        if (t) {
            var o = (0, l.default)(this).constructor;
            r = Reflect.construct(n, arguments, o);
        } else r = n.apply(this, arguments);
        return (0, i.default)(this, r);
    };
}

var c = require("../../../workflow_common/core/action/ActionBase.js"), a = require("../../../workflow_common/core/action/ActionResult.js");

module.exports = function(e) {
    (0, o.default)(c, e);
    var i = u(c);
    function c(e) {
        var r;
        return (0, t.default)(this, c), (r = i.call(this)).m_actionDelayVO = e, r;
    }
    return (0, r.default)(c, [ {
        key: "doAction",
        value: function() {
            var e = this, t = setTimeout(function() {
                var r;
                (clearTimeout(t), e.m_actionDelayVO.delayAction) && (r = require("../../WorkflowDP.js").getSingleton().createGearImpl(e.m_actionDelayVO.delayAction));
                r ? (r.completeFunction = function(t) {
                    e.completeFunction && e.completeFunction(new a(e, t.isComplete)), e.dispose();
                }, r.doAction()) : (e.completeFunction && e.completeFunction(new a(e, !0)), e.dispose());
            }, this.m_actionDelayVO.delayTime);
        }
    }, {
        key: "dispose",
        value: function() {
            (0, n.default)((0, l.default)(c.prototype), "dispose", this).call(this), this.m_actionDelayVO = null;
        }
    } ]), c;
}(c);