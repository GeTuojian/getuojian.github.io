var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../../@babel/runtime/helpers/createClass")), i = e(require("../../../../../@babel/runtime/helpers/get")), n = e(require("../../../../../@babel/runtime/helpers/inherits")), o = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), a = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function c(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, i = (0, a.default)(e);
        if (t) {
            var n = (0, a.default)(this).constructor;
            r = Reflect.construct(i, arguments, n);
        } else r = i.apply(this, arguments);
        return (0, o.default)(this, r);
    };
}

var l = require("../../../workflow_common/core/action/ActionBase.js"), u = require("../../../workflow_common/core/action/ActionResult.js");

module.exports = function(e) {
    (0, n.default)(l, e);
    var o = c(l);
    function l(e) {
        var r;
        return (0, t.default)(this, l), (r = o.call(this)).m_actionMultiVO = e, r;
    }
    return (0, r.default)(l, [ {
        key: "dispose",
        value: function() {
            this.actionImplArray = null, this.m_actionMultiVO = null, (0, i.default)((0, a.default)(l.prototype), "dispose", this).call(this);
        }
    }, {
        key: "doAction",
        value: function(e, t) {
            var r = require("../../WorkflowDP.js");
            this.actionImplArray = [];
            var i = this.m_actionMultiVO;
            i.action1 && this.actionImplArray.push(r.getSingleton().createGearImpl(i.action1)), 
            i.action2 && this.actionImplArray.push(r.getSingleton().createGearImpl(i.action2)), 
            i.action3 && this.actionImplArray.push(r.getSingleton().createGearImpl(i.action3)), 
            i.action4 && this.actionImplArray.push(r.getSingleton().createGearImpl(i.action4));
            var n = this;
            if (!n.actionImplArray.length) return n.completeFunction && n.completeFunction(new u(n, !0)), 
            void n.dispose();
            var o = this.actionImplArray.shift();
            o.completeFunction = function r(i) {
                if (i.actionBase.dispose(), i.dispose(), !n.actionImplArray || !n.actionImplArray.length) return n.completeFunction && n.completeFunction(new u(n, !0)), 
                void n.dispose();
                var o = n.actionImplArray.shift();
                o.completeFunction = r, o.doAction(e, t);
            }, o.doAction(e, t);
        }
    } ]), l;
}(l);