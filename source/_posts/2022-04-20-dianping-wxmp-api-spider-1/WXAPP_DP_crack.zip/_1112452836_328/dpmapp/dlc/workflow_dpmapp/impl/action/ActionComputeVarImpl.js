var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../../@babel/runtime/helpers/createClass")), a = e(require("../../../../../@babel/runtime/helpers/get")), u = e(require("../../../../../@babel/runtime/helpers/inherits")), l = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), o = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function n(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, a = (0, o.default)(e);
        if (t) {
            var u = (0, o.default)(this).constructor;
            r = Reflect.construct(a, arguments, u);
        } else r = a.apply(this, arguments);
        return (0, l.default)(this, r);
    };
}

var i = require("../../../workflow_common/core/action/ActionBase.js"), c = require("../../../workflow_common/core/action/ActionResult.js");

module.exports = function(e) {
    (0, u.default)(i, e);
    var l = n(i);
    function i(e) {
        var r;
        return (0, t.default)(this, i), (r = l.call(this)).m_actionComputeVar = e, r;
    }
    return (0, r.default)(i, [ {
        key: "doAction",
        value: function() {
            var e = this, t = require("../../WorkflowDP.js").getSingleton().createGearImpl(this.m_actionComputeVar.variableId);
            function r(e, t) {
                var r = e.m_actionComputeVar.value;
                switch (e.m_actionComputeVar.operater) {
                  case 0:
                    t.value += r;
                    break;

                  case 1:
                    t.value -= r;
                    break;

                  case 2:
                    t.value *= r;
                    break;

                  case 3:
                    t.value /= r;
                    break;

                  case 4:
                    t.value %= r;
                    break;

                  case 5:
                    t.value = Math.pow(t.value, r);
                    break;

                  case 6:
                    t.value |= r;
                    break;

                  case 7:
                    t.value &= r;
                    break;

                  case 8:
                    t.value ^= r;
                    break;

                  case 63:
                    t.value = r;
                }
                e.completeFunction && e.completeFunction(new c(e, !0)), e.dispose(), e = null;
            }
            t.everSetValue ? r(this, t) : t.addCallBack(function(a) {
                r(e, t);
            });
        }
    }, {
        key: "dispose",
        value: function() {
            (0, a.default)((0, o.default)(i.prototype), "dispose", this).call(this), this.m_actionComputeVar = null;
        }
    } ]), i;
}(i);