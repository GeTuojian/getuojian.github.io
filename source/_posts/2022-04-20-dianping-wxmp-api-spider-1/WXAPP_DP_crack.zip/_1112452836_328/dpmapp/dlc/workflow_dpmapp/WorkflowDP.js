var i = require("../workflow_common/Workflow.js");

i.prototype.init = function() {
    var i = {
        ActionAlert: require("./impl/action/ActionAlertImpl.js"),
        ActionAntiTiredAction: require("./impl/action/ActionAntiTiredActionImpl.js"),
        ActionToast: require("./impl/action/ActionToastImpl.js"),
        ActionCondition: require("./impl/action/ActionConditionImpl.js"),
        ActionDelayAction: require("./impl/action/ActionDelayActionImpl.js"),
        ActionComputeVar: require("./impl/action/ActionComputeVarImpl.js"),
        ActionNavigate: require("./impl/action/ActionNavigateImpl.js"),
        ActionMultiSeq: require("./impl/action/ActionMultiSeqImpl.js"),
        ActionMultiBatch: require("./impl/action/ActionMultiBatchImpl.js"),
        ActionMultiSwitch: require("./impl/action/ActionMultiSwitchImpl.js"),
        ActionSendRequest: require("./impl/action/ActionSendRequestImpl.js"),
        ActionShowHideDLCElement: require("./impl/action/ActionShowHideDLCElementImpl.js"),
        ActionDoCasterFunction: require("./impl/action/ActionDoCasterFunctionImpl.js"),
        ActionSwitchPlatform: require("./impl/action/ActionSwitchPlatformImpl.js"),
        ConditionVariableNever: require("../workflow_common/core/condition/ConditionNever.js"),
        ConditionVariable: require("./impl/condition/ConditionVariableImpl.js"),
        ConditionTimeZone: require("./impl/condition/ConditionTimeZoneImpl.js"),
        ConditionMultiTimeZone8: require("./impl/condition/ConditionMultiTimeZone8Impl.js"),
        ConditionCitys: require("./impl/condition/ConditionCitysImpl.js"),
        ConditionCustomerType: require("./impl/condition/ConditionCustomerTypeImpl.js"),
        ConditionHaimaUserLayer: require("./impl/condition/ConditionHaimaUserLayerImpl.js"),
        ConditionPages: require("./impl/condition/ConditionPagesImpl.js"),
        ConditionOr: require("./impl/condition/ConditionOrImpl.js"),
        ConditionAnd: require("./impl/condition/ConditionAndImpl.js"),
        ConditionAnd4: require("./impl/condition/ConditionAnd4Impl.js"),
        ConditionXor: require("./impl/condition/ConditionXorImpl.js"),
        VariableLocal: require("../workflow_common/core/variable/VariableLocal.js"),
        ViewMainKK: require("./impl/view/ViewDPBase.js"),
        ViewMainMidThrough: require("./impl/view/ViewDPBase.js"),
        ViewProfileIcon: require("./impl/view/ViewDPBase.js"),
        ViewSideIcon: require("./impl/view/ViewDPBase.js"),
        TriggerOnScriptIninted: require("./impl/trigger/TriggerOnScriptInintedImpl.js"),
        TriggerOnPageInited: require("./impl/trigger/TriggerOnPageInitedImpl.js"),
        TriggerOnFrameworkEvent: require("./impl/trigger/TriggerOnFrameworkEventImpl.js"),
        TriggerOnVariableChanged: require("./impl/trigger/TriggerOnVariableChangedImpl.js"),
        TriggerOnConditionChanged: require("./impl/trigger/TriggerOnConditionChangedImpl.js")
    };
    Object.assign(this._gearImplMap, i);
    var n = this._gearEnv, e = new (require("./impl/variable/VariableGlobalImpl_loginStatus.js"))(this._app), o = new (require("./impl/variable/VariableGlobalImpl_enableDebug.js"))(this._app), t = new (require("../workflow_common/core/condition/ConditionAlways.js"))(), r = new (require("../workflow_common/core/condition/ConditionNever.js"))(), l = this.createGearImpl(n.env_instancePool[5100], !0), a = this.createGearImpl(n.env_instancePool[5101], !0);
    Object.assign(this._residentImplIns, {
        3000: {
            func: function() {
                return null;
            },
            instance: null
        },
        4100: {
            func: e.getInstance.bind(e),
            instance: e
        },
        4101: {
            func: o.getInstance.bind(o),
            instance: o
        },
        5001: {
            func: t.getInstance.bind(t),
            instance: t
        },
        5002: {
            func: r.getInstance.bind(r),
            instance: r
        },
        5100: {
            func: l.getInstance.bind(l),
            instance: l
        },
        5101: {
            func: a.getInstance.bind(a),
            instance: a
        }
    });
}, module.exports = i;