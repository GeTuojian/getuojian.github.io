var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), r = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), t = e(require("../../../../../@babel/runtime/helpers/createClass")), i = e(require("../../../../../@babel/runtime/helpers/get")), n = e(require("../../../../../@babel/runtime/helpers/inherits")), u = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function o(e) {
    var r = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var t, i = (0, l.default)(e);
        if (r) {
            var n = (0, l.default)(this).constructor;
            t = Reflect.construct(i, arguments, n);
        } else t = i.apply(this, arguments);
        return (0, u.default)(this, t);
    };
}

var a = require("../../../workflow_common/core/trigger/TriggerBase.js");

module.exports = function(e) {
    (0, n.default)(a, e);
    var u = o(a);
    function a(e, t) {
        var i;
        return (0, r.default)(this, a), (i = u.call(this)).gearTriggerOnScriptIninted = e, 
        i;
    }
    return (0, t.default)(a, [ {
        key: "activate",
        value: function() {
            (0, i.default)((0, l.default)(a.prototype), "activate", this).call(this), this.trigger(), 
            this.dispose();
        }
    }, {
        key: "trigger",
        value: function() {
            if (this.gearTriggerOnScriptIninted && this.gearTriggerOnScriptIninted.triggerAction) {
                var e = require("../../../workflow_common/Workflow.js").getSingleton().createGearImpl(this.gearTriggerOnScriptIninted.triggerAction);
                e && e.doAction();
            }
        }
    }, {
        key: "dispose",
        value: function() {
            (0, i.default)((0, l.default)(a.prototype), "dispose", this).call(this), this.gearTriggerOnScriptIninted = null;
        }
    } ]), a;
}(a);