var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), i = e(require("../../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../../@babel/runtime/helpers/assertThisInitialized")), r = e(require("../../../../../@babel/runtime/helpers/get")), o = e(require("../../../../../@babel/runtime/helpers/inherits")), s = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function u(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var i, n = (0, l.default)(e);
        if (t) {
            var r = (0, l.default)(this).constructor;
            i = Reflect.construct(n, arguments, r);
        } else i = n.apply(this, arguments);
        return (0, s.default)(this, i);
    };
}

var a = require("../../../workflow_common/core/condition/ConditionBase.js"), c = require("../../../workflow_common/core/condition/ConditionResult.js");

module.exports = function(e) {
    (0, o.default)(a, e);
    var s = u(a);
    function a(e, i) {
        var r;
        return (0, t.default)(this, a), (r = s.call(this)).m_conditionTimeZoneVO = e, Object.defineProperty((0, 
        n.default)(r), "_app", {
            value: i,
            enumerable: !1,
            writable: !0
        }), r._app.env.register(21007, r._timeChange, (0, n.default)(r)), r;
    }
    return (0, i.default)(a, [ {
        key: "_timeChange",
        value: function(e, t, i, n) {
            n.serverTime = t.serverTime;
            var r = n.recentConditionResult;
            n.getConditionResult(), n.recentConditionResult.isComplete && (r && r.isComplete && r.bool === n.recentConditionResult.bool || n.onConditionChange()), 
            r = null;
        }
    }, {
        key: "getConditionResult",
        value: function() {
            if (void 0 === this.serverTime) this.recentConditionResult = new c(!1, !1); else {
                var e = 1e3 * this.m_conditionTimeZoneVO.t0 < this.serverTime && 1e3 * this.m_conditionTimeZoneVO.t1 > this.serverTime;
                e = this.m_conditionTimeZoneVO.reverseReturn ? !e : e, this.recentConditionResult = new c(e, !0);
            }
            return this.recentConditionResult;
        }
    }, {
        key: "dispose",
        value: function() {
            this.reference--, this.reference || (this._app && (this._app.env.unregister(21007, this._timeChange, this), 
            this._app = null), this.m_conditionTimeZoneVO = null, this.recentConditionResult = null, 
            this.serverTime = null, (0, r.default)((0, l.default)(a.prototype), "dispose", this).call(this));
        }
    } ]), a;
}(a);