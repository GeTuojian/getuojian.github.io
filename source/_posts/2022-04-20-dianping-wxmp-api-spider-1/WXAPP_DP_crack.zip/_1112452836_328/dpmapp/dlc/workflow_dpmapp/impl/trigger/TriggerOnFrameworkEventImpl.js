var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), r = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), t = e(require("../../../../../@babel/runtime/helpers/createClass")), i = e(require("../../../../../@babel/runtime/helpers/assertThisInitialized")), n = e(require("../../../../../@babel/runtime/helpers/get")), o = e(require("../../../../../@babel/runtime/helpers/inherits")), u = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function a(e) {
    var r = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var t, i = (0, l.default)(e);
        if (r) {
            var n = (0, l.default)(this).constructor;
            t = Reflect.construct(i, arguments, n);
        } else t = i.apply(this, arguments);
        return (0, u.default)(this, t);
    };
}

var s = require("../../../workflow_common/core/trigger/TriggerBase.js"), c = require("../../../workflow_common/Workflow.js");

module.exports = function(e) {
    (0, o.default)(s, e);
    var u = a(s);
    function s(e, t) {
        var n;
        return (0, r.default)(this, s), (n = u.call(this)).m_triggerOnFrameworkEventVO = e, 
        n._triggeredPages = [], n._app || (n._app = t, n._app.env.register(e.eventId, n.__onTrigger, (0, 
        i.default)(n))), n;
    }
    return (0, t.default)(s, [ {
        key: "__onTrigger",
        value: function(e, r, t, i) {
            i.trigger.call(i, r);
        }
    }, {
        key: "trigger",
        value: function(e) {
            var r = this;
            if (this.isActive && this.m_triggerOnFrameworkEventVO.triggerAction) {
                var t = c.getSingleton().createGearImpl(this.m_triggerOnFrameworkEventVO.triggerAction);
                t && (t.completeFunction = function(e) {
                    r.completeFunction && r.completeFunction(new ActionResult(r, e.isComplete));
                }, t.doAction(null, e));
            }
        }
    }, {
        key: "dispose",
        value: function() {
            this.m_triggerOnFrameworkEventVO && (this._app && (this._app.env.unregister(this.m_triggerOnFrameworkEventVO.eventId, this.__onTrigger, this), 
            this._app = null), this.m_triggerOnFrameworkEventVO = null), (0, n.default)((0, 
            l.default)(s.prototype), "dispose", this).call(this);
        }
    } ]), s;
}(s);