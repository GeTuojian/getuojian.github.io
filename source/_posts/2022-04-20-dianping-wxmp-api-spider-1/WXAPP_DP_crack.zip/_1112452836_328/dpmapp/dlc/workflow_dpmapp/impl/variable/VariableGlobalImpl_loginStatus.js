var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../../@babel/runtime/helpers/createClass")), a = e(require("../../../../../@babel/runtime/helpers/assertThisInitialized")), u = e(require("../../../../../@babel/runtime/helpers/get")), n = e(require("../../../../../@babel/runtime/helpers/inherits")), l = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), s = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function i(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, a = (0, s.default)(e);
        if (t) {
            var u = (0, s.default)(this).constructor;
            r = Reflect.construct(a, arguments, u);
        } else r = a.apply(this, arguments);
        return (0, l.default)(this, r);
    };
}

var o = require("../../../workflow_common/core/variable/VariableBase.js");

module.exports = function(e) {
    (0, n.default)(o, e);
    var l = i(o);
    function o(e) {
        var r;
        return (0, t.default)(this, o), (r = l.call(this))._app = e, r.value = e.userData.dpAccessToken ? 1 : 0, 
        r.globalId = "__G_LOGIN_STATUS__", e.env.register(43002, r._swapDataChanged, (0, 
        a.default)(r)), r;
    }
    return (0, r.default)(o, [ {
        key: "_swapDataChanged",
        value: function(e, t, r, a) {
            t.swapData === a._app.userData && "dpAccessToken" === t.field && (a.value = t.newData ? 1 : 0);
        }
    }, {
        key: "dispose",
        value: function() {
            this.reference--, this.reference || (this._swapDataChanged && (getApp().env.unregister(43002, this._swapDataChanged, this), 
            this._swapDataChanged = null), this._app = null, (0, u.default)((0, s.default)(o.prototype), "dispose", this).call(this));
        }
    } ]), o;
}(o);