var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../../@babel/runtime/helpers/inherits")), u = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), o = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function i(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, n = (0, o.default)(e);
        if (t) {
            var i = (0, o.default)(this).constructor;
            r = Reflect.construct(n, arguments, i);
        } else r = n.apply(this, arguments);
        return (0, u.default)(this, r);
    };
}

var l = require("../../../workflow_common/core/condition/ConditionBase.js"), c = require("../../../workflow_common/core/condition/ConditionResult.js");

module.exports = function(e) {
    (0, n.default)(l, e);
    var o = i(l);
    function l(e, r) {
        var n;
        return (0, t.default)(this, l), (n = o.call(this)).recentConditionResult = new c(!0, !0), 
        (0, u.default)(n);
    }
    return (0, r.default)(l, [ {
        key: "getConditionResult",
        value: function() {
            return this.recentConditionResult;
        }
    } ]), l;
}(l);