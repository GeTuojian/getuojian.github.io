var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../../@babel/runtime/helpers/createClass")), a = e(require("../../../../../@babel/runtime/helpers/get")), i = e(require("../../../../../@babel/runtime/helpers/inherits")), n = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), o = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function u(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, a = (0, o.default)(e);
        if (t) {
            var i = (0, o.default)(this).constructor;
            r = Reflect.construct(a, arguments, i);
        } else r = a.apply(this, arguments);
        return (0, n.default)(this, r);
    };
}

var c = require("../../../workflow_common/core/action/ActionBase.js"), l = require("../../../workflow_common/core/action/ActionResult.js");

module.exports = function(e) {
    (0, i.default)(c, e);
    var n = u(c);
    function c(e) {
        var r;
        return (0, t.default)(this, c), (r = n.call(this)).m_actionNavigateVO = e, r;
    }
    return (0, r.default)(c, [ {
        key: "doAction",
        value: function() {
            var e = this.m_actionNavigateVO.pageName;
            switch (47 !== e.charCodeAt(0) && (e = "stlk://" + e), this.m_actionNavigateVO.navType) {
              case 0:
              case 1:
                getApp().navigation.forwardTo({
                    url: e,
                    target: "_blank"
                });
                break;

              case 2:
                getApp().navigation.redirectTo({
                    url: e
                });
                break;

              case 3:
                getApp().navigation.back();
                break;

              case 4:
                getCurrentPages().length > 1 ? getApp().navigation.back() : getApp().navigation.redirectTo({
                    url: "stlk://home"
                });
                break;

              case 5:
                getApp().navigation.redirectTo({
                    url: "/" + this.route
                });
            }
            this.completeFunction && this.completeFunction(new l(this, !0));
        }
    }, {
        key: "dispose",
        value: function() {
            (0, a.default)((0, o.default)(c.prototype), "dispose", this).call(this), this.m_actionNavigateVO = null;
        }
    } ]), c;
}(c);