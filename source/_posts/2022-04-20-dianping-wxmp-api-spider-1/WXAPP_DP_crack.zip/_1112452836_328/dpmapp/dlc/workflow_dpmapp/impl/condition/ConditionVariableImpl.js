var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/typeof")), i = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../../@babel/runtime/helpers/get")), a = e(require("../../../../../@babel/runtime/helpers/inherits")), o = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function s(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var i, r = (0, l.default)(e);
        if (t) {
            var n = (0, l.default)(this).constructor;
            i = Reflect.construct(r, arguments, n);
        } else i = r.apply(this, arguments);
        return (0, o.default)(this, i);
    };
}

var u = require("../../../workflow_common/core/condition/ConditionBase.js"), c = require("../../../workflow_common/core/condition/ConditionResult.js");

module.exports = function(e) {
    (0, a.default)(u, e);
    var o = s(u);
    function u(e) {
        var t;
        return (0, i.default)(this, u), (t = o.call(this)).m_conditionVariableVO = e, t.recentConditionResult = null, 
        t;
    }
    return (0, r.default)(u, [ {
        key: "addCallBack",
        value: function(e, t) {
            (0, n.default)((0, l.default)(u.prototype), "addCallBack", this).call(this, e, t), 
            this.getConditionResult();
        }
    }, {
        key: "dispose",
        value: function() {
            this.reference--, this.reference || (this.m_varImpl && (this._onVarChanged && (this.m_varImpl.removeCallBack(this._onVarChanged), 
            this._onVarChanged = null), this.m_varImpl.dispose(), this.m_varImpl = null), this.m_conditionVariableVO = null, 
            (0, n.default)((0, l.default)(u.prototype), "dispose", this).call(this));
        }
    }, {
        key: "__onVarChanged",
        value: function(e) {
            if (this.recentConditionResult.isComplete) {
                this.recentConditionResult.bool !== this.getConditionResult().bool && this.onConditionChange();
            } else {
                this.getConditionResult();
                this.onConditionChange();
            }
        }
    }, {
        key: "getConditionResult",
        value: function() {
            if (!this.m_varImpl) {
                var e = require("../../WorkflowDP.js");
                this.m_varImpl = e.getSingleton().createGearImpl(this.m_conditionVariableVO.variableId);
            }
            var i, r = this.m_varImpl;
            if (r.everSetValue) {
                var n = this.m_conditionVariableVO.field, a = this.m_conditionVariableVO.comparator, o = this.m_conditionVariableVO.value, l = r.value;
                n && "this" !== n && (l = "object" === (0, t.default)(l) ? l[n] : void 0), i = function(e, t, i) {
                    var r;
                    switch (t) {
                      case 0:
                        r = e < i;
                        break;

                      case 1:
                        r = e <= i;
                        break;

                      case 2:
                        r = e == i;
                        break;

                      case 3:
                        r = e >= i;
                        break;

                      case 4:
                        r = e > i;
                        break;

                      case 5:
                        r = e != i;
                        break;

                      case 6:
                        r = !0;
                        break;

                      case 7:
                        r = !1;
                    }
                    return r;
                }(l, a, o);
            } else i = void 0;
            return !this._onVarChanged && this.m_callBackArray && this.m_callBackArray.length && (this._onVarChanged = this.__onVarChanged.bind(this), 
            r.addCallBack(this._onVarChanged)), this.recentConditionResult = new c(i, r.everSetValue), 
            this.recentConditionResult;
        }
    } ]), u;
}(u);