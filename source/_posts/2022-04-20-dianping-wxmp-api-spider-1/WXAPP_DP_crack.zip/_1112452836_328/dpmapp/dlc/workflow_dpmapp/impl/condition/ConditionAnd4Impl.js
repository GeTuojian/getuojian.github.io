var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), n = e(require("../../../../../@babel/runtime/helpers/inherits")), r = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), o = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function i(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var n, i = (0, o.default)(e);
        if (t) {
            var u = (0, o.default)(this).constructor;
            n = Reflect.construct(i, arguments, u);
        } else n = i.apply(this, arguments);
        return (0, r.default)(this, n);
    };
}

var u = require("../../../workflow_common/core/condition/ConditionTwoCondition.js"), c = (require("../../../workflow_common/core/condition/ConditionResult.js"), 
require("./ConditionAndImpl.js"));

module.exports = function(e) {
    (0, n.default)(o, e);
    var r = i(o);
    function o(e) {
        return (0, t.default)(this, o), r.call(this, function() {
            return new c({
                condition0: e.condition0,
                condition1: e.condition1
            });
        }, function() {
            return new c({
                condition0: e.condition2,
                condition1: e.condition3
            });
        }, 2);
    }
    return o;
}(u);