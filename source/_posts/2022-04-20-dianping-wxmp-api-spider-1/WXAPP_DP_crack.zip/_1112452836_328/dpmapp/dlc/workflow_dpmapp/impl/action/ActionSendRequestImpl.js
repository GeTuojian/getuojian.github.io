var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), n = e(require("../../../../../@babel/runtime/helpers/createClass")), o = e(require("../../../../../@babel/runtime/helpers/get")), r = e(require("../../../../../@babel/runtime/helpers/inherits")), i = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), c = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function u(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var n, o = (0, c.default)(e);
        if (t) {
            var r = (0, c.default)(this).constructor;
            n = Reflect.construct(o, arguments, r);
        } else n = o.apply(this, arguments);
        return (0, i.default)(this, n);
    };
}

var a = require("../../../workflow_common/core/action/ActionBase.js"), l = require("../../../workflow_common/core/action/ActionResult.js");

module.exports = function(e) {
    (0, r.default)(a, e);
    var i = u(a);
    function a(e) {
        var n;
        return (0, t.default)(this, a), (n = i.call(this)).m_actionSendRequestVO = e, n;
    }
    return (0, n.default)(a, [ {
        key: "doAction",
        value: function() {
            !function(e, t) {
                var n;
                try {
                    n = JSON.parse(e.m_actionSendRequestVO.body);
                } catch (t) {
                    n = e.m_actionSendRequestVO.body;
                }
                getApp().sc.request({
                    protocol: {
                        path: "".concat(e.m_actionSendRequestVO.path),
                        method: 1 == e.m_actionSendRequestVO.method ? "POST" : "GET",
                        dataType: "json",
                        data: n
                    },
                    callback: function(n) {
                        if (n.serverData && 200 == n.serverData.statusCode) {
                            var o, r = n.serverData.data[e.m_actionSendRequestVO.protocolTextId];
                            if (t.value = r, e.m_actionSendRequestVO.succAction) o = require("../../WorkflowDP.js").getSingleton().createGearImpl(e.m_actionSendRequestVO.succAction);
                            o ? (o.completeFunction = function(t) {
                                e.completeFunction && e.completeFunction(new l(e, t.isComplete)), e.dispose();
                            }, o.doAction()) : (e.completeFunction && e.completeFunction(new l(e, !0)), e.dispose());
                        } else {
                            var i;
                            if (e.m_actionSendRequestVO.failAction) i = require("../../WorkflowDP.js").getSingleton().createGearImpl(e.m_actionSendRequestVO.failAction);
                            i ? (i.completeFunction = function(t) {
                                e.completeFunction && e.completeFunction(new l(e, t.isComplete)), e.dispose();
                            }, i.doAction()) : (e.completeFunction && e.completeFunction(new l(e, !0)), e.dispose());
                        }
                    },
                    dispose: function() {}
                });
            }(this, require("../../WorkflowDP.js").getSingleton().createGearImpl(this.m_actionSendRequestVO.variableId));
        }
    }, {
        key: "dispose",
        value: function() {
            (0, o.default)((0, c.default)(a.prototype), "dispose", this).call(this), this.m_actionSendRequestVO = null;
        }
    } ]), a;
}(a);