var t = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../../../../@babel/runtime/helpers/classCallCheck")), n = t(require("../../../../../@babel/runtime/helpers/createClass")), o = t(require("../../../../../@babel/runtime/helpers/get")), i = t(require("../../../../../@babel/runtime/helpers/inherits")), l = t(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), c = t(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function r(t) {
    var e = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (t) {
            return !1;
        }
    }();
    return function() {
        var n, o = (0, c.default)(t);
        if (e) {
            var i = (0, c.default)(this).constructor;
            n = Reflect.construct(o, arguments, i);
        } else n = o.apply(this, arguments);
        return (0, l.default)(this, n);
    };
}

var u = require("../../../workflow_common/core/action/ActionBase.js"), a = require("../../../workflow_common/core/action/ActionResult.js");

module.exports = function(t) {
    (0, i.default)(u, t);
    var l = r(u);
    function u(t) {
        var n;
        return (0, e.default)(this, u), (n = l.call(this)).m_actionAlertVO = t, n;
    }
    return (0, n.default)(u, [ {
        key: "doAction",
        value: function() {
            var t, e, n = this, o = {
                content: this.m_actionAlertVO.content,
                title: this.m_actionAlertVO.title,
                buttons: [ {
                    label: this.m_actionAlertVO.label,
                    callback: null
                } ]
            };
            this.m_actionAlertVO.label2 && o.buttons.push({
                label: this.m_actionAlertVO.label2,
                callback: null
            });
            var i = require("../../../workflow_common/Workflow.js");
            this.m_actionAlertVO.clickAction && (t = i.getSingleton().createGearImpl(this.m_actionAlertVO.clickAction)), 
            this.m_actionAlertVO.label2 && this.m_actionAlertVO.clickAction2 && (e = i.getSingleton().createGearImpl(this.m_actionAlertVO.clickAction2)), 
            o.buttons[0].callback = t ? function() {
                t.completeFunction = function(t) {
                    n.completeFunction && n.completeFunction(new a(n, t.isComplete)), n.dispose();
                }, t.doAction();
            } : function() {
                n.completeFunction && n.completeFunction(new a(n, !0)), n.dispose();
            }, o.buttons[1] && (o.buttons[1].callback = e ? function() {
                e.completeFunction = function(t) {
                    n.completeFunction && n.completeFunction(new a(n, t.isComplete)), n.dispose();
                }, e.doAction();
            } : function() {
                n.completeFunction && n.completeFunction(new a(n, !0)), n.dispose();
            }), getApp().env.notify(33101, o);
        }
    }, {
        key: "dispose",
        value: function() {
            (0, o.default)((0, c.default)(u.prototype), "dispose", this).call(this), this.m_actionAlertVO = null;
        }
    } ]), u;
}(u);