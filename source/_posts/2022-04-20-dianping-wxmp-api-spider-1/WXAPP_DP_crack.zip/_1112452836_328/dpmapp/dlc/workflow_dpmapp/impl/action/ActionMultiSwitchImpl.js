var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/typeof")), r = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), i = e(require("../../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../../@babel/runtime/helpers/get")), l = e(require("../../../../../@babel/runtime/helpers/inherits")), a = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), o = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function c(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, i = (0, o.default)(e);
        if (t) {
            var n = (0, o.default)(this).constructor;
            r = Reflect.construct(i, arguments, n);
        } else r = i.apply(this, arguments);
        return (0, a.default)(this, r);
    };
}

var u = require("../../../workflow_common/core/action/ActionBase.js"), s = require("../../../workflow_common/core/action/ActionResult.js");

module.exports = function(e) {
    (0, l.default)(u, e);
    var a = c(u);
    function u(e) {
        var t;
        return (0, r.default)(this, u), (t = a.call(this)).m_gearActionSwitch = e, t.variableId = null, 
        t.field = null, t;
    }
    return (0, i.default)(u, [ {
        key: "doAction",
        value: function(e, r) {
            require("../../WorkflowDP.js");
            if (!this.m_varImpl) {
                var i = require("../../WorkflowDP.js");
                this.m_varImpl = i.getSingleton().createGearImpl(this.m_gearActionSwitch.variableId);
            }
            var n = this.m_varImpl, l = null;
            function a(i, n, l) {
                var a = l.field;
                a && "this" !== a && (n = "object" === (0, t.default)(n) ? n[a] : void 0);
                var o, c = require("../../WorkflowDP.js");
                switch (n) {
                  case l.case1:
                    o = c.getSingleton().createGearImpl(l.action1);
                    break;

                  case l.case2:
                    o = c.getSingleton().createGearImpl(l.action2);
                    break;

                  case l.case3:
                    o = c.getSingleton().createGearImpl(l.action3);
                    break;

                  case l.case4:
                    o = c.getSingleton().createGearImpl(l.action4);
                    break;

                  default:
                    o = c.getSingleton().createGearImpl(l.actionDefault);
                }
                o ? (o.completeFunction = function(e) {
                    i.completeFunction && i.completeFunction(new s(i, e.isComplete)), o.dispose(), i.dispose();
                }, o.doAction(e, r)) : (i.completeFunction && i.completeFunction(new s(i, !0)), 
                i.dispose());
            }
            n.everSetValue ? a(this, n.value, this.m_gearActionSwitch) : (l = function(e) {
                e.removeaddCallBack(l), l = null, a(this, e.value, this.m_gearActionSwitch);
            }.bind(this), n.addCallBack(l));
        }
    }, {
        key: "dispose",
        value: function() {
            this.m_gearActionSwitch = null, (0, n.default)((0, o.default)(u.prototype), "dispose", this).call(this);
        }
    } ]), u;
}(u);