var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/typeof")), r = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), n = e(require("../../../../../@babel/runtime/helpers/createClass")), o = e(require("../../../../../@babel/runtime/helpers/get")), i = e(require("../../../../../@babel/runtime/helpers/inherits")), u = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), c = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function a(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, n = (0, c.default)(e);
        if (t) {
            var o = (0, c.default)(this).constructor;
            r = Reflect.construct(n, arguments, o);
        } else r = n.apply(this, arguments);
        return (0, u.default)(this, r);
    };
}

var s = require("../../../workflow_common/core/action/ActionBase.js"), l = require("../../../workflow_common/core/action/ActionResult.js");

function f(e) {
    return (f = "function" == typeof Symbol && "symbol" === (0, t.default)(Symbol.iterator) ? function(e) {
        return (0, t.default)(e);
    } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : (0, 
        t.default)(e);
    })(e);
}

function p(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            writable: !0,
            configurable: !0
        }
    }), t && h(e, t);
}

function h(e, t) {
    return (h = Object.setPrototypeOf || function(e, t) {
        return e.__proto__ = t, e;
    })(e, t);
}

function m(e) {
    var t = b();
    return function() {
        var r, n = v(e);
        if (t) {
            var o = v(this).constructor;
            r = Reflect.construct(n, arguments, o);
        } else r = n.apply(this, arguments);
        return d(this, r);
    };
}

function d(e, t) {
    return !t || "object" !== f(t) && "function" != typeof t ? y(e) : t;
}

function y(e) {
    if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e;
}

function b() {
    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
    if (Reflect.construct.sham) return !1;
    if ("function" == typeof Proxy) return !0;
    try {
        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
        !0;
    } catch (e) {
        return !1;
    }
}

function v(e) {
    return (v = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
        return e.__proto__ || Object.getPrototypeOf(e);
    })(e);
}

module.exports = function(e) {
    (0, i.default)(u, e);
    var t = a(u);
    function u(e) {
        var n;
        (0, r.default)(this, u), (n = t.call(this)).m_dlcElementId = e.elementGlobalId, 
        n.m_ast = null;
        try {
            n.m_ast = JSON.parse(e.ast);
        } catch (e) {}
        return n;
    }
    return (0, n.default)(u, [ {
        key: "doAction",
        value: function(e, t) {
            if (!this.m_ast) return this.completeFunction && this.completeFunction(new l(this, !0)), 
            void this.dispose();
            e || (e = {
                _$_appFake: require("../../../workflow_common/dlc/PageMVVM.js").createAppFake(),
                dispose: function() {
                    this._$_appFake && this._$_appFake.env && this._$_appFake.env.extraHold.length ? this._$_appFake.env.extraHold.forEach(function(e) {
                        e.evtId;
                    }) : this._$_appFake.env.dispose(), this._$_appFake = null;
                }
            });
            var r = require("../../../../../induction/common/@mtfe/jsvm-with-confusion/jsvm.js").default, n = {
                IS_WXMP: 1
            }, o = {
                getApp: function() {
                    return e._$_appFake;
                },
                getCurrentPages: function(e) {
                    function t() {
                        return e.apply(this, arguments);
                    }
                    return t.toString = function() {
                        return e.toString();
                    }, t;
                }(function() {
                    var t = getCurrentPages();
                    return t.push(e), t;
                }),
                app: e._$_appFake,
                page: e,
                widget: e,
                args_page: e,
                args_event: t,
                widgetClassArray: null,
                _$_HttpProtocol: require("../../../../../framework/class_define/http_protocol.js"),
                _$_HttpRequestTask: require("../../../../../framework/class_define/http_request_task.js"),
                _$_TargetPlatfrom: n,
                _$_RuntimeInfo: require("../../../../../framework/class_define/runtime_info.js"),
                _$_Storage: require("../../../../../framework/utils/storage.js"),
                _$_LayoutUnit: function(e) {
                    return e + "rpx";
                },
                _$_pageWidgetFake: {
                    onLoad: function(e, t) {
                        e.forEach(function(e) {
                            e && e.call(t, t);
                        });
                    },
                    forEachWidget: function() {},
                    onUnload: function() {}
                },
                _typeof: f,
                _classCallCheck: p,
                _inherits: _,
                _setPrototypeOf: h,
                _createSuper: m,
                _possibleConstructorReturn: d,
                _assertThisInitialized: y,
                _isNativeReflectConstruct: b,
                _getPrototypeOf: v
            };
            o.wx = wx, new r(e, o, {
                ThrowVariableNotDefinedException: !1,
                es5: !0
            }).execute(this.m_ast), this.m_dlcElementId || e && (e.dispose.call(e), e = null), 
            this.completeFunction && this.completeFunction(new l(this, !0)), this.dispose();
        }
    }, {
        key: "dispose",
        value: function() {
            this.m_ast = null, this.m_dlcElementId = null, (0, o.default)((0, c.default)(u.prototype), "dispose", this).call(this);
        }
    } ]), u;
}(s);