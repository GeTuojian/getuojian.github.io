var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), o = e(require("../../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../../@babel/runtime/helpers/get")), r = e(require("../../../../../@babel/runtime/helpers/inherits")), i = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), c = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function u(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var o, n = (0, c.default)(e);
        if (t) {
            var r = (0, c.default)(this).constructor;
            o = Reflect.construct(n, arguments, r);
        } else o = n.apply(this, arguments);
        return (0, i.default)(this, o);
    };
}

var l = require("../../../workflow_common/core/action/ActionBase.js"), a = require("../../../workflow_common/core/action/ActionResult.js");

module.exports = function(e) {
    (0, r.default)(l, e);
    var i = u(l);
    function l(e) {
        var o;
        return (0, t.default)(this, l), (o = i.call(this)).m_actionToastVO = e, o;
    }
    return (0, o.default)(l, [ {
        key: "doAction",
        value: function() {
            var e, t = this, o = {
                content: this.m_actionToastVO.content,
                duration: this.m_actionToastVO.duration,
                mask: this.m_actionToastVO.modal
            }, n = require("../../../workflow_common/Workflow.js");
            this.m_actionToastVO.endAction && (e = n.getSingleton().createGearImpl(this.m_actionToastVO.endAction)), 
            o.callback = e ? function() {
                e.completeFunction = function(e) {
                    t.completeFunction && t.completeFunction(new a(t, e.isComplete)), t.dispose();
                }, e.doAction();
            } : function() {
                t.completeFunction && t.completeFunction(new a(t, !0)), t.dispose();
            }, getApp().env.notify(33001, o);
        }
    }, {
        key: "dispose",
        value: function() {
            (0, n.default)((0, c.default)(l.prototype), "dispose", this).call(this), this.m_actionToastVO = null;
        }
    } ]), l;
}(l);