var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), i = e(require("../../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../../@babel/runtime/helpers/assertThisInitialized")), r = e(require("../../../../../@babel/runtime/helpers/get")), o = e(require("../../../../../@babel/runtime/helpers/inherits")), s = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function u(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var i, n = (0, l.default)(e);
        if (t) {
            var r = (0, l.default)(this).constructor;
            i = Reflect.construct(n, arguments, r);
        } else i = n.apply(this, arguments);
        return (0, s.default)(this, i);
    };
}

var a = require("../../../workflow_common/core/condition/ConditionBase.js"), c = require("../../../workflow_common/core/condition/ConditionResult.js");

module.exports = function(e) {
    (0, o.default)(a, e);
    var s = u(a);
    function a(e, i) {
        var r;
        return (0, t.default)(this, a), (r = s.call(this)).m_conditionCitysVO = e, Object.defineProperty((0, 
        n.default)(r), "_app", {
            value: i,
            enumerable: !1
        }), r.m_cityList = r.m_conditionCitysVO.cityList.split(","), r._app.env.register(43002, r._onCityChange, (0, 
        n.default)(r)), r;
    }
    return (0, i.default)(a, [ {
        key: "_onCityChange",
        value: function(e, t, i, n) {
            if (t.swapData === n._app.userData && ("dpCityName" === t.field && 1 & n.m_conditionCitysVO.cityType || "dpLocCityName" === t.field && 4 & n.m_conditionCitysVO.cityType)) {
                var r = n.recentConditionResult;
                n.getConditionResult(), n.recentConditionResult.isComplete && (r && r.isComplete && r.bool === n.recentConditionResult.bool || n.onConditionChange()), 
                r = null;
            }
        }
    }, {
        key: "getConditionResult",
        value: function() {
            var e = [];
            if (1 & this.m_conditionCitysVO.cityType && (this._app.userData.dpCityName ? e.push({
                isComplete: 1,
                city: this._app.userData.dpCityName
            }) : e.push({
                isComplete: 0
            })), 4 & this.m_conditionCitysVO.cityType) {
                var t = require("../../../../../framework/mtdp_bucket/async_data_provider/loc_cityid_provider.js");
                if (t.setApp(this._app), t.isDataPrepared()) {
                    var i = t.getDataSync();
                    if (Array.isArray(i)) for (var n = 0; n < i.length; n++) "locCityName" === i[n].key && e.push({
                        isComplete: 1,
                        city: i[n].value
                    });
                } else e.push({
                    isComplete: 0
                });
            }
            2 & this.m_conditionCitysVO.cityType && e.push({
                isComplete: 0
            });
            for (var r = this.m_conditionCitysVO.inCitys, o = 0, s = 0; s < e.length; s++) if (e[s].isComplete && (o++, 
            -1 !== this.m_cityList.indexOf(e[s].city))) return this.recentConditionResult = new c(!!r, !0), 
            this.recentConditionResult;
            return o === e.length ? this.recentConditionResult = new c(!r, !0) : this.recentConditionResult = new c(void 0, !1), 
            this.recentConditionResult;
        }
    }, {
        key: "dispose",
        value: function() {
            this.reference--, this.reference || (this._app && (this._app.env.unregister(43002, this._onCityChange, this), 
            this._app = null), this.m_conditionCitysVO = null, this.recentConditionResult = null, 
            (0, r.default)((0, l.default)(a.prototype), "dispose", this).call(this));
        }
    } ]), a;
}(a);