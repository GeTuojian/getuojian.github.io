var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), r = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), t = e(require("../../../../../@babel/runtime/helpers/inherits")), n = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), o = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function i(e) {
    var r = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var t, i = (0, o.default)(e);
        if (r) {
            var u = (0, o.default)(this).constructor;
            t = Reflect.construct(i, arguments, u);
        } else t = i.apply(this, arguments);
        return (0, n.default)(this, t);
    };
}

var u = require("../../../workflow_common/core/condition/ConditionTwoCondition.js");

require("../../../workflow_common/core/condition/ConditionResult.js");

module.exports = function(e) {
    (0, t.default)(o, e);
    var n = i(o);
    function o(e) {
        (0, r.default)(this, o);
        var t = require("../../WorkflowDP.js");
        return n.call(this, function() {
            return t.getSingleton().createGearImpl(e.condition0);
        }, function() {
            return t.getSingleton().createGearImpl(e.condition1);
        }, 2);
    }
    return o;
}(u);