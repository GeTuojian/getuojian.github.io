var e = require("../../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../../@babel/runtime/helpers/get")), o = e(require("../../../../../@babel/runtime/helpers/inherits")), i = e(require("../../../../../@babel/runtime/helpers/possibleConstructorReturn")), u = e(require("../../../../../@babel/runtime/helpers/getPrototypeOf"));

function c(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, n = (0, u.default)(e);
        if (t) {
            var o = (0, u.default)(this).constructor;
            r = Reflect.construct(n, arguments, o);
        } else r = n.apply(this, arguments);
        return (0, i.default)(this, r);
    };
}

var l = require("../../../workflow_common/core/action/ActionBase.js"), s = require("../../../workflow_common/core/action/ActionResult.js");

module.exports = function(e) {
    (0, o.default)(l, e);
    var i = c(l);
    function l(e) {
        var r;
        return (0, t.default)(this, l), (r = i.call(this)).m_destAction = e.actionWXMP, 
        void 0 === r.m_destAction && (r.m_destAction = e.actionOTHER), r;
    }
    return (0, r.default)(l, [ {
        key: "doAction",
        value: function() {
            var e, t = this;
            this.m_destAction && (e = require("../../WorkflowDP.js").getSingleton().createGearImpl(this.m_destAction));
            e ? (e.completeFunction = function(e) {
                t.completeFunction && t.completeFunction(new s(t, e.isComplete)), t.dispose();
            }, e.doAction()) : (this.completeFunction && this.completeFunction(new s(this, !0)), 
            this.dispose());
        }
    }, {
        key: "dispose",
        value: function() {
            (0, n.default)((0, u.default)(l.prototype), "dispose", this).call(this), this.m_destAction = null;
        }
    } ]), l;
}(l);