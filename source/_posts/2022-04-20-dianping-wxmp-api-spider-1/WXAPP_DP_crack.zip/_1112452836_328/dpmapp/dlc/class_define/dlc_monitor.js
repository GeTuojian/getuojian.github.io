var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), a = e(require("../../../@babel/runtime/helpers/classCallCheck")), l = e(require("../../../@babel/runtime/helpers/createClass")), t = function() {
    function e() {
        (0, a.default)(this, e);
    }
    return (0, l.default)(e, [ {
        key: "openNewDLCElementInGear",
        value: function(e, a, l, t, i, n, r) {
            var o = require("../service/gear_script_auto_load_service.js"), s = this, _ = o.getGearInfo(a);
            return void (_ && _.gear && 4 === _.status ? d(_.gear) : (this.monitorGearLoaded || (this.monitorGearLoaded = function(e, l) {
                var t = l.gearInfo;
                t.id === a && (s.monitorGearLoaded && (getApp().env.unregister("__ON_A_GEAR_SCRIPT_LOEADED_", s.monitorGearLoaded), 
                s.monitorGearLoaded = null), d(t.gear));
            }.bind(this), getApp().env.register("__ON_A_GEAR_SCRIPT_LOEADED_", this.monitorGearLoaded)), 
            "pd_" == a.substr(0, 3) && o.loadPDGear(a.substr(3))));
            function d(a) {
                if (l) {
                    var o = {
                        gear: a
                    };
                    l(o), a = o.gear;
                }
                var _ = a.instancePool;
                for (var d in _) {
                    var c = _[d];
                    "ActionShowHideDLCElement" === c.className && c.isOpen && s.openNewDLCElement(e, c.elementGlobalId, Object.assign({
                        pageQuery: c.pageQuery,
                        mask: c.mask,
                        animeType: c.animeType
                    }, n), t, i, r);
                }
            }
        }
    }, {
        key: "openNewDLCElement",
        value: function(e, a, l, t, i, n) {
            var r = this, o = require("../../dlc/workflow_dpmapp/WorkflowDP.js").getSingleton().createGearImpl(Object.assign({
                className: "ActionShowHideDLCElement",
                elementGlobalId: a,
                isOpen: 1,
                pageQuery: null,
                mask: 7,
                animeType: 0
            }, l));
            if (o) {
                t && (this.dlcLoadedCallback = function(e, l, i, n) {
                    n === r && l.pageName === a && (getApp().env.unregister("__ON_A_DLC_ELEMENT_LOADED_", r.dlcLoadedCallback, r), 
                    r.dlcLoadedCallback = null, t(l), t = null);
                }, getApp().env.register("__ON_A_DLC_ELEMENT_LOADED_", this.dlcLoadedCallback, this)), 
                i && (this.dlcClosingCallback = function(e, l, t, n) {
                    n === r && l.pageName === a && (getApp().env.unregister("__ON_A_DLC_ELEMENT_UNLOADING_", r.dlcClosingCallback, r), 
                    r.dlcClosingCallback = null, i(l), i = null);
                }, getApp().env.register("__ON_A_DLC_ELEMENT_UNLOADING_", this.dlcClosingCallback, this));
                var s = o.doAction(e);
                s && n && s.setData(n);
            }
        }
    }, {
        key: "dispose",
        value: function() {
            this.monitorGearLoaded && (getApp().env.unregister("__ON_A_GEAR_SCRIPT_LOEADED_", this.monitorGearLoaded), 
            this.monitorGearLoaded = null), this.dlcLoadedCallback && (getApp().env.unregister("__ON_A_DLC_ELEMENT_LOADED_", this.dlcLoadedCallback, this), 
            this.dlcLoadedCallback = null), this.dlcClosingCallback && (getApp().env.unregister("__ON_A_DLC_ELEMENT_UNLOADING_", this.dlcClosingCallback, this), 
            this.dlcClosingCallback = null);
        }
    } ]), e;
}();

module.exports = t;