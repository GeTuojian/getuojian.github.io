var i = require("../gear_common/GearEnv.js");

i.prototype.init = function() {
    var i = {
        ActionAlert: require("../gear_dpmapp/action/ActionAlert.js"),
        ActionAntiTiredAction: require("../gear_dpmapp/action/ActionAntiTiredAction.js"),
        ActionToast: require("../gear_dpmapp/action/ActionToast.js"),
        ActionCondition: require("../gear_dpmapp/action/ActionCondition.js"),
        ActionNavigate: require("../gear_dpmapp/action/ActionNavigate.js"),
        ActionComputeVar: require("../gear_dpmapp/action/ActionComputeVar.js"),
        ActionMultiBatch: require("../gear_dpmapp/action/ActionMultiBatch.js"),
        ActionMultiSeq: require("../gear_dpmapp/action/ActionMultiSeq.js"),
        ActionMultiSwitch: require("../gear_dpmapp/action/ActionMultiSwitch.js"),
        ActionDelayAction: require("../gear_dpmapp/action/ActionDelayAction.js"),
        ActionSendRequest: require("../gear_dpmapp/action/ActionSendRequest.js"),
        ActionNamedFunction: require("../gear_dpmapp/action/ActionNamedFunction.js"),
        ActionDoCasterFunction: require("../gear_dpmapp/action/ActionDoCasterFunction.js"),
        ActionSwitchPlatform: require("../gear_dpmapp/action/ActionSwitchPlatform.js"),
        ActionShowHideDLCElement: require("../gear_dpmapp/action/ActionShowHideDLCElement.js"),
        ConditionAnd: require("../gear_dpmapp/condition/ConditionAnd.js"),
        ConditionAnd4: require("../gear_dpmapp/condition/ConditionAnd4.js"),
        ConditionOr: require("../gear_dpmapp/condition/ConditionOr.js"),
        ConditionXor: require("../gear_dpmapp/condition/ConditionXor.js"),
        ConditionVariable: require("../gear_dpmapp/condition/ConditionVariable.js"),
        ConditionTimeZone: require("../gear_dpmapp/condition/ConditionTimeZone.js"),
        ConditionMultiTimeZone8: require("../gear_dpmapp/condition/ConditionMultiTimeZone8.js"),
        ConditionCustomerType: require("../gear_dpmapp/condition/ConditionCustomerType.js"),
        ConditionHaimaUserLayer: require("../gear_dpmapp/condition/ConditionHaimaUserLayer.js"),
        ConditionCitys: require("../gear_dpmapp/condition/ConditionCitys.js"),
        ConditionPages: require("../gear_dpmapp/condition/ConditionPages.js"),
        ConditionCircuitBreaker: require("../gear_dpmapp/condition/ConditionCircuitBreaker.js"),
        VariableGlobal: require("../gear_dpmapp/variable/VariableGlobal.js"),
        VariableLocal: require("../gear_dpmapp/variable/VariableLocal.js"),
        VariableReqParam: require("../gear_dpmapp/variable/VariableReqParam.js"),
        DPCommonConfig: require("../gear_dpmapp/view/DPCommonConfig.js"),
        "首页-金刚位": require("./view/ViewMainKK.js"),
        "首页-中通位": require("../gear_dpmapp/view/ViewMainMidThrough.js"),
        "我的页-图标位": require("../gear_dpmapp/view/ViewProfileIcon.js"),
        "通用-侧边栏按钮": require("../gear_dpmapp/view/ViewSideIcon.js"),
        DLCElement: require("../gear_dpmapp/view/DLCElement.js"),
        TriggerOnScriptIninted: require("../gear_dpmapp/trigger/TriggerOnScriptIninted.js"),
        TriggerOnPageInited: require("../gear_dpmapp/trigger/TriggerOnPageInited.js"),
        TriggerOnFrameworkEvent: require("../gear_dpmapp/trigger/TriggerOnFrameworkEvent.js"),
        TriggerOnConditionChanged: require("../gear_dpmapp/trigger/TriggerOnConditionChanged.js"),
        TriggerOnVariableChanged: require("../gear_dpmapp/trigger/TriggerOnVariableChanged.js")
    };
    Object.assign(this.env_classDict, i);
    var e = new i.VariableGlobal(4100);
    e.globalId = "__G_LOGIN_STATUS__";
    var r = new i.VariableGlobal(4101);
    r.globalId = "__G_ENABLE_DEBUG__";
    var a = require("../gear_common/GearClassInstanceBase.js"), n = new a(5001);
    n._className = "ConditionAlways";
    var o = new a(5002);
    o._className = "ConditionNever";
    var t = new i.ConditionVariable(5100);
    t.variableId = e, t.comparator = 2, t.value = 1;
    var p = new i.ConditionVariable(5101);
    p.variableId = r, p.comparator = 3, p.value = 1, Object.assign(this.env_instancePool, {
        3000: null,
        4100: e,
        4101: r,
        5001: n,
        5002: o,
        5100: t,
        5101: p
    });
}, module.exports = i;