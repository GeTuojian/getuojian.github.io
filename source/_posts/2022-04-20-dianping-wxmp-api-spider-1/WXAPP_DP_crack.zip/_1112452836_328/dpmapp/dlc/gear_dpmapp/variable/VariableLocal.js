var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../@babel/runtime/helpers/createClass")), u = e(require("../../../../@babel/runtime/helpers/inherits")), a = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function n(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, u = (0, l.default)(e);
        if (t) {
            var n = (0, l.default)(this).constructor;
            r = Reflect.construct(u, arguments, n);
        } else r = u.apply(this, arguments);
        return (0, a.default)(this, r);
    };
}

var i = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, u.default)(l, e);
    var a = n(l);
    function l(e) {
        var r;
        return (0, t.default)(this, l), (r = a.call(this, e))._className = "VariableLocal", 
        r.hasDefaultValue = 0, r.defaultValue = 0, r;
    }
    return (0, r.default)(l, [ {
        key: "decode",
        value: function(e, t, r) {
            this.hasDefaultValue = r.readUnsignedByte(), this.defaultValue = r.readByteOrShortOrInt();
        }
    } ]), l;
}(i);