var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../@babel/runtime/helpers/get")), u = e(require("../../../../@babel/runtime/helpers/inherits")), a = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function i(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, n = (0, l.default)(e);
        if (t) {
            var u = (0, l.default)(this).constructor;
            r = Reflect.construct(n, arguments, u);
        } else r = n.apply(this, arguments);
        return (0, a.default)(this, r);
    };
}

var s = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, u.default)(s, e);
    var a = i(s);
    function s(e) {
        var r;
        return (0, t.default)(this, s), (r = a.call(this, e))._className = "ActionNavigate", 
        r.pageName = null, r.navType = 0, r;
    }
    return (0, r.default)(s, [ {
        key: "decode",
        value: function(e, t, r) {
            this.pageName = t.getString(r.readUnsignedByteOrShort()), this.navType = r.readUnsignedByte();
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.pageName = null, (0, n.default)((0, l.default)(s.prototype), "dispose", this).call(this);
        }
    } ]), s;
}(s);