var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), n = e(require("../../../../@babel/runtime/helpers/createClass")), i = e(require("../../../../@babel/runtime/helpers/get")), r = e(require("../../../../@babel/runtime/helpers/inherits")), l = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), s = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function o(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var n, i = (0, s.default)(e);
        if (t) {
            var r = (0, s.default)(this).constructor;
            n = Reflect.construct(i, arguments, r);
        } else n = i.apply(this, arguments);
        return (0, l.default)(this, n);
    };
}

var u = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, r.default)(u, e);
    var l = o(u);
    function u(e) {
        var n;
        return (0, t.default)(this, u), (n = l.call(this, e))._className = "ConditionAnd4", 
        n.condition0 = null, n.condition1 = null, n.condition2 = null, n.condition3 = null, 
        n;
    }
    return (0, n.default)(u, [ {
        key: "decode",
        value: function(e, t, n) {
            this.condition0 = e.getClassInstance(t, n.readUnsignedInt()), this.condition1 = e.getClassInstance(t, n.readUnsignedInt()), 
            this.condition2 = e.getClassInstance(t, n.readUnsignedInt()), this.condition3 = e.getClassInstance(t, n.readUnsignedInt());
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.condition0 = null, this.condition1 = null, this.condition2 = null, this.condition3 = null, 
            (0, i.default)((0, s.default)(u.prototype), "dispose", this).call(this);
        }
    } ]), u;
}(u);