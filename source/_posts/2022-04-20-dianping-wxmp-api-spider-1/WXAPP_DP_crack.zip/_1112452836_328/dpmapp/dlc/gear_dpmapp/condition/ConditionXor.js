var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../@babel/runtime/helpers/get")), i = e(require("../../../../@babel/runtime/helpers/inherits")), u = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function s(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, n = (0, l.default)(e);
        if (t) {
            var i = (0, l.default)(this).constructor;
            r = Reflect.construct(n, arguments, i);
        } else r = n.apply(this, arguments);
        return (0, u.default)(this, r);
    };
}

var o = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, i.default)(o, e);
    var u = s(o);
    function o(e) {
        var r;
        return (0, t.default)(this, o), (r = u.call(this, e))._className = "ConditionXor", 
        r.condition0 = null, r.condition1 = null, r;
    }
    return (0, r.default)(o, [ {
        key: "decode",
        value: function(e, t, r) {
            this.condition0 = e.getClassInstance(t, r.readUnsignedInt()), this.condition1 = e.getClassInstance(t, r.readUnsignedInt());
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.condition0 = null, this.condition1 = null, (0, n.default)((0, l.default)(o.prototype), "dispose", this).call(this);
        }
    } ]), o;
}(o);