var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../@babel/runtime/helpers/createClass")), a = e(require("../../../../@babel/runtime/helpers/get")), n = e(require("../../../../@babel/runtime/helpers/inherits")), u = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function i(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, a = (0, l.default)(e);
        if (t) {
            var n = (0, l.default)(this).constructor;
            r = Reflect.construct(a, arguments, n);
        } else r = a.apply(this, arguments);
        return (0, u.default)(this, r);
    };
}

var s = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, n.default)(s, e);
    var u = i(s);
    function s(e) {
        var r;
        return (0, t.default)(this, s), (r = u.call(this, e))._className = "ActionComputeVar", 
        r.variableId = null, r.operater = 0, r.value = 0, r;
    }
    return (0, r.default)(s, [ {
        key: "decode",
        value: function(e, t, r) {
            this.variableId = e.getClassInstance(t, r.readUnsignedInt()), this.operater = r.readUnsignedByte(), 
            this.value = r.readByteOrShortOrInt();
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.variableId = null, (0, a.default)((0, l.default)(s.prototype), "dispose", this).call(this);
        }
    } ]), s;
}(s);