var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../@babel/runtime/helpers/get")), i = e(require("../../../../@babel/runtime/helpers/inherits")), l = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), u = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function s(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, n = (0, u.default)(e);
        if (t) {
            var i = (0, u.default)(this).constructor;
            r = Reflect.construct(n, arguments, i);
        } else r = n.apply(this, arguments);
        return (0, l.default)(this, r);
    };
}

var o = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, i.default)(o, e);
    var l = s(o);
    function o(e) {
        var r;
        return (0, t.default)(this, o), (r = l.call(this, e))._className = "ViewMainMidThrough", 
        r.imageUrl = null, r.commonConfig = null, r;
    }
    return (0, r.default)(o, [ {
        key: "decode",
        value: function(e, t, r) {
            this.imageUrl = t.getString(r.readUnsignedByteOrShort()), this.commonConfig = e.getClassInstance(t, r.readUnsignedInt());
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.imageUrl = null, this.commonConfig && (e.disposeInstance(t, this.commonConfig.instanceUID), 
            this.commonConfig = null), (0, n.default)((0, u.default)(o.prototype), "dispose", this).call(this);
        }
    } ]), o;
}(o);