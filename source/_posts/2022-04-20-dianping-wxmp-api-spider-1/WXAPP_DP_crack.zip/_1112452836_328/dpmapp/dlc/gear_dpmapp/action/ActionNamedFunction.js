var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../@babel/runtime/helpers/get")), l = e(require("../../../../@babel/runtime/helpers/inherits")), i = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), u = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function s(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, n = (0, u.default)(e);
        if (t) {
            var l = (0, u.default)(this).constructor;
            r = Reflect.construct(n, arguments, l);
        } else r = n.apply(this, arguments);
        return (0, i.default)(this, r);
    };
}

var a = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, l.default)(a, e);
    var i = s(a);
    function a(e) {
        var r;
        return (0, t.default)(this, a), (r = i.call(this, e))._className = "ActionNamedFunction", 
        r.element = null, r.functionName = null, r.triggerAction = null, r.closePanel = 0, 
        r;
    }
    return (0, r.default)(a, [ {
        key: "decode",
        value: function(e, t, r) {
            this.element = e.getClassInstance(t, r.readUnsignedInt()), this.functionName = t.getString(r.readUnsignedByteOrShort()), 
            this.triggerAction = e.getClassInstance(t, r.readUnsignedInt()), this.closePanel = r.readUnsignedByte();
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.element = null, this.functionName = null, this.triggerAction = null, (0, n.default)((0, 
            u.default)(a.prototype), "dispose", this).call(this);
        }
    } ]), a;
}(a);