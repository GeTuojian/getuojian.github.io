var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), n = e(require("../../../../@babel/runtime/helpers/createClass")), r = e(require("../../../../@babel/runtime/helpers/get")), a = e(require("../../../../@babel/runtime/helpers/inherits")), i = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), s = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function l(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var n, r = (0, s.default)(e);
        if (t) {
            var a = (0, s.default)(this).constructor;
            n = Reflect.construct(r, arguments, a);
        } else n = r.apply(this, arguments);
        return (0, i.default)(this, n);
    };
}

var u = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, a.default)(u, e);
    var i = l(u);
    function u(e) {
        var n;
        return (0, t.default)(this, u), (n = i.call(this, e))._className = "ActionMultiSwitch", 
        n.variableId = null, n.field = null, n.case1 = 0, n.action1 = null, n.case2 = 0, 
        n.action2 = null, n.case3 = 0, n.action3 = null, n.case4 = 0, n.action4 = null, 
        n.actionDefault = null, n;
    }
    return (0, n.default)(u, [ {
        key: "decode",
        value: function(e, t, n) {
            this.variableId = e.getClassInstance(t, n.readUnsignedInt()), this.field = t.getString(n.readUnsignedByteOrShort()), 
            this.case1 = n.readByteOrShortOrInt(), this.action1 = e.getClassInstance(t, n.readUnsignedInt()), 
            this.case2 = n.readByteOrShortOrInt(), this.action2 = e.getClassInstance(t, n.readUnsignedInt()), 
            this.case3 = n.readByteOrShortOrInt(), this.action3 = e.getClassInstance(t, n.readUnsignedInt()), 
            this.case4 = n.readByteOrShortOrInt(), this.action4 = e.getClassInstance(t, n.readUnsignedInt()), 
            this.actionDefault = e.getClassInstance(t, n.readUnsignedInt());
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.variableId = null, this.field = null, this.action1 = null, this.action2 = null, 
            this.action3 = null, this.action4 = null, this.actionDefault = null, (0, r.default)((0, 
            s.default)(u.prototype), "dispose", this).call(this);
        }
    } ]), u;
}(u);