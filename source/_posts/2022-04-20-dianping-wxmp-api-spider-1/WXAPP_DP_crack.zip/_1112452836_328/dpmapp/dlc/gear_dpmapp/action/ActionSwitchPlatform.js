var t = require("../../../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../../../@babel/runtime/helpers/classCallCheck")), n = t(require("../../../../@babel/runtime/helpers/createClass")), a = t(require("../../../../@babel/runtime/helpers/get")), i = t(require("../../../../@babel/runtime/helpers/inherits")), s = t(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = t(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function r(t) {
    var e = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (t) {
            return !1;
        }
    }();
    return function() {
        var n, a = (0, l.default)(t);
        if (e) {
            var i = (0, l.default)(this).constructor;
            n = Reflect.construct(a, arguments, i);
        } else n = a.apply(this, arguments);
        return (0, s.default)(this, n);
    };
}

var c = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(t) {
    (0, i.default)(c, t);
    var s = r(c);
    function c(t) {
        var n;
        return (0, e.default)(this, c), (n = s.call(this, t))._className = "ActionSwitchPlatform", 
        n.actionWXMP = null, n.actionSWAN = null, n.actionTTMA = null, n.actionKSMP = null, 
        n.actionMMP = null, n.actionH5WX = null, n.actionH5DPAPP = null, n.actionH5MTAPP = null, 
        n.actionH5 = null, n.actionOTHER = null, n;
    }
    return (0, n.default)(c, [ {
        key: "decode",
        value: function(t, e, n) {
            this.actionWXMP = t.getClassInstance(e, n.readUnsignedInt()), this.actionSWAN = t.getClassInstance(e, n.readUnsignedInt()), 
            this.actionTTMA = t.getClassInstance(e, n.readUnsignedInt()), this.actionKSMP = t.getClassInstance(e, n.readUnsignedInt()), 
            this.actionMMP = t.getClassInstance(e, n.readUnsignedInt()), this.actionH5WX = t.getClassInstance(e, n.readUnsignedInt()), 
            this.actionH5DPAPP = t.getClassInstance(e, n.readUnsignedInt()), this.actionH5MTAPP = t.getClassInstance(e, n.readUnsignedInt()), 
            this.actionH5 = t.getClassInstance(e, n.readUnsignedInt()), this.actionOTHER = t.getClassInstance(e, n.readUnsignedInt());
        }
    }, {
        key: "dispose",
        value: function(t, e) {
            this.actionWXMP = null, this.actionSWAN = null, this.actionTTMA = null, this.actionKSMP = null, 
            this.actionMMP = null, this.actionH5WX = null, this.actionH5DPAPP = null, this.actionH5MTAPP = null, 
            this.actionH5 = null, this.actionOTHER = null, (0, a.default)((0, l.default)(c.prototype), "dispose", this).call(this);
        }
    } ]), c;
}(c);