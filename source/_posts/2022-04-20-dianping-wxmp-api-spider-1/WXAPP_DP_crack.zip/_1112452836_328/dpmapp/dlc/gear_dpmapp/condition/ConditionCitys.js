var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../@babel/runtime/helpers/createClass")), i = e(require("../../../../@babel/runtime/helpers/get")), n = e(require("../../../../@babel/runtime/helpers/inherits")), u = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), s = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function l(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, i = (0, s.default)(e);
        if (t) {
            var n = (0, s.default)(this).constructor;
            r = Reflect.construct(i, arguments, n);
        } else r = i.apply(this, arguments);
        return (0, u.default)(this, r);
    };
}

var a = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, n.default)(a, e);
    var u = l(a);
    function a(e) {
        var r;
        return (0, t.default)(this, a), (r = u.call(this, e))._className = "ConditionCitys", 
        r.cityType = 0, r.inCitys = 0, r.cityList = null, r;
    }
    return (0, r.default)(a, [ {
        key: "decode",
        value: function(e, t, r) {
            this.cityType = r.readUnsignedByte(), this.inCitys = r.readUnsignedByte(), this.cityList = t.getString(r.readUnsignedByteOrShort());
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.cityList = null, (0, i.default)((0, s.default)(a.prototype), "dispose", this).call(this);
        }
    } ]), a;
}(a);