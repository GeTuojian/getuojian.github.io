var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), r = e(require("../../../../@babel/runtime/helpers/classCallCheck")), t = e(require("../../../../@babel/runtime/helpers/createClass")), u = e(require("../../../../@babel/runtime/helpers/get")), i = e(require("../../../../@babel/runtime/helpers/inherits")), n = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function a(e) {
    var r = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var t, u = (0, l.default)(e);
        if (r) {
            var i = (0, l.default)(this).constructor;
            t = Reflect.construct(u, arguments, i);
        } else t = u.apply(this, arguments);
        return (0, n.default)(this, t);
    };
}

var s = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, i.default)(s, e);
    var n = a(s);
    function s(e) {
        var t;
        return (0, r.default)(this, s), (t = n.call(this, e))._className = "ConditionCircuitBreaker", 
        t.circuitBreakerNum = null, t;
    }
    return (0, t.default)(s, [ {
        key: "decode",
        value: function(e, r, t) {
            this.circuitBreakerNum = r.getString(t.readUnsignedByteOrShort());
        }
    }, {
        key: "dispose",
        value: function(e, r) {
            this.circuitBreakerNum = null, (0, u.default)((0, l.default)(s.prototype), "dispose", this).call(this);
        }
    } ]), s;
}(s);