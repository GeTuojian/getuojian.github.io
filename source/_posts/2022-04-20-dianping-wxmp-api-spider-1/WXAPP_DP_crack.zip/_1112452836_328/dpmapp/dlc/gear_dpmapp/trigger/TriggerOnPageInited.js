var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../@babel/runtime/helpers/get")), i = e(require("../../../../@babel/runtime/helpers/inherits")), a = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), u = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function l(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, n = (0, u.default)(e);
        if (t) {
            var i = (0, u.default)(this).constructor;
            r = Reflect.construct(n, arguments, i);
        } else r = n.apply(this, arguments);
        return (0, a.default)(this, r);
    };
}

var s = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, i.default)(s, e);
    var a = l(s);
    function s(e) {
        var r;
        return (0, t.default)(this, s), (r = a.call(this, e))._className = "TriggerOnPageInited", 
        r.pageName = null, r.triggerAction = null, r.triggerStackPages = 0, r;
    }
    return (0, r.default)(s, [ {
        key: "decode",
        value: function(e, t, r) {
            this.pageName = t.getString(r.readUnsignedByteOrShort()), this.triggerAction = e.getClassInstance(t, r.readUnsignedInt()), 
            this.triggerStackPages = r.readUnsignedByte();
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.pageName = null, this.triggerAction = null, (0, n.default)((0, u.default)(s.prototype), "dispose", this).call(this);
        }
    } ]), s;
}(s);