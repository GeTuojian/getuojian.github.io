var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), l = e(require("../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../@babel/runtime/helpers/get")), r = e(require("../../../../@babel/runtime/helpers/inherits")), i = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), u = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function s(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var l, n = (0, u.default)(e);
        if (t) {
            var r = (0, u.default)(this).constructor;
            l = Reflect.construct(n, arguments, r);
        } else l = n.apply(this, arguments);
        return (0, i.default)(this, l);
    };
}

var c = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, r.default)(c, e);
    var i = s(c);
    function c(e) {
        var l;
        return (0, t.default)(this, c), (l = i.call(this, e))._className = "ActionAlert", 
        l.title = null, l.content = null, l.label = null, l.clickAction = null, l.label2 = null, 
        l.clickAction2 = null, l;
    }
    return (0, l.default)(c, [ {
        key: "decode",
        value: function(e, t, l) {
            this.title = t.getString(l.readUnsignedByteOrShort()), this.content = t.getString(l.readUnsignedByteOrShort()), 
            this.label = t.getString(l.readUnsignedByteOrShort()), this.clickAction = e.getClassInstance(t, l.readUnsignedInt()), 
            this.label2 = t.getString(l.readUnsignedByteOrShort()), this.clickAction2 = e.getClassInstance(t, l.readUnsignedInt());
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.title = null, this.content = null, this.label = null, this.clickAction = null, 
            this.label2 = null, this.clickAction2 = null, (0, n.default)((0, u.default)(c.prototype), "dispose", this).call(this);
        }
    } ]), c;
}(c);