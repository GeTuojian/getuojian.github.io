var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), n = e(require("../../../../@babel/runtime/helpers/createClass")), r = e(require("../../../../@babel/runtime/helpers/get")), a = e(require("../../../../@babel/runtime/helpers/inherits")), i = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function s(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var n, r = (0, l.default)(e);
        if (t) {
            var a = (0, l.default)(this).constructor;
            n = Reflect.construct(r, arguments, a);
        } else n = r.apply(this, arguments);
        return (0, i.default)(this, n);
    };
}

var u = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, a.default)(u, e);
    var i = s(u);
    function u(e) {
        var n;
        return (0, t.default)(this, u), (n = i.call(this, e))._className = "ActionMultiBatch", 
        n.action1 = null, n.action2 = null, n.action3 = null, n.action4 = null, n;
    }
    return (0, n.default)(u, [ {
        key: "decode",
        value: function(e, t, n) {
            this.action1 = e.getClassInstance(t, n.readUnsignedInt()), this.action2 = e.getClassInstance(t, n.readUnsignedInt()), 
            this.action3 = e.getClassInstance(t, n.readUnsignedInt()), this.action4 = e.getClassInstance(t, n.readUnsignedInt());
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.action1 = null, this.action2 = null, this.action3 = null, this.action4 = null, 
            (0, r.default)((0, l.default)(u.prototype), "dispose", this).call(this);
        }
    } ]), u;
}(u);