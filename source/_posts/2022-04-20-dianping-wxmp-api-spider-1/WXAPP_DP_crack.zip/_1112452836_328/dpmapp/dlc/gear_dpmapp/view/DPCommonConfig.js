var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../@babel/runtime/helpers/createClass")), i = e(require("../../../../@babel/runtime/helpers/get")), n = e(require("../../../../@babel/runtime/helpers/inherits")), l = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), s = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function u(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, i = (0, s.default)(e);
        if (t) {
            var n = (0, s.default)(this).constructor;
            r = Reflect.construct(i, arguments, n);
        } else r = i.apply(this, arguments);
        return (0, l.default)(this, r);
    };
}

var o = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, n.default)(o, e);
    var l = u(o);
    function o(e) {
        var r;
        return (0, t.default)(this, o), (r = l.call(this, e))._className = "DPCommonConfig", 
        r.showPrority = 0, r.sortPrority = 0, r.rtc = 0, r.device = 0, r.visibleCondition = null, 
        r.lxmv = null, r.lxmc = null, r.clickAction = null, r.preventMultiClick = 0, r;
    }
    return (0, r.default)(o, [ {
        key: "decode",
        value: function(e, t, r) {
            this.showPrority = r.readByteOrShortOrInt(), this.sortPrority = r.readByteOrShortOrInt(), 
            this.rtc = r.readUnsignedByteOrShort(), this.device = r.readUnsignedByte(), this.visibleCondition = e.getClassInstance(t, r.readUnsignedInt()), 
            this.lxmv = t.getString(r.readUnsignedByteOrShort()), this.lxmc = t.getString(r.readUnsignedByteOrShort()), 
            this.clickAction = e.getClassInstance(t, r.readUnsignedInt()), this.preventMultiClick = r.readUnsignedByte();
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.visibleCondition = null, this.lxmv = null, this.lxmc = null, this.clickAction = null, 
            (0, i.default)((0, s.default)(o.prototype), "dispose", this).call(this);
        }
    } ]), o;
}(o);