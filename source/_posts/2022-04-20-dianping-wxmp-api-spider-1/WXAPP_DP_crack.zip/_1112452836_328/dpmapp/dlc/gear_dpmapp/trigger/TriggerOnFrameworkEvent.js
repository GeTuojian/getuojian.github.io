var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../@babel/runtime/helpers/get")), u = e(require("../../../../@babel/runtime/helpers/inherits")), i = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function s(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, n = (0, l.default)(e);
        if (t) {
            var u = (0, l.default)(this).constructor;
            r = Reflect.construct(n, arguments, u);
        } else r = n.apply(this, arguments);
        return (0, i.default)(this, r);
    };
}

var a = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, u.default)(a, e);
    var i = s(a);
    function a(e) {
        var r;
        return (0, t.default)(this, a), (r = i.call(this, e))._className = "TriggerOnFrameworkEvent", 
        r.eventId = 0, r.triggerAction = null, r;
    }
    return (0, r.default)(a, [ {
        key: "decode",
        value: function(e, t, r) {
            this.eventId = r.readUnsignedShortOrInt(), this.triggerAction = e.getClassInstance(t, r.readUnsignedInt());
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.triggerAction = null, (0, n.default)((0, l.default)(a.prototype), "dispose", this).call(this);
        }
    } ]), a;
}(a);