var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../@babel/runtime/helpers/inherits")), u = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), i = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function s(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, n = (0, i.default)(e);
        if (t) {
            var s = (0, i.default)(this).constructor;
            r = Reflect.construct(n, arguments, s);
        } else r = n.apply(this, arguments);
        return (0, u.default)(this, r);
    };
}

var a = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, n.default)(i, e);
    var u = s(i);
    function i(e) {
        var r;
        return (0, t.default)(this, i), (r = u.call(this, e))._className = "ConditionTimeZone", 
        r.t0 = 0, r.t1 = 0, r.reverseReturn = 0, r;
    }
    return (0, r.default)(i, [ {
        key: "decode",
        value: function(e, t, r) {
            this.t0 = r.readUnsignedInt(), this.t1 = r.readUnsignedInt(), this.reverseReturn = r.readUnsignedByte();
        }
    } ]), i;
}(a);