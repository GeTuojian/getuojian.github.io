var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), n = e(require("../../../../@babel/runtime/helpers/createClass")), r = e(require("../../../../@babel/runtime/helpers/get")), i = e(require("../../../../@babel/runtime/helpers/inherits")), u = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function s(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var n, r = (0, l.default)(e);
        if (t) {
            var i = (0, l.default)(this).constructor;
            n = Reflect.construct(r, arguments, i);
        } else n = r.apply(this, arguments);
        return (0, u.default)(this, n);
    };
}

var o = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, i.default)(o, e);
    var u = s(o);
    function o(e) {
        var n;
        return (0, t.default)(this, o), (n = u.call(this, e))._className = "ConditionAnd", 
        n.condition0 = null, n.condition1 = null, n;
    }
    return (0, n.default)(o, [ {
        key: "decode",
        value: function(e, t, n) {
            this.condition0 = e.getClassInstance(t, n.readUnsignedInt()), this.condition1 = e.getClassInstance(t, n.readUnsignedInt());
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.condition0 = null, this.condition1 = null, (0, r.default)((0, l.default)(o.prototype), "dispose", this).call(this);
        }
    } ]), o;
}(o);