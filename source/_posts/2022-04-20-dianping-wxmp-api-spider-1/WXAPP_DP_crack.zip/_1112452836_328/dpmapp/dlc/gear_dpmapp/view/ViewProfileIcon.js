var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../@babel/runtime/helpers/get")), l = e(require("../../../../@babel/runtime/helpers/inherits")), i = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), u = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function s(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, n = (0, u.default)(e);
        if (t) {
            var l = (0, u.default)(this).constructor;
            r = Reflect.construct(n, arguments, l);
        } else r = n.apply(this, arguments);
        return (0, i.default)(this, r);
    };
}

var o = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, l.default)(o, e);
    var i = s(o);
    function o(e) {
        var r;
        return (0, t.default)(this, o), (r = i.call(this, e))._className = "ViewProfileIcon", 
        r.imageUrl = null, r.label = null, r.commonConfig = null, r;
    }
    return (0, r.default)(o, [ {
        key: "decode",
        value: function(e, t, r) {
            this.imageUrl = t.getString(r.readUnsignedByteOrShort()), this.label = t.getString(r.readUnsignedByteOrShort()), 
            this.commonConfig = e.getClassInstance(t, r.readUnsignedInt());
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.imageUrl = null, this.label = null, this.commonConfig && (e.disposeInstance(t, this.commonConfig.instanceUID), 
            this.commonConfig = null), (0, n.default)((0, u.default)(o.prototype), "dispose", this).call(this);
        }
    } ]), o;
}(o);