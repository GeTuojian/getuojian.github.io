var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../@babel/runtime/helpers/createClass")), u = e(require("../../../../@babel/runtime/helpers/get")), l = e(require("../../../../@babel/runtime/helpers/inherits")), a = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), n = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function s(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, u = (0, n.default)(e);
        if (t) {
            var l = (0, n.default)(this).constructor;
            r = Reflect.construct(u, arguments, l);
        } else r = u.apply(this, arguments);
        return (0, a.default)(this, r);
    };
}

var i = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, l.default)(i, e);
    var a = s(i);
    function i(e) {
        var r;
        return (0, t.default)(this, i), (r = a.call(this, e))._className = "VariableReqParam", 
        r.searchKey = null, r.hasDefaultValue = 0, r.defaultValue = null, r;
    }
    return (0, r.default)(i, [ {
        key: "decode",
        value: function(e, t, r) {
            this.searchKey = t.getString(r.readUnsignedByteOrShort()), this.hasDefaultValue = r.readUnsignedByte(), 
            this.defaultValue = t.getString(r.readUnsignedByteOrShort());
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.searchKey = null, this.defaultValue = null, (0, u.default)((0, n.default)(i.prototype), "dispose", this).call(this);
        }
    } ]), i;
}(i);