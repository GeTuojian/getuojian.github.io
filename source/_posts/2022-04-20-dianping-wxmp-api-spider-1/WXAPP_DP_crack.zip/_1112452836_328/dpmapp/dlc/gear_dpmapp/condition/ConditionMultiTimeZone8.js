var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), n = e(require("../../../../@babel/runtime/helpers/createClass")), r = e(require("../../../../@babel/runtime/helpers/inherits")), i = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), s = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function a(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var n, r = (0, s.default)(e);
        if (t) {
            var a = (0, s.default)(this).constructor;
            n = Reflect.construct(r, arguments, a);
        } else n = r.apply(this, arguments);
        return (0, i.default)(this, n);
    };
}

var u = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, r.default)(s, e);
    var i = a(s);
    function s(e) {
        var n;
        return (0, t.default)(this, s), (n = i.call(this, e))._className = "ConditionMultiTimeZone8", 
        n.t0 = 0, n.t1 = 0, n.t2 = 0, n.t3 = 0, n.t4 = 0, n.t5 = 0, n.t6 = 0, n.t7 = 0, 
        n.t8 = 0, n.t9 = 0, n.t10 = 0, n.t11 = 0, n.t12 = 0, n.t13 = 0, n.t14 = 0, n.t15 = 0, 
        n.reverseReturn = 0, n;
    }
    return (0, n.default)(s, [ {
        key: "decode",
        value: function(e, t, n) {
            this.t0 = n.readUnsignedInt(), this.t1 = n.readUnsignedInt(), this.t2 = n.readUnsignedInt(), 
            this.t3 = n.readUnsignedInt(), this.t4 = n.readUnsignedInt(), this.t5 = n.readUnsignedInt(), 
            this.t6 = n.readUnsignedInt(), this.t7 = n.readUnsignedInt(), this.t8 = n.readUnsignedInt(), 
            this.t9 = n.readUnsignedInt(), this.t10 = n.readUnsignedInt(), this.t11 = n.readUnsignedInt(), 
            this.t12 = n.readUnsignedInt(), this.t13 = n.readUnsignedInt(), this.t14 = n.readUnsignedInt(), 
            this.t15 = n.readUnsignedInt(), this.reverseReturn = n.readUnsignedByte();
        }
    } ]), s;
}(u);