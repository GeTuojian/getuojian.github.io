var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../@babel/runtime/helpers/get")), i = e(require("../../../../@babel/runtime/helpers/inherits")), s = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), l = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function a(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, n = (0, l.default)(e);
        if (t) {
            var i = (0, l.default)(this).constructor;
            r = Reflect.construct(n, arguments, i);
        } else r = n.apply(this, arguments);
        return (0, s.default)(this, r);
    };
}

var u = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, i.default)(u, e);
    var s = a(u);
    function u(e) {
        var r;
        return (0, t.default)(this, u), (r = s.call(this, e))._className = "ViewSideIcon", 
        r.imageUrl = null, r.imageWidth = 0, r.imageHeight = 0, r.pageList = null, r.commonConfig = null, 
        r;
    }
    return (0, r.default)(u, [ {
        key: "decode",
        value: function(e, t, r) {
            this.imageUrl = t.getString(r.readUnsignedByteOrShort()), this.imageWidth = r.readByteOrShortOrInt(), 
            this.imageHeight = r.readByteOrShortOrInt(), this.pageList = t.getString(r.readUnsignedByteOrShort()), 
            this.commonConfig = e.getClassInstance(t, r.readUnsignedInt());
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.imageUrl = null, this.pageList = null, this.commonConfig && (e.disposeInstance(t, this.commonConfig.instanceUID), 
            this.commonConfig = null), (0, n.default)((0, l.default)(u.prototype), "dispose", this).call(this);
        }
    } ]), u;
}(u);