var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../@babel/runtime/helpers/get")), l = e(require("../../../../@babel/runtime/helpers/inherits")), i = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), u = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function a(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, n = (0, u.default)(e);
        if (t) {
            var l = (0, u.default)(this).constructor;
            r = Reflect.construct(n, arguments, l);
        } else r = n.apply(this, arguments);
        return (0, i.default)(this, r);
    };
}

var s = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, l.default)(s, e);
    var i = a(s);
    function s(e) {
        var r;
        return (0, t.default)(this, s), (r = i.call(this, e))._className = "ActionShowHideDLCElement", 
        r.elementGlobalId = null, r.pageQuery = null, r.isOpen = 0, r.mask = 0, r.animeType = 0, 
        r;
    }
    return (0, r.default)(s, [ {
        key: "decode",
        value: function(e, t, r) {
            this.elementGlobalId = t.getString(r.readUnsignedByteOrShort()), this.pageQuery = t.getString(r.readUnsignedByteOrShort()), 
            this.isOpen = r.readUnsignedByte(), this.mask = r.readUnsignedByte(), this.animeType = r.readUnsignedByte();
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.elementGlobalId = null, this.pageQuery = null, (0, n.default)((0, u.default)(s.prototype), "dispose", this).call(this);
        }
    } ]), s;
}(s);