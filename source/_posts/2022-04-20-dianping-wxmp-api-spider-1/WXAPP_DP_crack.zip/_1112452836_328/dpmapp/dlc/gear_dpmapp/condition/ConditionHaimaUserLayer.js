var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), r = e(require("../../../../@babel/runtime/helpers/classCallCheck")), t = e(require("../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../@babel/runtime/helpers/inherits")), u = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), a = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function i(e) {
    var r = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var t, n = (0, a.default)(e);
        if (r) {
            var i = (0, a.default)(this).constructor;
            t = Reflect.construct(n, arguments, i);
        } else t = n.apply(this, arguments);
        return (0, u.default)(this, t);
    };
}

var s = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, n.default)(a, e);
    var u = i(a);
    function a(e) {
        var t;
        return (0, r.default)(this, a), (t = u.call(this, e))._className = "ConditionHaimaUserLayer", 
        t.contentId = 0, t.reverseReturn = 0, t;
    }
    return (0, t.default)(a, [ {
        key: "decode",
        value: function(e, r, t) {
            this.contentId = t.readUnsignedInt(), this.reverseReturn = t.readUnsignedByte();
        }
    } ]), a;
}(s);