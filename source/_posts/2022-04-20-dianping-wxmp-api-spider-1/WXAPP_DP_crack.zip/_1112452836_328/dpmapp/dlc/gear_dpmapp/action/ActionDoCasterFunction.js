var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../@babel/runtime/helpers/createClass")), l = e(require("../../../../@babel/runtime/helpers/get")), n = e(require("../../../../@babel/runtime/helpers/inherits")), u = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), a = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function i(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, l = (0, a.default)(e);
        if (t) {
            var n = (0, a.default)(this).constructor;
            r = Reflect.construct(l, arguments, n);
        } else r = l.apply(this, arguments);
        return (0, u.default)(this, r);
    };
}

var s = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, n.default)(s, e);
    var u = i(s);
    function s(e) {
        var r;
        return (0, t.default)(this, s), (r = u.call(this, e))._className = "ActionDoCasterFunction", 
        r.elementGlobalId = null, r.ast = null, r;
    }
    return (0, r.default)(s, [ {
        key: "decode",
        value: function(e, t, r) {
            this.elementGlobalId = t.getString(r.readUnsignedByteOrShort()), this.ast = t.getString(r.readUnsignedByteOrShort());
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.elementGlobalId = null, this.ast = null, (0, l.default)((0, a.default)(s.prototype), "dispose", this).call(this);
        }
    } ]), s;
}(s);