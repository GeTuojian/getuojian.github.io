var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), n = e(require("../../../../@babel/runtime/helpers/createClass")), r = e(require("../../../../@babel/runtime/helpers/get")), i = e(require("../../../../@babel/runtime/helpers/inherits")), l = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), o = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function u(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var n, r = (0, o.default)(e);
        if (t) {
            var i = (0, o.default)(this).constructor;
            n = Reflect.construct(r, arguments, i);
        } else n = r.apply(this, arguments);
        return (0, l.default)(this, n);
    };
}

var s = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, i.default)(s, e);
    var l = u(s);
    function s(e) {
        var n;
        return (0, t.default)(this, s), (n = l.call(this, e))._className = "ActionCondition", 
        n.condition = null, n.conditionTrueAction = null, n.conditionFalseAction = null, 
        n;
    }
    return (0, n.default)(s, [ {
        key: "decode",
        value: function(e, t, n) {
            this.condition = e.getClassInstance(t, n.readUnsignedInt()), this.conditionTrueAction = e.getClassInstance(t, n.readUnsignedInt()), 
            this.conditionFalseAction = e.getClassInstance(t, n.readUnsignedInt());
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.condition = null, this.conditionTrueAction = null, this.conditionFalseAction = null, 
            (0, r.default)((0, o.default)(s.prototype), "dispose", this).call(this);
        }
    } ]), s;
}(s);