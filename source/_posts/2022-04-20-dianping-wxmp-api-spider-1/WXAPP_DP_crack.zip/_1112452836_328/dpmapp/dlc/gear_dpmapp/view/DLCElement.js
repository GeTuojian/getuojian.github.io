var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../@babel/runtime/helpers/get")), l = e(require("../../../../@babel/runtime/helpers/inherits")), u = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), i = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function a(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, n = (0, i.default)(e);
        if (t) {
            var l = (0, i.default)(this).constructor;
            r = Reflect.construct(n, arguments, l);
        } else r = n.apply(this, arguments);
        return (0, u.default)(this, r);
    };
}

var s = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, l.default)(s, e);
    var u = a(s);
    function s(e) {
        var r;
        return (0, t.default)(this, s), (r = u.call(this, e))._className = "DLCElement", 
        r.isResident = 0, r.json = null, r.defaultData = null, r.globalId = null, r;
    }
    return (0, r.default)(s, [ {
        key: "decode",
        value: function(e, t, r) {
            this.isResident = r.readUnsignedByte(), this.json = t.getString(r.readUnsignedByteOrShort()), 
            this.defaultData = t.getString(r.readUnsignedByteOrShort()), this.globalId = t.getString(r.readUnsignedByteOrShort());
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.json = null, this.defaultData = null, this.globalId = null, (0, n.default)((0, 
            i.default)(s.prototype), "dispose", this).call(this);
        }
    } ]), s;
}(s);