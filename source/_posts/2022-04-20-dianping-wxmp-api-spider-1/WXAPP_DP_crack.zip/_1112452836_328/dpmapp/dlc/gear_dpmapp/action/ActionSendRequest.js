var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../@babel/runtime/helpers/get")), l = e(require("../../../../@babel/runtime/helpers/inherits")), i = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), s = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function u(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, n = (0, s.default)(e);
        if (t) {
            var l = (0, s.default)(this).constructor;
            r = Reflect.construct(n, arguments, l);
        } else r = n.apply(this, arguments);
        return (0, i.default)(this, r);
    };
}

var a = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, l.default)(a, e);
    var i = u(a);
    function a(e) {
        var r;
        return (0, t.default)(this, a), (r = i.call(this, e))._className = "ActionSendRequest", 
        r.path = null, r.method = 0, r.body = null, r.protocolTextId = null, r.variableId = null, 
        r.succAction = null, r.failAction = null, r;
    }
    return (0, r.default)(a, [ {
        key: "decode",
        value: function(e, t, r) {
            this.path = t.getString(r.readUnsignedByteOrShort()), this.method = r.readUnsignedByte(), 
            this.body = t.getString(r.readUnsignedByteOrShort()), this.protocolTextId = t.getString(r.readUnsignedByteOrShort()), 
            this.variableId = e.getClassInstance(t, r.readUnsignedInt()), this.succAction = e.getClassInstance(t, r.readUnsignedInt()), 
            this.failAction = e.getClassInstance(t, r.readUnsignedInt());
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.path = null, this.body = null, this.protocolTextId = null, this.variableId = null, 
            this.succAction = null, this.failAction = null, (0, n.default)((0, s.default)(a.prototype), "dispose", this).call(this);
        }
    } ]), a;
}(a);