var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../../@babel/runtime/helpers/createClass")), n = e(require("../../../../@babel/runtime/helpers/get")), i = e(require("../../../../@babel/runtime/helpers/inherits")), u = e(require("../../../../@babel/runtime/helpers/possibleConstructorReturn")), s = e(require("../../../../@babel/runtime/helpers/getPrototypeOf"));

function l(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, n = (0, s.default)(e);
        if (t) {
            var i = (0, s.default)(this).constructor;
            r = Reflect.construct(n, arguments, i);
        } else r = n.apply(this, arguments);
        return (0, u.default)(this, r);
    };
}

var a = require("../../gear_common/GearClassInstanceBase.js");

module.exports = function(e) {
    (0, i.default)(a, e);
    var u = l(a);
    function a(e) {
        var r;
        return (0, t.default)(this, a), (r = u.call(this, e))._className = "ActionToast", 
        r.content = null, r.duration = 0, r.modal = 0, r.hideToast = 0, r.endAction = null, 
        r;
    }
    return (0, r.default)(a, [ {
        key: "decode",
        value: function(e, t, r) {
            this.content = t.getString(r.readUnsignedByteOrShort()), this.duration = r.readUnsignedShortOrInt(), 
            this.modal = r.readUnsignedByte(), this.hideToast = r.readUnsignedByte(), this.endAction = e.getClassInstance(t, r.readUnsignedInt());
        }
    }, {
        key: "dispose",
        value: function(e, t) {
            this.content = null, this.endAction = null, (0, n.default)((0, s.default)(a.prototype), "dispose", this).call(this);
        }
    } ]), a;
}(a);