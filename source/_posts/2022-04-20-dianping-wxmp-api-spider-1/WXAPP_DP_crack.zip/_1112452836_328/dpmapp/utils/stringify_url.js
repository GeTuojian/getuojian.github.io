module.exports = function(r, i, n) {
    var o = r;
    if (i) {
        var e = [];
        for (var t in i) i.hasOwnProperty(t) && void 0 !== i[t] && e.push(t + "=" + i[t]);
        o = r ? ~r.indexOf("?") ? r + "&" + e.join("&") : r + "?" + e.join("&") : e.join("&");
    }
    return n && (o += "#" + n), o;
};