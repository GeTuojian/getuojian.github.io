module.exports = {
    queryStringToObject: function(t) {
        var n = {};
        if (!t) return null;
        var r = t.split("&");
        return r.length && r.forEach(function(t) {
            var r = t.split("=");
            n[r[0]] = r[1];
        }), n;
    },
    queryObjectToString: function(t) {
        if (!t) return "";
        var n = Object.keys(t);
        return n.length ? n.map(function(n) {
            return "".concat(n, "=").concat(t[n]);
        }).join("&") : "";
    }
};