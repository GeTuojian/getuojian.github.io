module.exports = function(t, e) {
    if (!t || !e) return !0;
    if (t === e) return !0;
    for (var r = t.split("."), n = e.split("."), l = r.length > n.length ? n.length : r.length, i = 0; i < l; i++) {
        var s = parseInt(r[i]), u = parseInt(n[i]);
        if (s !== u) return s > u;
    }
    return r.length > n.length;
};