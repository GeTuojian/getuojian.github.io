var o, e = arguments;

o = wx;

var n = {}, t = [ "stopRecord", "pauseVoice", "stopVoice", "pauseBackgroundAudio", "stopBackgroundAudio", "showNavigationBarLoading", "hideNavigationBarLoading", "createAnimation", "createContext", "hideKeyboard", "stopPullDownRefresh" ], i = [ "createSignal" ], a = function(a) {
    var r = -1 !== t.indexOf(a) || "on" === a.substr(0, 2) || /\w+Sync$/.test(a);
    if (-1 === i.indexOf(a)) try {
        "function" != typeof o[a] ? n[a] = o[a] : n[a] = r ? function() {
            return o[a].apply(o, e);
        } : function(e) {
            return e = e || {}, new Promise(function(n, t) {
                e.success = n, e.fail = t, o[a](e);
            });
        };
    } catch (o) {}
};

for (var r in o) a(r);

module.exports = n;