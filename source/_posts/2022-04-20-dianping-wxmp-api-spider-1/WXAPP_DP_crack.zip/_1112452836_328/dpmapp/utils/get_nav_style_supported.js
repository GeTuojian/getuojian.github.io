module.exports = function(e) {
    return ("IOS" === e.deviceSystem || "ANDROID" === e.deviceSystem) && parseInt(e.wxAppVersion.split(".")[0]) >= 7 || "MACOS" === e.deviceSystem;
};