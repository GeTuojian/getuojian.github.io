module.exports = function(i) {
    return -1 !== i.indexOf("mapi.dianping.com") || -1 !== i.indexOf("mapi.51ping.com") ? "mapi" : "mina";
};