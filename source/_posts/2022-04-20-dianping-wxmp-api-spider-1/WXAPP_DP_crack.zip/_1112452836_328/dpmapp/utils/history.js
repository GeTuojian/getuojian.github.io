var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/typeof")), r = require("../../framework/utils/storage.js");

module.exports = {
    setHistory: function(t) {
        var s = r.getLocalStorageSync("__KEYWORD_HISTORY__") || [];
        if ("string" == typeof t) {
            var i = s.indexOf(t);
            -1 !== i && s.splice(i, 1), "" !== t && s.unshift(t);
        } else {
            for (var o = -1, l = 0; l < s.length; l++) "object" === (0, e.default)(s[l]) && s[l].shopId == t.shopId && (o = l);
            -1 !== o && s.splice(o, 1), s.unshift(t);
        }
        s.length > 7 && (s = s.splice(0, 7)), r.setLocalStorageSync("__KEYWORD_HISTORY__", s);
    }
};