var t = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/typeof"));

module.exports = function() {
    var n;
    function i(t, i, o) {
        void 0 === o && (o = "log"), void 0 === i && (o = "KEY_STEP"), n && n.notify(35001, {
            content: t || "",
            reason: "KEY_STEP",
            level: o
        });
    }
    return {
        showToast: function(i, o, e, a, l) {
            if ("object" === (0, t.default)(i) && (o = i.duration, e = i.icon, a = i.callback, 
            l = i.mask, i = i.title), i || e) {
                var u = {
                    title: i,
                    duration: void 0 === o ? 1e3 : o
                };
                void 0 !== e && (u.icon = e), "function" == typeof a && (u.callback = a), void 0 !== l && (u.mask = l), 
                n && n.notify(33001, u);
            }
        },
        hideToast: function() {
            n && n.notify(33001, {
                duration: 0
            });
        },
        showAlert: function(i, o, e) {
            if ("object" === (0, t.default)(i) && (o = i.buttons, e = i.template, i = i.title || i.content), 
            i || content) {
                o || (o = [ {
                    label: "确定"
                } ]);
                var a = {
                    title: i,
                    buttons: o
                };
                void 0 !== e && (a.template = e), n && n.notify(33101, a);
            }
        },
        showModal: function(t) {
            wx.showModal(t);
        },
        request: function(t) {
            n && n.notify(30001, {
                identity: identity,
                data: data || null
            });
        },
        logC: function(t, i) {
            n && n.notify(37001, {
                identity: t,
                data: i || null
            });
        },
        logV: function(t, i) {
            n && n.notify(37002, {
                identity: t,
                data: i || null
            });
        },
        logS: i,
        logE: function(t, i) {
            n && n.notify(37003, {
                identity: t,
                data: i || null
            });
        },
        logPV: function(t) {
            if (n) {
                var i = require("../config/lx_id.js").cid[t];
                if (i) {
                    var o = {
                        behaviorType: "pageView",
                        data: {
                            cid: i
                        }
                    };
                    n.notify(36001, o);
                }
            }
        },
        owlInfo: function(t, n) {
            i({
                name: t,
                content: n
            }, "", "info");
        },
        setApp: function(t) {
            return n = t.env, this;
        }
    };
}();