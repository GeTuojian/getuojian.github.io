function e(e, r) {
    var n = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
    if (!n) {
        if (Array.isArray(e) || (n = function(e, r) {
            if (!e) return;
            if ("string" == typeof e) return t(e, r);
            var n = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === n && e.constructor && (n = e.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(e);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return t(e, r);
        }(e)) || r && e && "number" == typeof e.length) {
            n && (e = n);
            var a = 0, o = function() {};
            return {
                s: o,
                n: function() {
                    return a >= e.length ? {
                        done: !0
                    } : {
                        done: !1,
                        value: e[a++]
                    };
                },
                e: function(e) {
                    throw e;
                },
                f: o
            };
        }
        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }
    var i, c = !0, s = !1;
    return {
        s: function() {
            n = n.call(e);
        },
        n: function() {
            var e = n.next();
            return c = e.done, e;
        },
        e: function(e) {
            s = !0, i = e;
        },
        f: function() {
            try {
                c || null == n.return || n.return();
            } finally {
                if (s) throw i;
            }
        }
    };
}

function t(e, t) {
    (null == t || t > e.length) && (t = e.length);
    for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
    return n;
}

var r = require("../../framework/utils/storage.js"), n = require("../../dpmapp/config/app_config.js"), a = require("../../framework/class_define/http_protocol.js"), o = require("../../framework/class_define/http_request_task.js"), i = "/wxmapi/tabbar/config", c = {
    "首页": "pages/index/index",
    "找好店": "pages/ranklist/ranklist",
    "找优惠": "pages/group/group",
    "我的": "pages/my/my"
}, s = n.TAB_BARS;

function u(e, t, r) {
    if (c[e.name] && wx.showTabBarRedDot) {
        var n = e.id, a = e.name, o = c[a], i = s.indexOf(o);
        r[a] && r[a] == n || (o != t ? e.text ? wx.setTabBarBadge({
            index: i,
            text: e.text
        }) : wx.showTabBarRedDot({
            index: i
        }) : (e.text ? wx.removeTabBarBadge({
            index: i
        }) : wx.hideTabBarRedDot({
            index: i
        }), r[a] = n));
    }
}

module.exports = function(t) {
    getApp().h.request(new o(new a("".concat(n.DOMAIN).concat(i)), {
        callback: function(n) {
            if (200 === n.statusCode && 200 === n.data.code && n.data.configList.length > 0) try {
                var a, o = n.data.configList, i = r.getLocalStorageSync("__CACHE@APP:__dp_clicked_tabbars") || {}, c = e(o);
                try {
                    for (c.s(); !(a = c.n()).done; ) {
                        u(a.value, t, i);
                    }
                } catch (e) {
                    c.e(e);
                } finally {
                    c.f();
                }
                Object.keys(i).length && r.setLocalStorageSync("__CACHE@APP:__dp_clicked_tabbars", i);
            } catch (e) {} else 200 !== n.statusCode || n.data.code;
        }
    }));
};