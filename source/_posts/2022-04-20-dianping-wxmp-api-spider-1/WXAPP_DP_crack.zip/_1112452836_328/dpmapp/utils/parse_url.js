module.exports = function(r, e) {
    e && e.shouldDecode && (r = decodeURIComponent(r));
    var s, u, t = r, o = t.lastIndexOf("#");
    -1 !== o && (s = t.substr(o + 1), t = t.substr(0, o));
    var i = t.indexOf("?");
    if (-1 !== i) {
        var n = t.substr(i + 1);
        u = require("./query_util.js").queryStringToObject(n), t = t.substr(0, i);
    }
    return {
        uri: t,
        query: u || {},
        hash: s
    };
};