var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/typeof")), r = require("../../framework/class_define/http_protocol.js"), t = require("../../framework/class_define/http_request_task.js"), a = "/wxmapi/shop/shopmapinfo", s = {};

module.exports = function(o) {
    if (o) {
        var i, u = o.shopId, d = o.shopUuid;
        "object" === (0, e.default)(o) && o.lat && (i = o);
        var l = function(e) {
            wx.openLocation({
                latitude: e.lat,
                longitude: e.lng,
                name: e.shopName,
                address: e.address
            });
        };
        if (i) l(i); else if (d || u) if (s[u] || s[d]) l(s[u] || s[d]); else {
            var n = {};
            d ? n.shopUuid = d : n.shopId = u, o.mtsiReferrer && (n.mtsiReferrer = o.mtsiReferrer), 
            getApp().h.request(new t(new r(a, {
                method: "GET",
                data: n
            }), {
                callback: function(e) {
                    var r = e.serverData || null;
                    if (r && 200 === r.statusCode && r.data && 200 === r.data.code) {
                        var t = r.data.shopInfo;
                        s = {}, d ? s[d] = t : s[u] = t, l(t);
                    }
                }
            }));
        }
    }
};