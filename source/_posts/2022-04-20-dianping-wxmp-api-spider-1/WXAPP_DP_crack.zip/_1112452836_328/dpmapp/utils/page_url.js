module.exports = {
    getCurrentPageUrl: function() {
        var t = getCurrentPages();
        return t && t.length ? t[t.length - 1].route : "";
    },
    getCurrentPageUrlWithArgs: function() {
        var t = getCurrentPages(), e = t[t.length - 1], r = e.route, n = e.options, u = r + "?";
        for (var g in n) {
            u += g + "=" + n[g] + "&";
        }
        return u = u.substring(0, u.length - 1);
    },
    getCurrentPage: function() {
        var t = {};
        if ("function" == typeof getCurrentPages) {
            var e = getCurrentPages();
            t = e[e.length - 1];
        }
        return t;
    },
    getPageRoutes: function() {
        var t = {};
        if ("function" == typeof getCurrentPages) {
            var e = getCurrentPages();
            if (e && e.length) {
                var r = "", n = [];
                e.forEach(function(t, e) {
                    r += e + 1 + ":" + t.route + "; ", n.push(t.route);
                }), t = {
                    text: r,
                    routes: n
                };
            }
        }
        return t;
    }
};