module.exports = {
    APP_VERSION: "9.4.0",
    APP_NAME: "dianping-wxapp",
    OWL_APP_NAME: "dianping-wxapp",
    LX_APP_NAME: "dianping_wxapp",
    PERF_TOKEN: "61baefba1c9d4405e12322e2",
    TAB_BARS: [ "pages/home/home", "pages/group/group", "pages/ranklist/ranklist", "pages/my/my" ],
    DOMAIN: "https://m.dianping.com",
    DOMAIN_A: "https://a.dianping.com",
    STATIC_DOMAIN: "https://www.dpfile.com",
    WS_DOMAIN: "wss://m.dianping.com",
    MAPI_DOMAIN: "https://mapi.dianping.com",
    PAGE_DOMAIN: "https://h5.dianping.com",
    ACCOUNT_DOMIAN: "https://maccount.dianping.com",
    ENV: "production"
}, module.exports.WXMP_APP_ID = "wx734c1ad7b3562129", module.exports.APP_ID = module.exports.CX_APP_ID = module.exports.WXMP_APP_ID, 
module.exports.APP_CHANNEL = "weixin";