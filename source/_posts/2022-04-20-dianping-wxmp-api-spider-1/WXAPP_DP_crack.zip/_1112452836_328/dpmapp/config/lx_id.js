var _ = (0, require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/defineProperty")).default)({
    "home.top_open_app": "b_dianping_nova_jb3j5d2a_mc",
    "home.switch_city": "b_dianping_nova_78mln7xl_mc",
    "home.serarch": "b_dianping_nova_scpx39m3_mc",
    "home.user": "b_dianping_nova_qpxw3i6w_mc",
    "home.jgw": "b_dianping_nova_zabd5582_mc",
    "home.search_container": "b_dianping_nova_scpx39m3_mc",
    "home.feed": "b_dianping_nova_9whvlr9c_mc",
    "home.search_find": "b_dianping_nova_zypoxx4g_mc"
}, "home.search_container", "b_dianping_nova_09rp90s8_mc");

module.exports = {
    cid: {
        home: "c_dianping_nova_1vwde2m4",
        login: "c_dianping_nova_cii5zjp3"
    },
    bid_c: _,
    bid_v: {
        "home.top_open_app": "b_dianping_nova_jb3j5d2a_mv",
        "home.jgw": "b_dianping_nova_zabd5582_mv",
        "home.feed": "b_dianping_nova_9whvlr9c_mv",
        "home.search_container": "b_dianping_nova_ikgkmgys_mv",
        "home.search_find": "b_dianping_nova_zypoxx4g_mv"
    },
    bid_e: {},
    home_s: "home_share1"
};