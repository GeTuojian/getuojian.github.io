require("../../../framework/class_define/component_base.js")({
    properties: {
        card: Object
    },
    created: function() {},
    data: {},
    methods: {}
});