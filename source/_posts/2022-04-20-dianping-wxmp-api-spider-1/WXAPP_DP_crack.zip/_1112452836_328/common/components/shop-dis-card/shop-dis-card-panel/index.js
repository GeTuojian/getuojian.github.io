var t = require("../../../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../../../@babel/runtime/helpers/typeof")), r = t(require("../../../../@babel/runtime/helpers/objectWithoutProperties"));

Component({
    properties: {
        page: {
            type: String,
            value: "poi"
        },
        shopId: {
            type: String,
            value: ""
        },
        shopUuid: {
            type: String,
            value: ""
        },
        header: {
            type: String,
            value: ""
        },
        cardNo: {
            type: String,
            value: ""
        },
        title: {
            type: String,
            value: "",
            observer: "_getTitle"
        },
        subtitle: {
            type: String,
            value: ""
        },
        cardPriceDesc: {
            type: String,
            value: "",
            observer: "_getCardPriceDesc"
        },
        originalCardPrice: {
            type: String,
            value: 28,
            observer: "_originalCardPrice"
        },
        promoDesc: {
            type: String,
            value: ""
        },
        userCardDesc: {
            type: String,
            value: ""
        },
        userHasCard: {
            type: Boolean,
            value: !0
        },
        button: {
            type: String,
            value: "https://p0.meituan.net/dprainbow/5e74de336a3474deda4ada7ffca2dfcd18715.png",
            observer: "_getBtn"
        },
        saleCount: {
            type: String,
            value: "持卡会员1人"
        },
        bigBackgroundPic: {
            type: String,
            value: "https://p0.meituan.net/dprainbow/c4725350925949d4cd181fb44a2b8277247282.png"
        },
        linkUrl: {
            type: String,
            value: ""
        },
        cardExpiredTips: {
            type: String,
            value: "",
            observer: "_getCardExpiredTips"
        },
        cardExpiredTipsUrl: {
            type: String,
            value: ""
        },
        cardBottomTipsDo: {
            type: Object,
            observer: "__getCardExpiredTipList",
            value: {}
        }
    },
    data: {
        titleArr: [],
        cardPriceDescArr: [],
        originalCardPriceArr: [],
        btnArr: [],
        cardExpiredTipsArr: [],
        cardExpiredTipsList: [],
        launchAppUrl: ""
    },
    ready: function() {
        var t = this.data || {}, e = t.title, r = void 0 === e ? "" : e, i = t.cardPriceDesc, a = void 0 === i ? "" : i, s = t.button, n = void 0 === s ? "" : s, p = t.cardExpiredTips, o = void 0 === p ? "" : p, c = t.cardBottomTipsDo;
        this._getTitle(r), this._getCardPriceDesc(a), this._getBtn(n), this._getCardExpiredTips(o), 
        this.__getCardExpiredTipList(c);
    },
    methods: {
        click: function() {
            this.redirectDetail();
        },
        redirectDetail: function() {
            var t = getApp().userData.wxmpEncryptedOpenId, e = decodeURIComponent(this.data.linkUrl) || "", r = getApp().userData.dpAccessToken, i = e.split("index.html") || [];
            e = i[0] + "index.html?dpId=".concat(t, "&token=").concat(r, "&appId=wx734c1ad7b3562129&openId=!&utm_source=dianping-wxapp") + i[1], 
            getApp().navigation.forwardTo({
                url: e,
                type: "h5"
            });
        },
        _getTitle: function(t) {
            var e = this.getJsonArray(t);
            this.setData({
                titleArr: e
            });
        },
        _getCardPriceDesc: function(t) {
            var e = this.getJsonArray(t);
            this.setData({
                cardPriceDescArr: e
            });
        },
        _originalCardPrice: function(t) {
            var e = this.getJsonArray(t);
            this.setData({
                originalCardPriceArr: e
            });
        },
        _getBtn: function(t) {
            var e = this.getJsonArray(t);
            this.setData({
                btnArr: e
            });
        },
        _getCardExpiredTips: function(t) {
            var e = this.getJsonArray(t);
            this.setData({
                cardExpiredTipsArr: e
            });
        },
        __getCardExpiredTipList: function(t) {
            var e = this, i = t || {}, a = i.tipList, s = i.cardTip, n = a && a.length ? a : s ? [ s ] : [], p = [];
            n.forEach(function(t) {
                var i = [];
                if (e.isJsonStr(t)) {
                    var a = JSON.parse(t);
                    if (a && a.length) a.forEach(function(t) {
                        var a = t.text, s = (0, r.default)(t, [ "text" ]);
                        i.push({
                            text: a,
                            styles: e.parseStyle(s)
                        });
                    }); else {
                        var s = a.text, n = (0, r.default)(a, [ "text" ]);
                        i.push({
                            text: s,
                            styles: e.parseStyle(n)
                        });
                    }
                } else i.push({
                    text: jsonStr,
                    styles: {}
                });
                p.push(i);
            }), this.setData({
                cardExpiredTipsList: p
            });
        },
        isJsonStr: function(t) {
            if ("string" == typeof t) try {
                var r = JSON.parse(t);
                return !("object" !== (0, e.default)(r) || !r);
            } catch (t) {
                return !1;
            }
            return !1;
        },
        parseStyle: function(t) {
            var e = Object.keys(t);
            if (!e || !e.length) return null;
            var r = "";
            return e.forEach(function(e) {
                var i = t[e];
                "textsize" === e ? r += "font-size: ".concat(i, "px;") : "textcolor" === e ? r += "color: ".concat(i, ";") : "backgroundcolor" === e || (r += "opacity" === e ? "opacity: ".concat(opacity, ";") : "".concat(e, ": ").concat(i, ";"));
            }), r;
        },
        getJsonArray: function(t) {
            var e = this;
            return function(t) {
                var i = [];
                if (e.isJsonStr(t)) {
                    var a = JSON.parse(t);
                    if (a && a.length) a.forEach(function(t) {
                        var a = t.text, s = (0, r.default)(t, [ "text" ]);
                        i.push({
                            text: a,
                            styles: e.parseStyle(s)
                        });
                    }); else {
                        var s = a.text, n = (0, r.default)(a, [ "text" ]);
                        i.push({
                            text: s,
                            styles: e.parseStyle(n)
                        });
                    }
                } else i.push({
                    text: t,
                    styles: {}
                });
                return i;
            }(t);
        }
    }
});