var t = require("../../../framework/class_define/http_protocol.js"), e = require("../../../framework/class_define/http_request_task.js"), a = require("../../../dpmapp/config/app_config.js"), i = "/merchantcard/timescard/navigation/membercards.json", r = "/api/vc/merchantcard/discountcard/navigation/querycards.json";

Component({
    properties: {
        options: {
            type: Object,
            observer: "init"
        },
        page: {
            type: String,
            value: "poi"
        }
    },
    data: {
        cardInfo: null,
        scene: 1001,
        loaded: !1
    },
    methods: {
        init: function(t) {
            if (t && !this.data.loaded) {
                var e = getApp().getShowOptions, a = ((void 0 === e ? function() {} : e)() || {}).scene, i = void 0 === a ? 1001 : a;
                this.setData({
                    scene: i,
                    loaded: !0
                }), "poi" === this.data.page ? this.initPoi(t) : "spu" === this.data.page && this.initTuanOrSpu(t, this.data.page);
            }
        },
        initPoi: function(r) {
            var n = this, d = require("../../../framework/mtdp_bucket/async_data_provider/cityid_provider.js"), o = getApp().userData.wxmpEncryptedOpenId;
            d.getDataAsync(function(d) {
                if (d) {
                    var s = {
                        platform: 1,
                        clientType: 106,
                        cityId: getApp().userData.dpCityId,
                        clientVersion: a.APP_VERSION,
                        dpId: o,
                        userId: getApp().userData.userid || ""
                    };
                    r.shopId && (s.shopid = r.shopId), r.shopUuid && (s.shopuuid = r.shopUuid), s.token = "!", 
                    getApp().h.request(new e(new t(i, {
                        header: {
                            "content-type": "application/x-www-form-urlencoded"
                        },
                        data: s
                    }), {
                        callback: function(t) {
                            var e = t.serverData || null;
                            if (e && 200 === e.statusCode && e.data) {
                                var a = e.data;
                                200 == a.code && a.msg && a.msg.memberCardList && a.msg.memberCardList[0] && n.setData({
                                    cardInfo: a.msg.memberCardList[0] || null
                                });
                            }
                        }
                    }));
                }
            });
        },
        initTuanOrSpu: function(i, n) {
            var d = this, o = getApp().userData.wxmpEncryptedOpenId, s = {
                platform: 1,
                clientType: 106,
                cityId: i.cityId,
                clientVersion: a.APP_VERSION,
                dpId: o,
                userId: getApp().userData.userid || ""
            };
            "tuan" === n && (s.dealgroupid = i.dealId), i.shopId && (s.shopid = i.shopId), i.shopUuid && (s.shopuuid = i.shopUuid), 
            s.token = "!", getApp().h.request(new e(new t(r, {
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                data: s
            }), {
                callback: function(t) {
                    var e = t.serverData || null;
                    if (e && 200 === e.statusCode && e.data) {
                        var a = e.data;
                        200 == a.code && a.msg && d.setData({
                            cardInfo: a.msg
                        });
                    }
                }
            }));
        },
        formatDate: function(t) {
            var e = new Date(t), a = e.getFullYear(), i = e.getMonth() + 1, r = e.getDate(), n = i < 10 ? "0".concat(i) : i, d = r < 10 ? "0".concat(r) : r;
            return "".concat(a, "-").concat(n, "-").concat(d);
        }
    }
});