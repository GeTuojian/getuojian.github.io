var e, t = require("../../../framework/class_define/component_base.js"), o = require("../../../framework/mtdp_bucket/utils/lx_adaptor.js"), a = require("../../../framework/mtdp_bucket/utils/owl_adaptor.js"), s = require("../../../framework/utils/navigator.js"), n = require("../../../dpmapp/config/app_config.js"), i = require("../../../framework/class_define/http_protocol.js"), r = require("../../../framework/class_define/http_request_task.js"), d = require("../../../framework/mtdp_bucket/async_data_provider/token_provider.js"), c = "/wxmapi/user/userinfo", l = "/wxmapi/user/follow";

t({
    properties: {
        offuserId: {
            type: Number
        },
        description: {
            type: String
        },
        from: {
            type: String,
            value: "notedetail"
        },
        contentId: {
            type: Number
        },
        shopId: {
            type: Number
        }
    },
    data: {
        isShow: 0,
        hasFollowed: 0,
        lxCustomData: {}
    },
    ready: function() {
        var e = this, t = getApp().bridge.getShowOptions(), a = this.data, s = a.offuserId, n = a.shopId, i = a.contentId, r = {
            custom: {
                offuser_id: s
            }
        };
        n && (r.custom.shop_id = n), i && (r.custom.content_id = i), this.setData({
            lxCustomData: r
        }), s && t && t.scene && 1036 === t.scene && this.getUserInfo().then(function(t) {
            if (t && 200 === t.code && t.userInfo) {
                o.moduleView("b_dianping_nova_shareinfo_mv", e.data.lxCustomData || r);
                var a = t.userInfo;
                e.setData({
                    isShow: a && Object.keys(a).length ? 1 : 0,
                    userInfo: a,
                    description: e.data.description || a.description || "我发现了这篇超赞的点评",
                    hasFollowed: a.isFriend ? 1 : 0
                });
            }
        });
    },
    methods: {
        getUserInfo: function() {
            var e = this;
            return new Promise(function(t, o) {
                var a = e.data, s = a.offuserId, d = a.from;
                getApp().h.request(new r(new i("".concat(n.DOMAIN).concat(c), {
                    method: "GET",
                    needAccessToken: !0,
                    header: {
                        token: "!"
                    },
                    data: {
                        offuserId: s,
                        from: d,
                        token: "!"
                    }
                }), {
                    callback: function(e) {
                        var a = e.serverData || null;
                        a && 200 === a.statusCode && a.data && 200 === a.data.code ? t(a.data) : o(a);
                    }
                }));
            });
        },
        followFriends: function(e) {
            var t = this, s = this, c = this.data.offuserId;
            o.moduleClick("b_dianping_nova_shareinfo_follow_mc", this.data.lxCustomData), getApp().h.request(new r(new i("".concat(n.DOMAIN).concat(l), {
                method: "GET",
                needAccessToken: !0,
                data: {
                    offuserId: c,
                    follow: e
                }
            }), {
                callback: function(o) {
                    var n = o.serverData || null;
                    if (n && n.data && 200 === n.statusCode) {
                        var i = n.data;
                        200 === i.code ? 0 === e ? (i.title && getApp().sc.showToast({
                            title: i.title,
                            icon: "none",
                            duration: 2e3
                        }), s.setData({
                            hasFollowed: 1
                        })) : (i.title && getApp().sc.showToast({
                            title: i.title,
                            icon: "none",
                            duration: 2e3
                        }), s.setData({
                            hasFollowed: 0
                        })) : 201 === i.code ? i.title && getApp().sc.showToast({
                            title: i.title,
                            icon: "none",
                            duration: 2e3
                        }) : 222 === i.code ? (i.title && getApp().sc.showToast({
                            title: i.title,
                            icon: "none",
                            duration: 2e3
                        }), s.setData({
                            hasFollowed: 1
                        })) : 223 === i.code ? (i.title && getApp().sc.showToast({
                            title: i.title,
                            icon: "none",
                            duration: 2e3
                        }), t.setData({
                            hasFollowed: 0
                        })) : 200 !== i.loginCode && (getApp().userData.dpAccessToken = null, d.getDataAsync(function() {
                            t.followFriends(e);
                        }));
                    } else getApp().sc.showToast({
                        title: "网络错误, 请刷新再试",
                        icon: "none"
                    }), a.addError("关注/取消关注用户失败", o);
                }
            }));
        },
        triggerFollow: function() {
            var t = this, o = this.data.hasFollowed;
            clearTimeout(e), o ? getApp().sc.showModal({
                content: "确定不再关注TA吗？",
                success: function(a) {
                    a.confirm ? e = setTimeout(function() {
                        t.followFriends(o);
                    }, 100) : a.cancel;
                }
            }) : e = setTimeout(function() {
                t.followFriends(o);
            }, 100);
        },
        closeShare: function() {
            o.moduleClick("b_dianping_nova_shareinfo_dislike_mc", this.data.lxCustomData), this.setData({
                isShow: 0
            });
        },
        seeItspage: function() {
            var e = this.data.offuserId;
            e ? (s.forwardTo({
                url: "/packages/user/pages/personal/personal?offuserId=".concat(e)
            }), o.moduleClick("b_dianping_nova_shareinfo_mc", this.data.lxCustomData)) : getApp().sc.showToast({
                title: "获取id错误",
                icon: "none"
            });
        }
    }
});