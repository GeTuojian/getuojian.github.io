var e, t = require("../../../framework/mtdp_bucket/utils/lx_adaptor.js"), o = require("../../../framework/utils/storage.js"), i = "b_dianping_nova_8bgigzjh_mv", n = "b_dianping_nova_v61oul2j_mc";

Component({
    properties: {
        remainingText: {
            type: String,
            value: ""
        },
        isIndex: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        showPopUp: !1,
        top: "3px",
        right: "54px",
        sceneIsWallet: !1
    },
    ready: function() {
        var n = getApp(), a = n.bridge.getShowOptions() && n.bridge.getShowOptions().scene ? parseInt(n.bridge.getShowOptions().scene) : null, s = !1, p = Date.now();
        if (1001 !== a) {
            var r = o.getLocalStorageSync("dp_show_pop_up");
            if (r) {
                var u = r.lastModifyTime, l = r.deltaTime;
                p - u > 60 * l * 1e3 && (s = !0);
            } else s = !0;
            if (s) {
                var d = n.runtimeInfo || new (require("../../../framework/class_define/runtime_info.js"))(), g = d.statusBarHeight, c = d.deviceSystem.indexOf("iOS") > -1 ? 40 : 44, h = 85;
                wx.getMenuButtonBoundingClientRect && wx.getMenuButtonBoundingClientRect() && (c = 2 * (wx.getMenuButtonBoundingClientRect().top - g) + wx.getMenuButtonBoundingClientRect().height, 
                h = wx.getMenuButtonBoundingClientRect().width), this.data.isIndex && this.setData({
                    top: "".concat(g + c + 8, "px"),
                    right: "".concat(.7 * (h - 9), "px")
                }), t.moduleView(i);
                var w = this;
                e = setTimeout(function() {
                    o.setLocalStorageAsync("dp_show_pop_up", {
                        lastModifyTime: p,
                        deltaTime: 30
                    }), w.setData({
                        showPopUp: !1
                    });
                }, 5e3);
            }
        }
        this.setData({
            showPopUp: s,
            sceneIsWallet: 1019 === a
        });
    },
    methods: {
        closePopUp: function() {
            var i = Date.now();
            o.setLocalStorageAsync("dp_show_pop_up", {
                lastModifyTime: i,
                deltaTime: 720
            }), e && clearTimeout(e), t.moduleClick(n), this.setData({
                showPopUp: !1
            });
        }
    }
});