var t = require("../../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../../@babel/runtime/helpers/typeof")), i = t(require("../../../@babel/runtime/helpers/slicedToArray"));

function r(t, e) {
    var i = "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
    if (!i) {
        if (Array.isArray(t) || (i = function(t, e) {
            if (!t) return;
            if ("string" == typeof t) return n(t, e);
            var i = Object.prototype.toString.call(t).slice(8, -1);
            "Object" === i && t.constructor && (i = t.constructor.name);
            if ("Map" === i || "Set" === i) return Array.from(t);
            if ("Arguments" === i || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i)) return n(t, e);
        }(t)) || e && t && "number" == typeof t.length) {
            i && (t = i);
            var r = 0, a = function() {};
            return {
                s: a,
                n: function() {
                    return r >= t.length ? {
                        done: !0
                    } : {
                        done: !1,
                        value: t[r++]
                    };
                },
                e: function(t) {
                    throw t;
                },
                f: a
            };
        }
        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }
    var o, l = !0, s = !1;
    return {
        s: function() {
            i = i.call(t);
        },
        n: function() {
            var t = i.next();
            return l = t.done, t;
        },
        e: function(t) {
            s = !0, o = t;
        },
        f: function() {
            try {
                l || null == i.return || i.return();
            } finally {
                if (s) throw o;
            }
        }
    };
}

function n(t, e) {
    (null == e || e > t.length) && (e = t.length);
    for (var i = 0, r = new Array(e); i < e; i++) r[i] = t[i];
    return r;
}

var a = [], o = [], l = 0, s = 0, c = 0, f = 0, u = 0, h = 0, p = !1;

Component({
    properties: {
        styleConfig: {
            type: Object,
            value: {}
        },
        data: {
            type: Array,
            value: [],
            observer: "computeInitData"
        },
        loadHeight: {
            type: Number,
            value: 300
        },
        refresh: {
            type: Boolean,
            value: !1
        },
        loadMore: {
            type: Boolean,
            value: !0
        },
        isEnd: {
            type: Boolean,
            value: !1
        },
        pageError: {
            type: Boolean,
            value: !1
        }
    },
    attached: function() {},
    data: {
        leftList: [],
        rightList: []
    },
    methods: {
        computeInitData: function(t) {
            if (t && t.length) {
                var e = this.data, i = e.refresh, r = e.paddingStyle;
                if (h && r || this.getStyleInfo(), !this.listQuery) {
                    var n = this.createSelectorQuery();
                    n.select("#left-list").boundingClientRect(), n.select("#right-list").boundingClientRect(), 
                    this.listQuery = n;
                }
                i && (a = [], o = [], l = 0, s = 0), this.addFeedItem(t.shift()), this.list = t;
            }
        },
        addFeedItem: function(t) {
            var e = [], i = [], r = a.length, n = o.length;
            t.originalWidth = parseFloat(t.picWidth), t.originalHeight = parseFloat(t.picHeight), 
            t.picWidth = h;
            var c = t.originalWidth / t.picWidth;
            t.picHeight = c ? t.originalHeight / c : 0, l <= s ? (t.column = "leftList", a.push(t), 
            e.push(t)) : (t.column = "rightList", o.push(t), i.push(t)), this.setListData(e, r, i, n);
        },
        setListData: function(t, e, n, a) {
            var o = this, c = {};
            if (e) {
                var f, u = r(t.entries());
                try {
                    for (u.s(); !(f = u.n()).done; ) {
                        var h = (0, i.default)(f.value, 2), d = h[0], g = h[1];
                        c["leftList[".concat(e + d, "]")] = g;
                    }
                } catch (t) {
                    u.e(t);
                } finally {
                    u.f();
                }
            } else c.leftList = t;
            if (a) {
                var y, v = r(n.entries());
                try {
                    for (v.s(); !(y = v.n()).done; ) {
                        var m = (0, i.default)(y.value, 2), b = m[0], x = m[1];
                        c["rightList[".concat(a + b, "]")] = x;
                    }
                } catch (t) {
                    v.e(t);
                } finally {
                    v.f();
                }
            } else c.rightList = n;
            this.setData(c, function() {
                o.listQuery.exec(function(t) {
                    l = t[0].height, s = t[1].height, o.list.length ? (o.addFeedItem(o.list.shift()), 
                    p = !1) : (o.shorterList = l > s ? "right-list" : "left-list", p = !0);
                });
            });
        },
        getStyleInfo: function() {
            var t = getApp().runtimeInfo || new (require("../../../framework/class_define/runtime_info.js"))();
            f = t.windowWidth, u = t.windowHeight, c = 750 / f;
            var i = this.data.styleConfig || {}, r = i.padding, n = i.itemGap, a = 0, o = 0, l = "", s = "";
            if (r && "object" === (0, e.default)(r)) {
                for (var p in r) r[p] = r[p] / c;
                a = r.left + r.right, l = "".concat(r.top, "px ").concat(r.right, "px ").concat(r.bottom, "px ").concat(r.left, "px");
            } else r && "number" == typeof r ? (a = 2 * (r /= c), l = "".concat(r, "px")) : (r = 0, 
            l = "0px");
            if (n && "object" === (0, e.default)(n)) {
                for (var d in n) n[d] = n[d] / c;
                o = 2 * (n.left + n.right), s = "".concat(n.top, "px ").concat(n.right, "px ").concat(n.bottom, "px ").concat(n.left, "px");
            } else n && "number" == typeof n ? (o = 4 * (n /= c), s = "".concat(n, "px")) : (n = 0, 
            s = "0px");
            h = (f - a - o) / 2, this.setData({
                paddingStyle: l,
                itemGapStyle: s
            });
        },
        getScrollOffset: function() {
            var t = this;
            if (p && this.data.loadMore && this.data.leftList.length && !this.data.isEnd) {
                p = !1;
                try {
                    if (!this.scrollQuery) {
                        var e = this.createSelectorQuery();
                        e.select("#".concat(this.shorterList)).boundingClientRect(), this.scrollQuery = e;
                    }
                    this.scrollQuery.exec(function(e) {
                        e[0].bottom - u <= t.data.loadHeight ? t.triggerEvent("nextpage") : p = !0;
                    });
                } catch (t) {}
            }
        },
        pageErrTap: function() {
            p = !1, this.triggerEvent("nextpage");
        },
        refreshItem: function(t, e) {
            if (t && e) {
                var i = {};
                i[t] = e, this.setData(i);
            }
        }
    }
});