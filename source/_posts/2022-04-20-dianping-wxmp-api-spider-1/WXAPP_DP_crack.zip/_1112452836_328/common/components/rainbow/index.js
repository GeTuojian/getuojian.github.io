var t = require("../../../framework/mtdp_bucket/utils/lx_adaptor.js"), a = "b_et2lvx3l", e = "b_4687gd6y", r = "/wxmapi/shop/rainbow";

Component({
    behaviors: [],
    properties: {
        loadOptions: {
            type: Object,
            vaule: null
        },
        rainBowData: {
            type: Object,
            vaule: null,
            observer: "_rainBowDataChange"
        }
    },
    ready: function() {
        var t = this;
        this.data.rainBowData ? this._dealRainBowData(this.data.rainBowData) : this.data.loadOptions && this.fetchData(this.data.loadOptions || {}).then(function(a) {
            a && t._dealRainBowData(a);
        });
    },
    methods: {
        _rainBowDataChange: function(t) {
            this._dealRainBowData(t);
        },
        fetchData: function(t) {
            var a = this, e = require("../../../framework/mtdp_bucket/async_data_provider/cityid_provider.js"), r = {};
            if (r = this._dealParams(t)) return new Promise(function(t) {
                e.getDataAsync(function(e) {
                    e && (r.cityId = getApp().userData.dpCityId, a.getRainBowData(r).then(function(a) {
                        t(a);
                    }).catch(function(a) {
                        t();
                    }));
                });
            });
        },
        getRainBowData: function(t) {
            var a = require("../../../framework/class_define/http_protocol.js"), e = require("../../../framework/class_define/http_request_task.js");
            return new Promise(function(o, n) {
                getApp().h.request(new e(new a(r, {
                    header: {
                        openidPlt: ""
                    },
                    data: t
                }), {
                    callback: function(t) {
                        var a = t.serverData || null;
                        a && 200 === a.statusCode && a.data && a.data.rainBowData ? o(a.data.rainBowData) : n(t);
                    }
                }));
            });
        },
        _dealParams: function(t) {
            var a = {}, e = t.shopId, r = t.shopUuid;
            if (t.dealGroupId) a.dealGroupId = t.dealGroupId; else if (r) a.shopUuid = r; else {
                if (!a.shopId) return null;
                a.shopId = e;
            }
            return a;
        },
        _dealRainBowData: function(e) {
            if (e.showModule = !1, e.endTime && e.urls && e.urls.length > 0) {
                var r = (Date.parse(new Date(e.endTime)) - Date.parse(new Date())) / 1e3;
                if (r > 0) {
                    e.showModule = !0, this.initSeconds(r, e), t.moduleView(a);
                    var o = setInterval(function() {
                        var t = r;
                        this.updateSeconds(t), --r <= 0 && (clearInterval(o), e.showModule = !1, this.setData({
                            rainBowData: e
                        }));
                    }.bind(this), 1e3);
                }
            }
        },
        initSeconds: function(t, a) {
            var e = this._dealSecond(t), r = e.dayStr, o = e.hrStr, n = e.minStr, i = e.secStr;
            t > 86400 ? this.setData({
                rainBowData: a,
                dayStr: r,
                hrStr: o,
                dayModel: !0,
                hourModel: !1,
                minModel: !1
            }) : t > 3600 ? this.setData({
                rainBowData: a,
                hrStr: o,
                minStr: n,
                dayModel: !1,
                hourModel: !0,
                minModel: !1
            }) : this.setData({
                rainBowData: a,
                minStr: n,
                secStr: i,
                dayModel: !1,
                hourModel: !1,
                minModel: !0
            });
        },
        updateSeconds: function(t) {
            var a = this._dealSecond(t), e = a.dayStr, r = a.hrStr, o = a.minStr, n = a.secStr;
            t >= 86400 ? t % 3600 == 0 && this.setData({
                dayStr: e,
                hrStr: r,
                dayModel: !0,
                hourModel: !1,
                minModel: !1
            }) : t >= 3600 && t < 86400 ? (t + 1) % 60 == 0 && this.setData({
                hrStr: r,
                minStr: o,
                dayModel: !1,
                hourModel: !0,
                minModel: !1
            }) : this.setData({
                minStr: o,
                secStr: n,
                dayModel: !1,
                hourModel: !1,
                minModel: !0
            });
        },
        _dealSecond: function(t) {
            var a = Math.floor(t / 3600 / 24), e = a.toString();
            1 == e.length && (e = "0" + e);
            var r = Math.floor((t - 3600 * a * 24) / 3600), o = r.toString();
            1 == o.length && (o = "0" + o);
            var n = Math.floor((t - 3600 * a * 24 - 3600 * r) / 60), i = n.toString();
            1 == i.length && (i = "0" + i);
            var d = (t - 3600 * a * 24 - 3600 * r - 60 * n).toString();
            return 1 == d.length && (d = "0" + d), {
                dayStr: e,
                hrStr: o,
                minStr: i,
                secStr: d
            };
        },
        rainBowTap: function() {
            t.moduleClick(e);
        }
    }
});