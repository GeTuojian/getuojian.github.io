var a = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/helpers/defineProperty"));

function e(a, e) {
    var t = Object.keys(a);
    if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(a);
        e && (n = n.filter(function(e) {
            return Object.getOwnPropertyDescriptor(a, e).enumerable;
        })), t.push.apply(t, n);
    }
    return t;
}

function t(t) {
    for (var n = 1; n < arguments.length; n++) {
        var i = null != arguments[n] ? arguments[n] : {};
        n % 2 ? e(Object(i), !0).forEach(function(e) {
            (0, a.default)(t, e, i[e]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(i)) : e(Object(i)).forEach(function(a) {
            Object.defineProperty(t, a, Object.getOwnPropertyDescriptor(i, a));
        });
    }
    return t;
}

var n = require("./lib/draw.js"), i = n.drawText, o = n.drawImage, s = n.drawMixImage, r = n.drawMixText;

Component({
    properties: {
        config: {
            type: Object,
            observer: "observerCanvas"
        },
        savetoalbum: {
            type: Boolean,
            value: !1,
            observer: function(a) {
                a && this.saveToAlbum();
            }
        }
    },
    data: {
        imagePath: "",
        picPath: "",
        isDrawing: !1
    },
    detached: function() {
        this.canvasNode = null, this.drawPromise = [], this.downLoadImageList = [];
    },
    methods: {
        observerCanvas: function(a) {
            var e = this;
            if (a && a.configs && a.configs.length) {
                this.newCanvas = a.newCanvas;
                var t = a.canvasId || "myCanvas";
                if (this.newCanvas) {
                    this.data.isDrawing = !0, this.createSelectorQuery().select("#".concat(t)).fields({
                        node: !0,
                        size: !0
                    }).exec(function(t) {
                        if (e.canvasNode = t && t[0] && t[0].node, e.canvasNode) {
                            var n = e.canvasNode.getContext("2d"), i = wx.getSystemInfoSync().pixelRatio;
                            e.canvasNode.width = e.data.config.width * i, e.canvasNode.height = e.data.config.height * i, 
                            n.scale(i, i), e.draw(n).then(function() {
                                a.needSave ? e.save() : e.saveToLocal();
                            }).catch(function(a) {
                                e.data.isDrawing = !1;
                            });
                        }
                    });
                } else {
                    var n = wx.createCanvasContext(t, this);
                    this.draw(n).then(function() {
                        a.needSave ? e.save() : e.saveToLocal();
                    }).catch(function(a) {
                        e.data.isDrawing = !1;
                    });
                }
            }
        },
        draw: function(a) {
            var e = this, n = this, c = this.data.config && this.data.config.configs;
            return n.drawPromise = [], n.newCanvas ? new Promise(function(t, d) {
                var h, f;
                a.clearRect(0, 0, e.data.config.width, e.data.config.height), c.forEach(function(e) {
                    "image" === e.drawType ? n.drawPromise.push(o.bind(n, a, e, "2d", n.canvasNode)) : "text" === e.drawType ? n.drawPromise.push(i.bind(n, a, e, "2d")) : "mix" === e.drawType && (e.imageConfig && e.imageConfig.url ? n.drawPromise.push(s.bind(n, a, e, "2d", n.canvasNode)) : n.drawPromise.push(r.bind(n, a, e, "2d")));
                }), (h = n.drawPromise, f = Promise.resolve(), h.forEach(function(a) {
                    f = f.then(function() {
                        return a();
                    });
                }), f).then(function() {
                    t();
                }).catch(function(a) {
                    d(a);
                });
            }) : (n.downLoadImageList = [], n.init(c), Promise.all(this.downLoadImageList).then(function(n) {
                var d = 0;
                return a.clearRect(0, 0, e.data.config.width, e.data.config.height), c.forEach(function(e) {
                    "image" === e.drawType ? e.hasUrl ? (o(a, t(t({}, e), {}, {
                        url: n[d]
                    }), "", ""), d++) : o(a, e, "", "") : "text" === e.drawType ? i(a, e, "", "") : "mix" === e.drawType && (e.hasUrl ? (s(a, t(t({}, e), {}, {
                        imageConfig: t(t({}, e.imageConfig), {}, {
                            url: n[d]
                        })
                    }), "", ""), d++) : r(a, e, "", ""));
                }), new Promise(function(e) {
                    a.draw(!0, function() {
                        e();
                    });
                });
            }));
        },
        init: function(a) {
            var e = this;
            this.downLoadImageList = [];
            try {
                a.forEach(function(a) {
                    var t;
                    "image" === a.drawType ? (t = a.url) && (0 === t.indexOf("https://") ? e.downLoadImageList.push(e._downLoadFile(t)) : e.downLoadImageList.push(t), 
                    a.hasUrl = !0) : "mix" === a.drawType && (t = a.imageConfig && a.imageConfig.url) && (0 === t.indexOf("https://") ? e.downLoadImageList.push(e._downLoadFile(t)) : e.downLoadImageList.push(t), 
                    a.hasUrl = !0);
                });
            } catch (a) {
                Logan.log("mina-canvas init error: ".concat(JSON.stringify(a)));
            }
        },
        save: function() {
            var a = this, e = this.data.config.canvasId || "myCanvas";
            wx.canvasToTempFilePath({
                canvas: this.canvasNode,
                canvasId: e,
                x: 0,
                y: 0,
                success: function(e) {
                    a.triggerEvent("savecanvas", {
                        url: e.tempFilePath
                    }, {
                        bubbles: !0
                    }), a.data.isDrawing = !1, a.setData({
                        imagePath: e.tempFilePath
                    });
                },
                fail: function(e) {
                    a.data.isDrawing = !1, a.setData({
                        imagePath: ""
                    }), Logan.log("mina-canvas save error: ".concat(JSON.stringify(e)));
                }
            }, this);
        },
        saveToLocal: function() {
            var a = this, e = this.data.config.canvasId || "myCanvas";
            wx.canvasToTempFilePath({
                canvas: this.canvasNode,
                canvasId: e,
                x: 0,
                y: 0,
                success: function(e) {
                    a.data.isDrawing = !1, a.setData({
                        picPath: e.tempFilePath
                    });
                },
                fail: function(e) {
                    a.data.isDrawing = !1, a.setData({
                        picPath: ""
                    }), Logan.log("mina-canvas save error: ".concat(JSON.stringify(e)));
                }
            }, this);
        },
        saveToAlbum: function() {
            var a = this;
            a.data.isDrawing ? wx.showToast({
                title: "图片正在生成中, 请稍后再试",
                icon: "none"
            }) : a.data.picPath ? wx.saveImageToPhotosAlbum({
                filePath: a.data.picPath,
                success: function() {
                    a.triggerEvent("savesuccess");
                },
                fail: function(a) {
                    Logan.log("mina-canvas save album error: ".concat(JSON.stringify(a))), wx.showToast({
                        title: "保存失败",
                        icon: "none"
                    });
                }
            }) : wx.showToast({
                title: "保存失败, 请返回刷新再试",
                icon: "none"
            }), a.setData({
                savetoalbum: !1
            });
        },
        getCanvasNode: function() {
            var a = this, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.data.config.canvasId;
            return new Promise(function(t, n) {
                if (e) try {
                    a.createSelectorQuery().select("#".concat(e)).fields({
                        node: !0,
                        size: !0
                    }).exec(function(a) {
                        t(a[0].node);
                    });
                } catch (a) {
                    n();
                } else n();
            });
        },
        _downLoadFile: function(a) {
            return new Promise(function(e, t) {
                wx.downloadFile({
                    url: a,
                    success: function(a) {
                        e(a.tempFilePath);
                    },
                    fail: function(a) {
                        t(a);
                    }
                });
            });
        }
    }
});