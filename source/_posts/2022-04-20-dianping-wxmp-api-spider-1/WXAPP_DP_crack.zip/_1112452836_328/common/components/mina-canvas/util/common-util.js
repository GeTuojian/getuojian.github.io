module.exports = {
    replaceFollowStr: function(e) {
        if (!e) return "";
        var t = /\S+\.(?=jpe?g|png|webp|gif|GIF|WEBP|PNG|JPE?G)/i;
        try {
            return "".concat(e.match(t)[0]).concat(e.replace(t, "").match(/jpe?g|png|webp|gif|GIF|WEBP|PNG|JPE?G/i)[0]);
        } catch (t) {
            return e;
        }
    }
};