var e = require("../../../framework/mtdp_bucket/utils/lx_adaptor.js"), t = require("../../../framework/mtdp_bucket/utils/owl_adaptor.js"), i = require("../../../framework/class_define/http_protocol.js"), a = require("../../../framework/class_define/http_request_task.js"), o = require("../../../dpmapp/utils/page_url.js"), s = "/ugc/review/shop/shopreview", n = "b_4sho1bz2";

Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        reviewListParams: {
            type: Object,
            value: {}
        },
        lxData: {
            type: Object
        },
        tagConfig: {
            type: Object,
            value: {
                headJump: !0,
                showHead: !0
            }
        },
        hasApp: {
            type: Boolean,
            value: !1
        },
        popType: {
            type: String
        },
        needLogin: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        reviewTags: [],
        listView: {},
        show: !0
    },
    created: function() {},
    ready: function() {
        this.getData();
    },
    methods: {
        getData: function() {
            var e = this.data.reviewListParams || {}, t = parseInt(e.shopId) || 0, i = e.shopUuid || "";
            (t || i) && (this.setData({
                shopId: t,
                shopUuid: i,
                listView: {
                    firstLoading: !0
                },
                shopOptions: {
                    shopId: t,
                    shopUuid: i
                }
            }), this.fetchReviewList({
                shopId: t,
                shopUuid: i
            }));
        },
        handleClickTag: function(e) {
            var t = this, i = function() {
                var i = e.detail.target.dataset, a = i.type, o = i.keyword, s = i.hit;
                t.jump2List({
                    type: a,
                    keyword: o,
                    hit: s
                }), t.triggerEvent("revieweventlisten", {
                    hitTag: o,
                    tagType: a,
                    eventPosition: "listTagBtn"
                });
            };
            this.data.needLogin ? getApp().bridge.login().then(i) : i();
        },
        handleAllReview: function(t) {
            var i = this;
            e.moduleClick(n, this.data.lxData);
            var a = function() {
                i.triggerEvent("revieweventlisten", {
                    eventPosition: "listHeadBtn",
                    e: t
                });
            };
            this.data.needLogin ? getApp().bridge.login().then(a) : a();
        },
        jump2List: function() {
            var e, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = t.type, a = t.keyword, o = t.hit;
            this.data.shopUuid && (e = "shopUuid=".concat(this.data.shopUuid)), this.data.shopId && (e = "shopId=".concat(this.data.shopId)), 
            e && getApp().navigation.forwardTo({
                url: "".concat("/packages/ugc/pages/reviewlist/reviewlist", "?").concat(e, "&msource=wxappmain&hit=").concat(o, "&tagType=").concat(i, "&tag=") + encodeURIComponent(a)
            });
        },
        fetchReviewList: function(e) {
            var n = this, r = function(e) {
                t.addError("fetchReviewList fail:", e, !0), n.setData({
                    isError: !0,
                    listView: {
                        list: [],
                        listError: {
                            iconType: 2
                        },
                        isEnd: !1
                    }
                });
            }, d = {
                pageSize: 3,
                cx: "!",
                mtsiReferrer: encodeURIComponent(o.getCurrentPageUrlWithArgs()),
                isNeedNewReview: 1
            };
            e.shopUuid ? d.shopUuid = e.shopUuid : d.shopId = e.shopId, getApp().h.request(new a(new i(s, {
                data: d
            }), {
                callback: function(e) {
                    n.setData({
                        isLoading: !1,
                        showTagLoading: !1
                    }), wx.hideNavigationBarLoading(), getApp().sc.hideToast();
                    var t = e.serverData || null;
                    if (t && 200 === t.statusCode && t.data && 200 === t.data.code) if (t.data.shopReviewInfo) {
                        var i = t.data.shopReviewInfo, a = i.reviewTotalCount, o = i.reviewList, s = i.reviewTags, p = {
                            list: o || [],
                            showLoading: !1,
                            isEnd: !1,
                            firstLoading: !1
                        };
                        n.setData({
                            totalCount: a,
                            listView: p,
                            reviewTags: s || [],
                            isError: !1
                        });
                    } else r("加载评论出错，该商户不存在评价，shopid为".concat(d.shopUuid || d.shopId, ", res为").concat(JSON.stringify(t))); else r("网络出错了" + JSON.stringify(e));
                }
            }));
        },
        allReviewTap: function(t) {
            var i = this;
            e.moduleClick(n, this.data.lxData);
            var a = function() {
                i.triggerEvent("revieweventlisten", {
                    eventPosition: "listEndBtn",
                    e: t
                }), i.jump2List({
                    type: 0,
                    keyword: "全部",
                    hit: 0
                });
            };
            this.data.needLogin ? getApp().bridge.login().then(a) : a();
        },
        handleHorizontalScroll: function() {
            this.triggerEvent("horizontalscroll");
        },
        handleFindLazyLoadComponents: function() {
            this.triggerEvent("lazyload");
        }
    }
});