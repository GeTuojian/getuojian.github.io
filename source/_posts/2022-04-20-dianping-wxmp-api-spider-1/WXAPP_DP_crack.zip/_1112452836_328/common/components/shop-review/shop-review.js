var e = require("../../../framework/mtdp_bucket/utils/lx_adaptor.js"), t = require("../../../framework/class_define/component_base.js"), a = "b_6j5z6xfa", i = "b_dianping_nova_b_0vfknrak_mv", r = "b_0vfknrak", n = "b_7l0ayuo7";

t({
    behaviors: [],
    properties: {
        reviewList: {
            type: Object,
            vaule: {},
            observer: "_reviewListChange"
        },
        config: {
            type: Object,
            vaule: {}
        },
        reviewBid: {
            type: String
        },
        lxData: {
            type: Object
        },
        showReviewBottom: {
            type: Number,
            value: 0
        },
        shopId: {
            type: Number
        },
        shopUuid: {
            type: String
        },
        pageName: {
            type: String
        },
        shopOptions: {
            type: Object
        },
        lastReview: {
            type: Boolean
        },
        popType: {
            type: String,
            value: ""
        },
        needLogin: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        imgClass: "width: 160rpx;height: 160rpx;margin-right: 10rpx;border-radius: 6rpx;",
        sceneIsShare: !1,
        partialLength: 0
    },
    ready: function() {
        this.updateScene();
    },
    moved: function() {},
    detached: function() {},
    pageLifetimes: {
        show: function() {
            this.updateScene();
        }
    },
    methods: {
        updateScene: function() {
            var e = getApp(), t = e.bridge.getShowOptions() && e.bridge.getShowOptions().scene ? e.bridge.getShowOptions().scene : null;
            this.setData({
                sceneIsShare: "1036" === String(t)
            });
        },
        _reviewListChange: function(t) {
            var a = this;
            if (t) {
                var r = "width: 160rpx;height: 160rpx;margin-right: 10rpx;border-radius: 6rpx;";
                1 == t.length && (r = "width: 280rpx;height: 280rpx;border-radius: 12rpx;");
                var n = t.reviewPics.length > 3 ? 3 : t.reviewPics.length;
                this.setData({
                    imgClass: r,
                    partialLength: n
                }, function() {
                    e.moduleView(i, a.data.lxData);
                });
            }
        },
        previewImage: function(t) {
            var i = this;
            e.moduleClick(a, this.data.lxData);
            var r = function() {
                var e = t.target.dataset.id, a = i.data.reviewList.reviewPics, r = a[e];
                r && "video" == r.type ? getApp().navigation.forwardTo({
                    url: "".concat("/packages/video-preview/pages/index/index", "?video=").concat(r.videoUrl)
                }) : (a = a.map(function(e) {
                    return e.bigurl;
                }), wx.previewImage({
                    urls: a,
                    current: a[e]
                }), i.triggerEvent("previewImage"));
            };
            this.data.needLogin ? getApp().bridge.login().then(r) : r();
        },
        jumpToDetail: function(t) {
            var a = this;
            e.moduleClick(r, this.data.lxData);
            var i = function() {
                var e = t.currentTarget.dataset, i = e.review, r = e.url;
                a.gotoReviewDetail(i, r);
            };
            this.data.needLogin ? getApp().bridge.login().then(i) : i();
        },
        gotoReviewDetail: function(e, t) {
            !t && e && (t = e.detailUrl || ""), getApp().navigation.forwardTo({
                url: t
            });
        },
        navToPersonal: function() {
            var t = this.data, a = t.reviewList, i = t.pageName, r = t.lxData;
            e.moduleClick(n, r);
            var o = function() {
                var e = a.userId, t = a.anonymous, r = a.platform;
                if (!(t || 2 === r || e <= 0)) {
                    var n = "".concat("/packages/user/pages/personal/personal", "?offuserId=").concat(e, "&msource=").concat(i);
                    getApp().navigation.forwardTo({
                        url: n
                    });
                }
            };
            this.data.needLogin ? getApp().bridge.login().then(o) : o();
        }
    }
});