var t = Object.assign || function(t) {
    for (var e = 1; e < arguments.length; e++) {
        var a = arguments[e];
        for (var i in a) Object.prototype.hasOwnProperty.call(a, i) && (t[i] = a[i]);
    }
    return t;
};

Component({
    behaviors: [],
    properties: {
        wechatFingerprint: {
            type: String
        },
        dealid: {
            type: Number
        },
        cityid: {
            type: Number
        },
        shopid: {
            type: String
        },
        shopuuid: {
            type: String
        },
        sourcecode: {
            type: String
        },
        biztag: {
            type: String
        },
        orderstatus: {
            type: String
        },
        orderid: {
            type: String
        },
        env: {
            type: String
        },
        platform: {
            type: String
        },
        swimlane: {
            type: String
        },
        token: {
            type: String
        }
    },
    data: {
        scenetype: 1,
        messageShow: !1,
        messageShowStyle: !1,
        modelShow: !1,
        modelShowStyle: !1,
        isShow: !1,
        isEdit: !1,
        isValidate: !1,
        phonenumber: "",
        subTitle: "将使用该号码进行加密呼出",
        btnText: "立即呼叫",
        remark: [],
        title: "号码保护",
        hasBackupPhone: !1,
        shopBackupPhonePromptVO: {},
        userPhoneEmptyPrompt: ""
    },
    ready: function() {
        this.getVirtualPhoneNumber();
    },
    moved: function() {},
    detached: function() {},
    observers: {
        phonenumber: function(t) {
            this.setData({
                isValidate: /^1(3|4|5|6|7|8|9)\d{9}$/.test(t)
            });
        }
    },
    methods: {
        _reqwest: function(e) {
            var a = this, i = e.url, o = e.data, n = e.method;
            return new Promise(function(e, s) {
                var r = "dianping";
                "meituan" === a.data.platform && (r = "meituan");
                var d = {
                    url: i,
                    data: o,
                    header: {
                        token: a.data.token,
                        isMicroMessenger: "true",
                        appName: r
                    },
                    method: n
                };
                a.data.swimlane && (d.header["x-gw-mock"] = "true", d.header.swimlane = a.data.swimlane), 
                wx.request(t({
                    success: function(t) {
                        var a = t.statusCode, i = t.data;
                        200 === a ? e(i) : s({
                            code: a,
                            msg: "Server Exception"
                        });
                    },
                    fail: function() {
                        s({
                            code: 404,
                            msg: "WeiXin/Network Exception"
                        });
                    }
                }, d));
            });
        },
        _getDomain: function() {
            var t = "beta";
            "prod" === this.data.env && (t = "prod");
            var e = "dianping";
            return "meituan" === this.data.platform && (e = "meituan"), {
                prod: {
                    dianping: "mapi.dianping.com",
                    meituan: "mapi.meituan.com"
                },
                beta: {
                    dianping: "mapi.51ping.com",
                    meituan: "beta.mapi.meituan.com"
                }
            }[t][e];
        },
        getVirtualPhoneNumber: function() {
            var t = this;
            try {
                this._reqwest({
                    url: "https://".concat(this._getDomain(), "/dzgm/vn/checkvirtualnumber.bin"),
                    data: {
                        scenetype: this.data.scenetype,
                        shopid: this.data.shopid,
                        shopuuid: this.data.shopuuid,
                        sourcecode: this.data.sourcecode
                    },
                    method: "get"
                }).then(function(e) {
                    if (e.data && e.data.useVirtualNumber) {
                        var a = e.data.virtualNumberDialPopUpVO, i = a.userPhone, o = a.subTitle, n = a.btnText, s = a.remark, r = a.title, d = a.shopBackupPhonePromptVO, h = void 0 === d ? {} : d, u = a.hasBackupPhone, c = void 0 !== u && u, m = a.userPhoneEmptyPrompt, p = void 0 === m ? "" : m, l = a.promptUnderUserPhone, g = void 0 === l ? "请确保使用该号码进行呼叫" : l, S = {
                            isShow: !0,
                            modelShow: !0,
                            modelShowStyle: !0,
                            phonenumber: i,
                            isValidate: /^1(3|4|5|6|7|8|9)\d{9}$/.test(i),
                            subTitle: o,
                            btnText: n,
                            remark: s || [],
                            title: r,
                            hasBackupPhone: c,
                            shopBackupPhonePromptVO: h || {},
                            userPhoneEmptyPrompt: p,
                            promptUnderUserPhone: g
                        };
                        t.setData(S);
                    } else t.continue();
                }).catch(function() {
                    t.continue();
                });
            } catch (t) {
                this.continue();
            }
        },
        getRiskManagementParams: function() {
            var t = this.data;
            return {
                wechatFingerprint: t.wechatFingerprint,
                cityid: t.cityid,
                dealid: t.dealid
            };
        },
        checkRiskManagement: function(t) {
            return t.code && 502 === t.code;
        },
        dialNormalNumber: function() {
            this.callback(0);
        },
        dialBackupNumber: function() {
            this.callback(1);
        },
        callback: function(e) {
            var a = this;
            this.data.isValidate ? this._reqwest({
                url: "https://".concat(this._getDomain(), "/dzgm/vn/getvirtualnumber.bin"),
                data: t({
                    scenetype: this.data.scenetype,
                    shopid: this.data.shopid,
                    shopuuid: this.data.shopuuid,
                    sourcecode: this.data.sourcecode,
                    userphone: this.data.phonenumber,
                    biztag: this.data.biztag,
                    orderstatus: this.data.orderstatus,
                    orderid: this.data.orderid,
                    shopphoneindex: e
                }, this.getRiskManagementParams()),
                method: "POST"
            }).then(function(t) {
                t.success ? (a.close(), a.triggerEvent("resolve", t.data.virtualNumber, {})) : a.checkRiskManagement(t) ? wx.showToast({
                    title: t.message,
                    duration: 2e3,
                    icon: "none"
                }) : a.setData({
                    modelShow: !1,
                    modelShowStyle: !1,
                    messageShow: !0,
                    messageShowStyle: !0
                });
            }).catch(function() {
                a.setData({
                    modelShow: !1,
                    modelShowStyle: !1,
                    messageShow: !0,
                    messageShowStyle: !0
                });
            }) : wx.showToast({
                title: "请输入正确的11位手机号码",
                duration: 1500,
                icon: "none"
            });
        },
        close: function() {
            var t = this;
            this.setData({
                modelShowStyle: !1,
                messageShowStyle: !1
            });
            var e = setTimeout(function() {
                t.setData({
                    modelShow: !1,
                    messageShow: !1,
                    isShow: !1
                }), t.triggerEvent("close", !1, {}), clearTimeout(e);
            }, 400);
        },
        edit: function() {
            this.setData({
                isEdit: !0
            });
        },
        continue: function() {
            this.close(), this.triggerEvent("reject", !1, {});
        }
    }
});