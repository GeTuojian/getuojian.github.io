Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        listview: {
            type: Object,
            observer: function(t) {
                var e = t.list, i = t.supplyList, o = t.noResultGuidewords, r = t.firstLoading, n = t.listError, s = t.needBottom, l = t.tryAgain;
                l ? this.setData({
                    tryAgain: l
                }) : this.setData({
                    list: e || [],
                    supplyList: i || [],
                    noResultGuidewords: o || [],
                    firstLoading: r || !1,
                    listError: n || {},
                    needBottom: s || 0,
                    tryAgain: l || !1
                });
            }
        },
        pulldown: {
            type: Boolean,
            observer: function(t) {
                !0 !== t && "true" !== t || this.triggerEvent("pulldown");
            }
        },
        reachbottom: {
            type: Boolean,
            observer: function(t) {
                !0 !== t && "true" !== t || this.triggerEvent("reachbottom");
            }
        },
        queryid: {
            type: String,
            value: ""
        }
    },
    data: {
        list: [],
        supplyList: [],
        noResultGuidewords: [],
        firstLoading: !1,
        listError: {},
        needBottom: 0,
        tryAgain: !1
    },
    methods: {
        onExceptionEvent: function() {
            this.triggerEvent("exception");
        },
        tryAgain: function() {
            this.triggerEvent("tryagain");
        }
    }
});