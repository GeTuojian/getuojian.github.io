module.exports = {
    createChecker: function(e) {
        return {
            check: function() {
                return !0;
            },
            dispose: null
        };
    }
};