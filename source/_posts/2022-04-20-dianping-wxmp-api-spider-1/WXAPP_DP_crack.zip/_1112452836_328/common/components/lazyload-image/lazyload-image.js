var e = require("../../../framework/class_define/component_base.js"), t = require("./utils/check_image_in_sight.js"), a = {}, s = {
    properties: {
        src: {
            type: String,
            value: ""
        },
        mode: {
            type: String,
            value: "scaleToFill"
        },
        directShow: {
            type: Boolean,
            value: !1
        },
        imgClass: {
            type: String,
            value: ""
        }
    },
    data: {
        status: 0
    },
    created: function() {
        (this.properties.directShow || a[this.properties.src]) && this.setData({
            status: 3
        });
        var e = getCurrentPages(), t = e[e.length - 1];
        t && (t.__lazyImage ? t.__lazyImage.push(this) : (t.__lazyImage = [ this ], getApp().env.register(40044, r, t), 
        getApp().env.register(20012, n, t)), this.ownerPage = t);
    },
    attached: function() {
        i(this);
    },
    detached: function() {
        if (this.ownerPage && this.ownerPage.__lazyImage) {
            var e = this.ownerPage.__lazyImage.indexOf(this);
            this.ownerPage.__lazyImage.splice(e, 1), this.ownerPage = null;
        }
        this.checker && (this.checker.dispose && this.checker.dispose(), this.checker = null);
    },
    methods: {}
};

function r(e, t, a, s) {
    if (s === t.page) for (var r = s.__lazyImage, n = 0; n < r.length; n++) {
        var c = r[n];
        c.data.status >= 1 || i(c, t);
    }
}

function i(e, a) {
    e.checker || (e.checker = t.createChecker(e)), e.checker.check(a) && e.setData({
        status: 1
    });
}

function n(e, t, a, s) {
    if (s === t.page) {
        var i = s;
        i && i.__lazyImage && (getApp().env.unregister(40044, r, i), getApp().env.unregister(20012, n, i), 
        delete i.__lazyImage);
    }
}

s.methods.onImageLoad = function() {
    var e = this;
    a[e.data.imgSrc] = 1, e.setData({
        status: 2
    });
    var t = setTimeout(function() {
        clearTimeout(t), e.setData({
            status: 3
        });
    }, 600);
}, s.methods.onImageError = function(e) {
    getApp().env.notify(35001, {
        content: "图片加载失败:" + JSON.stringify(e),
        reason: "IMAGE_LOAD_ERROR",
        level: "error"
    });
}, e(s);