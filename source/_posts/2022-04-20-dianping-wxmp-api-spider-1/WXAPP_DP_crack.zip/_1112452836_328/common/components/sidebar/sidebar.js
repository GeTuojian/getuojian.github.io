var e = require("../../../framework/class_define/component_base.js"), i = require("../../widgets/sidebar/sidebar.js"), t = new i(), a = {
    data: t.getPrivateData(null),
    method: function() {
        var e = {};
        return t.injectPrivateFunction(e), e;
    },
    attached: function() {
        this._gearViewWidget = new i(), this._gearViewWidget.onPageInit(this);
    },
    detached: function() {
        this._gearViewWidget && (this._gearViewWidget.dispose(this), this._gearViewWidget = null);
    }
};

t.dispose(null), t = null, e(a);