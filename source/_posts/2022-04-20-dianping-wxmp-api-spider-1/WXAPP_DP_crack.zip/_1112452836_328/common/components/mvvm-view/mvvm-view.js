require("../../../framework/class_define/component_base.js")({
    properties: {
        subVM: Array,
        id: String,
        text: String,
        className: String,
        styleString: String,
        mvvmName: String,
        renderTime: Number
    },
    data: {},
    methods: {
        onTapMVVMElement: function(e) {
            var t = getCurrentPages(), r = t[t.length - 1];
            r && r.onTapMVVMElement && r.onTapMVVMElement(e);
        }
    }
});