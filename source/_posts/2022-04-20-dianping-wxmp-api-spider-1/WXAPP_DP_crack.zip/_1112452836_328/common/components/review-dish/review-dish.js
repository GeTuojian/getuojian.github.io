var e = require("../../../framework/mtdp_bucket/utils/lx_adaptor.js"), t = require("../../../framework/mtdp_bucket/utils/logan_adaptor.js"), a = require("../../../framework/class_define/component_base.js"), o = "b_8khz6xhm";

a({
    properties: {
        reviewDish: {
            type: Array
        },
        lxData: {
            type: Object
        },
        shopId: {
            type: Number
        },
        shopUuid: {
            type: String
        },
        needLogin: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    ready: function() {},
    moved: function() {},
    detached: function() {},
    methods: {
        torecommend: function(a) {
            t.log("跳转推荐菜");
            var r, n = a.currentTarget.dataset.shopid, i = a.currentTarget.dataset.shopuuid, c = a.currentTarget.dataset.id;
            e.moduleClick(o, this.data.lxData);
            var d = function() {
                r = i ? "https://m.dianping.com/shop/".concat(i, "/dish").concat(c, "?msource=mina_food") : "https://m.dianping.com/shop/".concat(n, "/dish").concat(c, "?msource=mina_food");
                try {
                    getApp().navigation.forwardTo({
                        url: "/pages/webview/webview?url=".concat(encodeURIComponent(r))
                    });
                } catch (e) {
                    t.log("跳转推荐菜: ".concat(JSON.stringify(e)));
                }
            };
            this.data.needLogin ? getApp().bridge.login().then(d) : d();
        }
    }
});