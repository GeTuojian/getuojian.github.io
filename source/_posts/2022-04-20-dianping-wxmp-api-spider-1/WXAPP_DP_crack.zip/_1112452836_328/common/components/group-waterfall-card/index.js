var e = require("../../../framework/mtdp_bucket/utils/lx_adaptor.js");

Component({
    properties: {
        item: {
            type: Object,
            value: null,
            observer: "itemChange"
        },
        index: {
            type: Number
        }
    },
    ready: function() {
        this._intersectionObserver();
    },
    methods: {
        itemChange: function(e) {
            e && Object.keys(e).length && this.setData({
                item: e,
                index: this.data.index
            });
        },
        onTap: function() {
            e.moduleClick("b_dianping_nova_small_procedures_reculike_mc", {
                query_id: this.data.item.queryId,
                title: this.data.item.title,
                index: this.data.index,
                custom: {
                    city_id: getApp().userData.dpCityId || 0,
                    user_id: getApp().userData.userid || "",
                    openid: getApp().userData.wxmpEncryptedOpenId || "",
                    unionid: getApp().userData.wxmpEncryptedUnionId || "",
                    content_id: this.data.item.itemId,
                    bussi_id: this.data.item.bizId,
                    module_id: 17,
                    show_style: "doubleList"
                }
            }), getApp().navigation.forwardTo({
                url: this.data.item.schema
            });
        },
        _moduleView: function() {
            e.moduleView("b_dianping_nova_small_procedures_reculike_mv", {
                query_id: this.data.item.queryId,
                title: this.data.item.title,
                index: this.data.index,
                custom: {
                    city_id: getApp().userData.dpCityId || 0,
                    user_id: getApp().userData.userid || "",
                    openid: getApp().userData.wxmpEncryptedOpenId || "",
                    unionid: getApp().userData.wxmpEncryptedUnionId || "",
                    content_id: this.data.item.itemId,
                    bussi_id: this.data.item.bizId,
                    module_id: 17,
                    show_style: "doubleList"
                }
            });
        },
        _intersectionObserver: function() {
            var e = this;
            if (!this._observer) try {
                this._observer = this.createIntersectionObserver().relativeToViewport(), this._observer.observe(".card", function(t) {
                    t && t.intersectionRatio > 0 && !e.hasExposed && (e._moduleView(), e._observer.disconnect(), 
                    e.hasExposed = !0);
                });
            } catch (e) {}
        }
    }
});