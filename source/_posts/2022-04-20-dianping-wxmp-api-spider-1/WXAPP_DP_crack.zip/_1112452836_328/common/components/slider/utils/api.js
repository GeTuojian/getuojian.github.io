var e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../../@babel/runtime/helpers/typeof")), r = e(require("../../../../@babel/runtime/helpers/classCallCheck")), o = e(require("../../../../@babel/runtime/helpers/createClass"));

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var a = require("./config.js"), n = function() {
    function e() {
        (0, r.default)(this, e);
    }
    return (0, o.default)(e, [ {
        key: "getPageData",
        value: function(e, t) {
            var r = {
                requestCode: e,
                feVersion: a.feVersion[t] || "0.1.0",
                source: a.source
            };
            return r._token = encodeURIComponent(a.rohr.r(r)), new Promise(function(e, t) {
                wx.request({
                    method: "POST",
                    url: "".concat(a.baseUrl, "/v2/ext_api/page_data"),
                    data: r,
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    success: function(r) {
                        var o = r.data, a = o.status, n = o.data, u = o.error;
                        200 === r.statusCode ? e({
                            status: a,
                            data: n,
                            error: u
                        }) : t(r);
                    },
                    fail: function(e) {
                        t(e);
                    }
                });
            });
        }
    }, {
        key: "sendInfo",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = e.request_code, o = e.type, n = e.action, u = void 0 === n ? "" : n, i = e.options, s = void 0 === i ? null : i, c = {
                request_code: r
            };
            if (s && "object" === (0, t.default)(s)) for (var d in s) s.hasOwnProperty(d) && (c[d] = s[d]);
            return c._token = encodeURIComponent(a.rohr.r(c)), new Promise(function(e, t) {
                wx.request({
                    url: "".concat(a.baseUrl, "/v2/ext_api/").concat(u, "/info?id=").concat(o),
                    method: "POST",
                    data: c,
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    success: function(r) {
                        var o = r.data, a = o.status, n = o.data, u = o.error;
                        200 === r.statusCode ? e({
                            status: a,
                            data: n,
                            error: u
                        }) : t("");
                    },
                    fail: function(e) {
                        t(e);
                    }
                });
            });
        }
    }, {
        key: "verify",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = e.request_code, o = e.type, n = e.action, u = void 0 === n ? "" : n, i = e.options, s = void 0 === i ? null : i, c = {
                request_code: r
            };
            if (s && "object" === (0, t.default)(s)) for (var d in s) s.hasOwnProperty(d) && (c[d] = s[d]);
            return c._token = encodeURIComponent(a.rohr.r(c)), new Promise(function(e, t) {
                wx.request({
                    url: "".concat(a.baseUrl, "/v2/ext_api/").concat(u, "/verify?id=").concat(o),
                    method: "POST",
                    data: c,
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    success: function(r) {
                        var o = r.data, a = o.status, n = o.data, u = o.error;
                        200 === r.statusCode ? e({
                            status: a,
                            data: n,
                            error: u
                        }) : t();
                    },
                    fail: function(e) {
                        t(e);
                    }
                });
            });
        }
    } ]), e;
}();

exports.default = n;