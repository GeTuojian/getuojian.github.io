var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../@babel/runtime/helpers/createClass"));

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var a, o = require("./konan.js"), n = (a = o) && a.__esModule ? a : {
    default: a
}, i = require("./utils/config.js");

var c = function() {
    function e() {
        (0, t.default)(this, e);
    }
    return (0, r.default)(e, null, [ {
        key: "getSystemInfo",
        value: function() {
            return wx.getSystemInfoSync();
        }
    }, {
        key: "getPageData",
        value: function(e) {
            var t = {
                requestCode: e,
                feVersion: i.feVersion.slider,
                source: i.source
            };
            return t._token = i.rohr.r(t), new Promise(function(e, r) {
                wx.request({
                    url: "".concat(i.baseUrl, "/v2/ext_api/page_data"),
                    method: "POST",
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    data: t,
                    success: function(t) {
                        var r = t.data.data || {}, a = r.action, o = r.type, n = r.request_code, i = r.notifyUrl;
                        e({
                            action: a,
                            id: o,
                            request_code: n,
                            notifyUrl: i
                        });
                    },
                    fail: function(e) {
                        r(e);
                    }
                });
            });
        }
    }, {
        key: "getNotifyUrl",
        value: function(e, t, r) {
            var a = -1 === e.indexOf("?") ? "?" : "&";
            return new Promise(function(o, n) {
                wx.request({
                    url: "".concat(e).concat(a, "request_code=").concat(t, "&response_code=").concat(r),
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    success: function(e) {
                        e.data;
                        o();
                    },
                    fail: function(e) {
                        o();
                    }
                });
            });
        }
    }, {
        key: "verfiySlide",
        value: function(e) {
            var t = e.action, r = e.id, a = e.requestCode, o = e.behavior, c = void 0 === o ? null : o, u = e.captchacode, s = void 0 === u ? "" : u, d = {
                id: r,
                request_code: a,
                fingerprint: ""
            }, l = this;
            return c && (d.behavior = n.default.Kaito(JSON.stringify(c), a)), s && (d.captchacode = s), 
            d._token = i.rohr.r(d), new Promise(function(e, a) {
                wx.request({
                    url: "".concat(i.baseUrl, "/v2/ext_api/").concat(t, "/verify?id=").concat(r),
                    method: "POST",
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    data: d,
                    success: function(t) {
                        var r = getApp().$loginPage.data.pageData, a = t.data, o = a.data, n = a.status, i = a.error;
                        if (1 === n && r.notifyUrl) {
                            var c = r.notifyUrl;
                            l.getNotifyUrl(c, r.request_code, o.response_code).then(function(t) {
                                e({
                                    status: n,
                                    error: i,
                                    data: o
                                });
                            });
                        } else e({
                            status: n,
                            error: i,
                            data: o
                        });
                    },
                    fail: function(e) {
                        a(e);
                    }
                });
            });
        }
    }, {
        key: "verfiyCode",
        value: function(e) {
            var t = e.action, r = e.id, a = e.requestCode, o = e.captchacode;
            return this.verfiySlide({
                action: t,
                id: r,
                requestCode: a,
                captchacode: o
            });
        }
    } ]), e;
}();

exports.default = c;