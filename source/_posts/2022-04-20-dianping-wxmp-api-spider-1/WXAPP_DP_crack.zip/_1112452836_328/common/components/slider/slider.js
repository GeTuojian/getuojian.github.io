var e = s(require("./sliderSDK.js")), t = s(require("./sliderAPI.js")), a = require("./utils/config.js"), i = require("../../../framework/class_define/component_base.js");

function s(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var o = getApp();

i({
    properties: {
        title: {
            type: String,
            value: "验证"
        },
        imgTitle: {
            type: String,
            value: "请输入图片中的内容"
        },
        imgButton: {
            type: String,
            value: "验证"
        }
    },
    data: {
        isShow: !1
    },
    methods: {
        showSlider: function(i) {
            var s = this, r = i.requestCode;
            a.rohr.i(a.rohrConfig.i), t.default.getPageData(r).then(function(t) {
                var a = new e.default({
                    requestCode: r,
                    pageData: t
                });
                o.$loginPage = s, s.setData({
                    sdk: a,
                    moveWidth: 0,
                    codeImage: "",
                    requestCode: r,
                    sliderCode: "",
                    isShow: !0,
                    validStep: "slider",
                    slideStatusClass: "",
                    animationData: {},
                    pageData: t
                });
            }).catch(function(e) {
                s.triggerEvent("sliderEvent", {
                    status: 0,
                    code: 99999,
                    error: e && e.errMsg || "slider API.getPageData error"
                }, {
                    bubbles: !0,
                    composed: !0
                });
            });
            var n = wx.createAnimation({
                transformOrigin: "50% 50%",
                duration: 500,
                timingFunction: "ease",
                delay: 0
            });
            this.animation = n;
        },
        sliderVerifySuccess: function(e) {
            var t = getApp().$loginPage, a = e && e.response_code || "", i = t.data.requestCode;
            wx.showToast({
                title: "验证成功",
                complete: function() {
                    t.setData({
                        isShow: !1
                    }), t.triggerEvent("sliderEvent", {
                        status: 1,
                        requestCode: i,
                        responseCode: a
                    }, {
                        bubbles: !0,
                        composed: !0
                    });
                }
            });
        },
        sliderTouchStart: function(e) {
            this.data.sdk.sliderTouchStart(e);
        },
        sliderTouchMove: function(e) {
            var t = this.data.sdk.sliderTouchMove(e), a = t.deltaX, i = "";
            t.isDone && (i = "slider-boxLoading"), this.setData({
                moveWidth: a,
                slideStatusClass: i
            });
        },
        sliderTouchEnd: function(e) {
            var t = this.data.sdk;
            t.isDone ? this.setData({
                slideStatusClass: "slider-boxLoading"
            }) : (t.sliderTouchEnd(e), this.setData({
                moveWidth: 0
            }));
        },
        sliderClose: function() {
            this.setData({
                isShow: !1
            }), this.triggerEvent("sliderEvent", {
                status: 0,
                code: 33333
            }, {
                bubbles: !0,
                composed: !0
            });
        },
        sliderValideCode: function(e) {
            var a = this, i = this.data, s = i.sliderCode, o = i.pageData, r = i.sdk.requestCode;
            t.default.verfiyCode({
                captchacode: s,
                action: o.action,
                id: 1,
                requestCode: r
            }).then(function(e) {
                var t = e.status, i = e.error, s = e.data;
                1 === t ? a.sliderVerifySuccess(s) : 0 === t && 121020 === i.code ? (wx.showToast({
                    title: i.message,
                    icon: "loading"
                }), a.sliderUpdataCaptch()) : wx.showToast({
                    title: i.message,
                    icon: "none",
                    duration: 2e3,
                    complete: function() {
                        a.triggerEvent("sliderEvent", {
                            status: 0,
                            code: i.code
                        }, {
                            bubbles: !0,
                            composed: !0
                        });
                    }
                });
            }, function(e) {
                a.triggerEvent("sliderEvent", {
                    status: 0,
                    code: 99999,
                    error: JSON.stringify(e) || "slider API.verfiyCode error"
                }, {
                    bubbles: !0,
                    composed: !0
                });
            });
        },
        sliderUpdataCaptch: function() {
            var e = this.data, t = e.requestCode, i = e.pageData;
            this.setData({
                codeImage: "".concat(a.baseUrl, "/v2/captcha?request_code=").concat(t, "&action=").concat(i.action, "&captchaHash=").concat(Number(new Date())),
                sliderCode: ""
            });
        },
        sliderValideCodeInput: function(e) {
            var t = e.detail.value;
            this.setData({
                sliderCode: t
            });
        },
        bindSliderInputFocus: function(e) {
            var t = this.data.animationData;
            this.animation.top(200).step(), t = this.animation.export(), this.setData({
                animationData: t
            });
        },
        bingSliderInputBlur: function(e) {
            var t = this.data.animationData;
            this.animation.top(300).step(), t = this.animation.export(), this.setData({
                animationData: t
            });
        },
        onTapPage: function(e) {
            a.rohr.t(e);
        },
        onTouchMovePage: function(e) {
            a.rohr.m(e);
        }
    }
});