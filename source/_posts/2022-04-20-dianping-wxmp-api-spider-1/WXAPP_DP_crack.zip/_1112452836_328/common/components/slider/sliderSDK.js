var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../@babel/runtime/helpers/slicedToArray")), i = e(require("../../../@babel/runtime/helpers/classCallCheck")), s = e(require("../../../@babel/runtime/helpers/createClass"));

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var o, n = require("./sliderAPI.js"), a = (o = n) && o.__esModule ? o : {
    default: o
}, r = require("./utils/config.js");

var u = function() {
    function e(t) {
        var s = t.requestCode, o = t.pageData;
        (0, i.default)(this, e);
        var n = (a.default.getSystemInfo() || {}).windowWidth, r = void 0 === n ? 375 : n, u = r / 375, d = [ 50 * u, 50 * u ], l = [ 270 * u, 52 * u ], c = [ 50 * u, 50 * u ], h = Date.now(), v = l[0] - d[0];
        Object.assign(this, {
            requestCode: s,
            windowWidth: r,
            zoom: u,
            btn: d,
            initTime: h,
            slideWidth: v,
            isDone: !1,
            zone: l,
            client: c,
            Timestamp: [ h ],
            count: 0,
            timeout: 0,
            points: null,
            trajectory: [],
            pageData: o
        });
    }
    return (0, s.default)(e, [ {
        key: "sliderTouchStart",
        value: function(e) {
            this.Timestamp.push(Date.now()), this.count += 1, this.points = [], this.addPoint(e);
        }
    }, {
        key: "sliderTouchMove",
        value: function(e) {
            var t = this.isDone, i = this.slideWidth;
            if (t) return {
                isDone: t,
                deltaX: i,
                slideWidth: i
            };
            var s = this.addPoint(e);
            return this.getPosition(s);
        }
    }, {
        key: "sliderTouchCancel",
        value: function(e) {
            this.slidEnd();
        }
    }, {
        key: "sliderTouchEnd",
        value: function(e) {}
    }, {
        key: "getPoint",
        value: function(e) {
            var t = e.touches[0] || {};
            return [ t.clientX, t.clientY ];
        }
    }, {
        key: "addPoint",
        value: function(e) {
            var i = this.points, s = this.initTime, o = this.getPoint(e), n = (0, t.default)(o, 2), a = n[0], r = n[1];
            return this.points = i || [], this.points.push([ 0, a, r, Date.now() - s ]), [ a, r ];
        }
    }, {
        key: "getPosition",
        value: function(e) {
            var i = (0, t.default)(e, 2), s = i[0], o = (i[1], this.slideWidth), n = (0, t.default)(this.points, 1)[0], a = this.isDone, r = s - n[1];
            return r < 0 && (r = 0), r >= o && (r = o, this.isDone = !0, this.slidEnd()), {
                deltaX: r,
                slideWidth: o,
                isDone: a
            };
        }
    }, {
        key: "slidEnd",
        value: function() {
            var e = this, t = e.trajectory, i = e.points, s = void 0 === i ? [] : i, o = e.Timestamp, n = e.pageData, u = void 0 === n ? {} : n, d = e.requestCode;
            (t = t.slice(-3, t.length)).push({
                point: s,
                vector: {
                    orientation: "h"
                }
            }), e.trajectory = t, e.points = null, o[o.length - 1] - o[0] > 3e3 && (e.timeout += 1), 
            e.setData();
            var l = u.action, c = u.id, h = {
                action: l,
                id: c,
                requestCode: d,
                behavior: e.behavior
            };
            a.default.verfiySlide(h).then(function(e) {
                var t = getApp().$loginPage, i = t.data.requestCode, s = e.data, o = e.status, n = e.error;
                if (1 === o) wx.showToast({
                    title: "验证成功",
                    complete: function() {
                        t.setData({
                            isShow: !1
                        });
                        var e = s && s.response_code || "";
                        t.triggerEvent("sliderEvent", {
                            status: 1,
                            requestCode: i,
                            responseCode: e
                        }, {
                            bubbles: !0,
                            composed: !0
                        });
                    }
                }); else if (0 === o && 121048 === n.code) {
                    var a = n.request_code;
                    t.setData({
                        "sdk.requestCode": a
                    }), t.setData({
                        codeImage: "".concat(r.baseUrl, "/v2/captcha?request_code=").concat(i, "&action=").concat(l),
                        validStep: "code"
                    });
                } else t.triggerEvent("sliderEvent", {
                    status: 0,
                    code: n.code
                }, {
                    bubbles: !0,
                    composed: !0
                });
            }).catch(function(e) {
                getApp().$loginPage.triggerEvent("sliderEvent", {
                    status: 0,
                    code: 99999
                }, {
                    bubbles: !0,
                    composed: !0
                });
            });
        }
    }, {
        key: "setData",
        value: function() {
            var e = this.zone, t = this.client, i = this.Timestamp, s = this.count, o = this.timeout, n = this.trajectory, a = {
                env: {
                    zone: e,
                    client: t,
                    Timestamp: i.slice(0, 2),
                    count: s,
                    timeout: o
                },
                trajectory: n
            };
            this.behavior = a;
        }
    } ]), e;
}();

exports.default = u;