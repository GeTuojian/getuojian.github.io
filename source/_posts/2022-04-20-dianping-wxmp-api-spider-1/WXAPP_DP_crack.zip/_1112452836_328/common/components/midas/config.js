exports.defaultConfig = function() {
    return {
        maxSendSize: 10
    };
}, exports.config = exports.defaultConfig();