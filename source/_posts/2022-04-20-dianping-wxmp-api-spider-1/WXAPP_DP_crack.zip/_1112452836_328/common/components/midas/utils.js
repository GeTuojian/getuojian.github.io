Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("./enum.js");

var t = /(?:^|&)act=[^?&=]*/gi, n = /(?:^|&)openid=([^?&=]*)/i, r = /(?:^|&)dpid=[^?&=]*/gi, i = /(?:^|&)adidx=[^?&=]*/gi, o = "", x = "", a = "", c = "";

function u() {
    try {
        return o || (o = decodeURIComponent(wx.getStorageSync("_lx_sdk_lxcuid") || ""));
    } catch (e) {}
}

function d() {
    try {
        return x || (x = decodeURIComponent(wx.getStorageSync("uuid") || ""));
    } catch (e) {}
}

function p() {
    try {
        return a || (a = decodeURIComponent(wx.getStorageSync("openid") || ""));
    } catch (e) {}
}

function g() {
    try {
        return c || (c = decodeURIComponent(wx.getStorageSync("unionid") || ""));
    } catch (e) {}
}

var l = 0;

function s() {
    var e = new Date().getTime();
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(t) {
        var n = (e + 16 * Math.random()) % 16 | 0;
        return e = Math.floor(e / 16), ("x" == t ? n : 3 & n | 8).toString(16);
    });
}

function v() {
    return new Date().getTime();
}

exports.buildActionUrl = function(o, x, a, c) {
    var s = u(), v = d(), y = p(), R = "";
    R += "&unionid=" + g() + "&adidx=" + x;
    var f = (o = o.replace(i, "")).match(n), m = f && f[1] || "";
    return y && m.length < 10 && (o.match(n) && (o = o.replace(n, "")), R += "&openid=" + y), 
    o.replace(t, ""), o = o.replace(r, ""), o += "&adClient=miniapp", c.serverType === e.SERVER_TYPE.MEITUAN ? o + "&act=" + a + (R += "&mtdpid=" + s + "&iuuid=" + v) + "&t=" + new Date().valueOf() + "&i=v1_" + ++l : o + "&act=" + a + (R += "&dpid=" + s) + "&t=" + new Date().valueOf() + "&i=v1_" + ++l;
}, exports.generateMillisecondTimestamp = v, exports.generateUUID = s, exports.getBaseUrl = function(t) {
    var n = t.serverType, r = t.env, i = e.SERVER_TYPE_URL[n] || e.SERVER_TYPE_URL[e.SERVER_TYPE.DIANPING];
    return (t.ishttps ? "https:" : "http:") + (i[r] || i[e.ENV.PRODUCT]);
}, exports.getJoinKey = function() {
    try {
        return s() + "-" + v();
    } catch (e) {
        return "";
    }
};