exports.lxParam = {
    loadLx: {
        eventName: "灵犀加载点",
        type: "moduleView",
        bid: "b_ad_load_mv"
    },
    impressionLx: {
        eventName: "灵犀曝光点",
        type: "moduleView",
        bid: "b_ad_launch_mv"
    },
    clickLx: {
        eventName: "灵犀点击点",
        type: "moduleClick",
        bid: "b_ad_launch_mc"
    },
    reachLX: {
        eventName: "灵犀到达点",
        type: "pageView",
        cid: "c_ad_adbase"
    }
};