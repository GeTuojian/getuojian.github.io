var a = require("./event.js"), t = require("./emitter.js"), e = require("./enum.js");

require("../../../framework/class_define/component_base.js")({
    externalClasses: [ "my-midas-class" ],
    properties: {
        env: {
            type: String,
            value: e.ENV.PRODUCT
        },
        serverType: {
            type: String,
            value: e.SERVER_TYPE.DIANPING
        },
        ishttps: {
            type: Boolean,
            value: !0
        },
        sendLoadPoint: {
            type: Boolean,
            value: !1
        },
        sendReachPoint: {
            type: Boolean,
            value: !1
        },
        adidx: {
            type: String,
            value: ""
        },
        feedback: {
            type: String,
            value: "",
            observer: "_feedbackChange"
        },
        extra: {
            type: String,
            value: ""
        },
        callbackParams: {
            type: String,
            value: ""
        },
        jumpLink: {
            type: String,
            value: ""
        },
        paddingTop: {
            type: String,
            value: ""
        },
        paddingRight: {
            type: String,
            value: ""
        },
        paddingBottom: {
            type: String,
            value: ""
        },
        paddingLeft: {
            type: String,
            value: ""
        }
    },
    data: {},
    methods: {
        onClick: function() {
            var a = this, e = function(e) {
                a.triggerEvent("clickend", a.data.callbackParams), a.data.jumpLink && getApp().navigation.forwardTo({
                    url: a.data.jumpLink,
                    success: function() {
                        a.data.sendReachPoint && a.data.feedback && t.sendReachPoint(a.data.feedback, a.data.adidx, a.data.extra, a.data);
                    },
                    fail: function(e) {
                        e && e.errMsg && (e.errMsg.indexOf("webview count limit exceed") > -1 || e.errMsg.indexOf("page limit") > -1) && getApp().navigation.redirectTo({
                            url: a.data.jumpLink,
                            success: function() {
                                a.data.sendReachPoint && a.data.feedback && t.sendReachPoint(a.data.feedback, a.data.adidx, a.data.extra, a.data);
                            }
                        });
                    }
                });
            };
            a.data.feedback && t.sendClickPoint(this.data.feedback, this.data.adidx, this.data.extra, a.data).then(e).catch(e);
        },
        _feedbackChange: function(a, e) {
            a && a !== e && (this.isSendImpression = !1, this.isSendLoadPoint = !1, this.data.sendLoadPoint && !this.isSendLoadPoint && this.data.feedback && (this.isSendLoadPoint = !0, 
            t.sendLoadPoint(this.data.feedback, this.data.adidx, this.data.extra, this.data)));
        }
    },
    created: function() {
        this.isSendLoadPoint = !1, this.isSendImpression = !1;
    },
    attached: function() {},
    ready: function() {
        var e = this;
        this.data.sendLoadPoint && !e.isSendLoadPoint && e.data.feedback && (e.isSendLoadPoint = !0, 
        t.sendLoadPoint(this.data.feedback, this.data.adidx, this.data.extra, e.data));
        var i = e.createSelectorQuery();
        i.selectViewport().fields({
            size: !0
        });
        var d = i.select(".midas-wraper").boundingClientRect(), n = this.data.paddingTop && parseFloat(this.data.paddingTop) || 0, s = this.data.paddingRight && parseFloat(this.data.paddingRight) || 0, o = this.data.paddingBottom && parseFloat(this.data.paddingBottom) || 0, r = this.data.paddingLeft && parseFloat(this.data.paddingLeft) || 0;
        this.__scroll = function() {
            e.isSendImpression || d.exec(function(a) {
                if (!e.isSendImpression) {
                    var i = a[0], d = a[1];
                    if (d && i) {
                        var c = d.top < i.height - o && d.bottom > 0 + n, p = d.left < i.width - r && d.right > 0 + s;
                        c && p && e.data.feedback && (e.isSendImpression = !0, t.sendImpressionPoint(e.data.feedback, e.data.adidx, e.data.extra, e.data));
                    }
                }
            });
        }, a.onScroll(this.__scroll), setTimeout(function() {
            e.__scroll();
        }, 10);
    },
    moved: function() {},
    detached: function() {
        a.offScroll(this.__scroll);
    }
});