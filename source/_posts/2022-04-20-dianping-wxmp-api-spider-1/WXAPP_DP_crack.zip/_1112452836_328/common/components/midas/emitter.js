var e = require("./config.js"), n = require("./enum.js"), o = require("./utils.js"), i = require("./bi.js"), t = require("../../../framework/mtdp_bucket/utils/lx_adaptor.js");

function r(e, n, i) {
    return function(e, n, o, i) {
        return new Promise(function(t, r) {
            wx.request({
                url: e,
                method: n,
                data: i,
                success: function() {
                    o(), t(!0);
                },
                fail: function(e) {
                    o(), r(e);
                }
            });
        }).catch(function() {});
    }(o.getBaseUrl(n) + "?" + e, "get", i);
}

function c(e, n, i) {
    return function(e, n, o) {
        return new Promise(function(i, t) {
            wx.request({
                url: e,
                data: {
                    data: JSON.stringify(n)
                },
                method: "POST",
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                success: function() {
                    o(), i(!0);
                },
                fail: function(e) {
                    o(), t(e);
                }
            });
        }).catch(function() {});
    }(o.getBaseUrl(n), e, i);
}

function u() {
    var n, o = [], i = e.config.maxSendSize || 10;
    function t() {
        n = setTimeout(function() {
            r();
        }, 200);
    }
    function r() {
        if (o.length) {
            var e = o.slice(0);
            o = [], c(e.map(function(e) {
                return e[0];
            }), e[0][1], e[0][2]);
        }
    }
    return function() {
        o.length > i && r(), n && clearTimeout(n), o.push(arguments), t();
    };
}

var a = u(), d = u();

exports.sendClickPoint = function(e, c, u, a) {
    var d = o.getJoinKey();
    return r(o.buildActionUrl(decodeURIComponent(e) + "&join_key=" + d + (u ? "&" + u : ""), c, n.ACT_TYPE.CLICK_POINT, a), a, function() {
        t.moduleClick(i.lxParam.clickLx.bid, {
            join_key: d,
            ad_feedback: e
        });
    });
}, exports.sendLoadPoint = function(e, r, c, u) {
    var d = o.getJoinKey();
    return a(encodeURIComponent(o.buildActionUrl(decodeURIComponent(e) + "&join_key=" + d + (c ? "&" + c : ""), r, n.ACT_TYPE.LOAD_POINT, u)), u, function() {
        t.moduleView(i.lxParam.loadLx.bid, {
            join_key: d,
            ad_feedback: e
        });
    });
}, exports.sendImpressionPoint = function(e, r, c, u) {
    var a = o.getJoinKey();
    return d(encodeURIComponent(o.buildActionUrl(decodeURIComponent(e) + "&join_key=" + a + (c ? "&" + c : ""), r, n.ACT_TYPE.IMPRESSION_POINT, u)), u, function() {
        t.moduleView(i.lxParam.impressionLx.bid, {
            join_key: a,
            ad_feedback: e
        });
    });
}, exports.sendReachPoint = function(e, c, u, a) {
    var d = o.getJoinKey();
    return r(o.buildActionUrl(decodeURIComponent(e) + "&join_key=" + d + (u ? "&" + u : ""), c, n.ACT_TYPE.REACH_POINT, a), a, function() {
        t.pageView(i.lxParam.reachLX.cid, {
            join_key: d,
            ad_feedback: e
        });
    });
};