var o = {};

function r(r, c) {
    r && c && (o[r] = o[r] || []).push(c);
}

function c(r, c) {
    if (r) if (void 0 !== c) for (var f = o[r] = o[r] || [], n = 100; n--; ) {
        var t = f.indexOf(c);
        if (-1 === t) break;
        f.splice(t, 1);
    } else o[r] = [];
}

function f(r, c, f) {
    (o[r] = o[r] || []).forEach(function(o) {
        o.call(f, c);
    });
}

exports.on = r, exports.off = c, exports.emit = f, exports.onScroll = function(o) {
    r("scroll", o);
}, exports.offScroll = function(o) {
    c("scroll", o);
}, exports.triggerScroll = function(o) {
    f("scroll", o);
};