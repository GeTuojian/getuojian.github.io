require("../../../framework/class_define/component_base.js")({
    properties: {
        star: {
            type: Number,
            value: 0
        },
        score: {
            type: String,
            value: ""
        },
        textStyle: {
            type: Object,
            value: {
                fontSize: "26rpx",
                marginLeft: "6rpx"
            }
        }
    },
    data: {
        newScore: ""
    },
    attached: function() {
        var e = (this.properties.score || "").split(".");
        this.properties.score && (e.length > 1 ? (this.properties.score = e[0] + "." + e[1].slice(0, 1), 
        this.setData({
            newScore: this.properties.score
        })) : 1 == e.length && (this.properties.score = e[0] + ".0", this.setData({
            newScore: this.properties.score
        })));
    },
    methods: {
        onTapStar: function(e) {
            var t = this.data.canClick, r = e.currentTarget.dataset.index;
            t && (this.setData({
                star: r
            }), this.triggerEvent("tapStar", {
                star: r
            }));
        }
    }
});