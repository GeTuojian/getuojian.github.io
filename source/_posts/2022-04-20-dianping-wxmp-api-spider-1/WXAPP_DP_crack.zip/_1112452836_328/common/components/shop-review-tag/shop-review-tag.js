var e = require("../../../framework/mtdp_bucket/utils/lx_adaptor.js"), t = require("../../../framework/class_define/component_base.js"), a = "b_qminz5z8", o = "b_4sho1bz2";

t({
    behaviors: [],
    properties: {
        pageName: {
            type: String
        },
        reviewTags: {
            type: Array
        },
        reviewCount: {
            type: Number
        },
        popType: {
            type: String,
            value: ""
        },
        hitTag: {
            type: String
        },
        moduleConfig: {
            type: Object,
            value: {
                headJump: !0,
                showHead: !0
            }
        },
        lxData: {
            type: Object
        },
        isAndroid: {
            type: Boolean
        },
        isList: {
            type: Boolean
        },
        shopOptions: {
            type: Object
        },
        showRightArrow: {
            type: Boolean,
            value: !0
        },
        needLogin: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    moved: function() {},
    detached: function() {},
    methods: {
        reviewTagAction: function(t) {
            var o = this.data, i = o.pageName, n = o.shopOptions, p = o.lxData;
            if (e.moduleClick(a, p), "detail" === i) {
                var s, r = t.currentTarget.dataset, c = r.keyword, d = r.type, g = r.hit;
                n && n.shopUuid && (s = "shopUuid=".concat(n.shopUuid)), n && n.shopId && (s = "shopId=".concat(n.shopId)), 
                s && getApp().navigation.forwardTo({
                    url: "".concat("/packages/ugc/pages/reviewlist/reviewlist", "?").concat(s, "&msource=wxappmain&hit=").concat(g, "&tagType=").concat(d, "&tag=") + encodeURIComponent(c)
                });
            } else this.triggerEvent("reviewTagAction", t);
        },
        allReviewTap: function() {
            var t = this, a = this.data, i = a.pageName, n = a.moduleConfig, p = n && n.headJump;
            if ("detail" === i || p) if (this.data.moduleConfig.gotoContact) this.triggerEvent("allReviewTap"); else {
                e.moduleClick(o, this.data.lxData);
                var s = function() {
                    var e, a = t.data.shopOptions;
                    a && a.shopUuid && (e = "shopUuid=".concat(a.shopUuid)), a && a.shopId && (e = "shopId=".concat(a.shopId)), 
                    e && getApp().navigation.forwardTo({
                        url: "".concat("/packages/ugc/pages/reviewlist/reviewlist", "?").concat(e, "&msource=wxappmain&tagType=").concat(1, "&tag=") + encodeURIComponent("全部")
                    });
                };
                this.data.needLogin ? getApp().bridge.login().then(s) : s();
            } else this.triggerEvent("clickAllReview");
        }
    }
});