var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../@babel/runtime/helpers/createClass")), a = e(require("../../../@babel/runtime/helpers/get")), i = e(require("../../../@babel/runtime/helpers/inherits")), n = e(require("../../../@babel/runtime/helpers/possibleConstructorReturn")), u = e(require("../../../@babel/runtime/helpers/getPrototypeOf"));

function s(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, a = (0, u.default)(e);
        if (t) {
            var i = (0, u.default)(this).constructor;
            r = Reflect.construct(a, arguments, i);
        } else r = a.apply(this, arguments);
        return (0, n.default)(this, r);
    };
}

var l = require("../gear_view_widget_base/gear_view_widget_base.js"), o = require("../../../framework/utils/layout_unit.js"), c = function(e) {
    (0, i.default)(l, e);
    var n = s(l);
    function l() {
        return (0, t.default)(this, l), n.call(this, "ViewSideIcon", 8, 80, 80, f);
    }
    return (0, r.default)(l, [ {
        key: "getPrivateData",
        value: function(e) {
            return Object.assign({
                sidebarAnime: "",
                sidebarHeight: ""
            }, (0, a.default)((0, u.default)(l.prototype), "getPrivateData", this).call(this));
        }
    }, {
        key: "onPageInit",
        value: function(e) {
            (0, a.default)((0, u.default)(l.prototype), "onPageInit", this).call(this, e), this._lastNum = this.rawDataFull.length, 
            this._lastNum && this.updatePageData();
        }
    } ]), l;
}(l);

function f(e, t) {
    if (e) {
        var r = this.rawDataFull.length, a = 0;
        if (this._lastNum === r ? t.sidebarAnime = "init-exist" : (this._lastNum < r ? (t.sidebarAnime = 0 === this._lastNum ? "slide-in" : "grow", 
        a = 1) : (a = -1, t.sidebarAnime = 0 === r ? "slide-out" : "degrade"), this._lastNum = r), 
        t.gearViewSideIconArray.forEach(function(e, t) {
            e.y = o(90 * t + 15);
        }), t.sidebarHeight = o(30 + 90 * Math.max(1, t.gearViewSideIconArray.length) - 10), 
        a < 0) {
            var i = t.gearViewSideIconArray.map(function(e) {
                return e.instanceUID;
            }), n = [];
            e.data.gearViewSideIconArray.forEach(function(e, r) {
                -1 === i.indexOf(e.instanceUID) && (e.isDegrade = 1, t.gearViewSideIconArray.splice(r, 0, e), 
                n.push(e.instanceUID));
            }), e.setData(t);
            var u = setTimeout(function() {
                clearTimeout(u);
                for (var t = e.data.gearViewSideIconArray, r = 0; r < t.length; ) -1 !== n.indexOf(t[r].instanceUID) ? t.splice(r, 1) : r++;
                e.setData({
                    gearViewSideIconArray: t
                });
            }, 450);
        } else if (a > 0) {
            var s = e.data.gearViewSideIconArray.map(function(e) {
                return e.instanceUID;
            });
            t.gearViewSideIconArray.forEach(function(e) {
                -1 === s.indexOf(e.instanceUID) && (e.isGrow = 1);
            }), e.setData(t);
        } else e.setData(t);
    }
}

module.exports = c;