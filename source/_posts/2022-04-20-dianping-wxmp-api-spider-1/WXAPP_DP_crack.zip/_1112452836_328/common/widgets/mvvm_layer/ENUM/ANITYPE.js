module.exports = {
    POPUP_PANEL: 1
};