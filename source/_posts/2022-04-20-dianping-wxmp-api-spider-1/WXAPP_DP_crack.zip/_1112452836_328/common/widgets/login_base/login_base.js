var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), i = e(require("../../../@babel/runtime/helpers/classCallCheck")), t = e(require("../../../@babel/runtime/helpers/createClass")), n = function() {
    function e(t) {
        var n = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        (0, i.default)(this, e), this._widgetInstanceArray = [ require("../../../pages/login/widgets/login_avatar/login_avatar.js"), require("../../../pages/login/widgets/wxmp_login/wxmp_login.js"), require("../../../pages/login/widgets/mobile_login/mobile_login.js"), require("../../../pages/login/widgets/hint_text/hint_text.js"), require("../../../pages/login/widgets/welcome/welcome.js"), require("../../../pages/login/widgets/policy/policy.js"), n ? require("../../../pages/login/widgets/delay_bind/delay_bind.js") : null ].filter(function(e) {
            return !!e;
        }).map(function(e) {
            return new e(t);
        });
    }
    return (0, t.default)(e, [ {
        key: "getPrivateData",
        value: function(e) {
            var i = this, t = {
                PAGE_CAN_HANDLE_TOKEN_REQUIRE: !0,
                loginStep: 1
            };
            return this._widgetInstanceArray.forEach(function(e) {
                if (e.getPrivateData) {
                    var n = e.getPrivateData(i);
                    Object.assign(t, n);
                }
            }), t;
        }
    }, {
        key: "injectPrivateFunction",
        value: function(e) {
            this._widgetInstanceArray.forEach(function(i) {
                i.injectPrivateFunction && i.injectPrivateFunction(e);
            });
        }
    }, {
        key: "onPageInit",
        value: function(e) {
            this._loadWxCodeService || (this._loadWxCodeService = !0, require("../../../pages/login/spec_service/wxcode_inject_service.js").setApp(getApp())), 
            this._widgetInstanceArray.forEach(function(i) {
                i.onPageInit && i.onPageInit(e);
            });
        }
    }, {
        key: "dispose",
        value: function(e) {
            this._loadWxCodeService && (require("../../../pages/login/spec_service/wxcode_inject_service.js").terminate(getApp()), 
            this._loadWxCodeService = !1), this._widgetInstanceArray && (this._widgetInstanceArray.forEach(function(i) {
                i.dispose && i.dispose(e);
            }), this._widgetInstanceArray = null);
        }
    } ]), e;
}();

module.exports = n;