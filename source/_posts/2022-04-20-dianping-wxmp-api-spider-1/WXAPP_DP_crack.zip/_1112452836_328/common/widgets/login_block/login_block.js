var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../@babel/runtime/helpers/classCallCheck")), r = e(require("../../../@babel/runtime/helpers/createClass")), n = e(require("../../../@babel/runtime/helpers/get")), l = e(require("../../../@babel/runtime/helpers/inherits")), u = e(require("../../../@babel/runtime/helpers/possibleConstructorReturn")), i = e(require("../../../@babel/runtime/helpers/getPrototypeOf"));

function a(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var r, n = (0, i.default)(e);
        if (t) {
            var l = (0, i.default)(this).constructor;
            r = Reflect.construct(n, arguments, l);
        } else r = n.apply(this, arguments);
        return (0, u.default)(this, r);
    };
}

var o = function(e) {
    (0, l.default)(o, e);
    var u = a(o);
    function o(e) {
        return (0, t.default)(this, o), u.call(this, e);
    }
    return (0, r.default)(o, [ {
        key: "injectPrivateFunction",
        value: function(e) {
            (0, n.default)((0, i.default)(o.prototype), "injectPrivateFunction", this).call(this, e), 
            e.onCompleteDelayBind = function() {}, e.onCancelDelayBind = function() {};
        }
    }, {
        key: "dispose",
        value: function(e) {
            e.onCompleteDelayBind = e.onCancelDelayBind = null, (0, n.default)((0, i.default)(o.prototype), "dispose", this).call(this, e);
        }
    } ]), o;
}(require("../login_base/login_base.js"));

module.exports = o;