var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../@babel/runtime/helpers/classCallCheck")), n = e(require("../../../@babel/runtime/helpers/createClass")), i = e(require("../../../@babel/runtime/helpers/get")), o = e(require("../../../@babel/runtime/helpers/inherits")), r = e(require("../../../@babel/runtime/helpers/possibleConstructorReturn")), u = e(require("../../../@babel/runtime/helpers/getPrototypeOf"));

function a(e) {
    var t = function() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
            !0;
        } catch (e) {
            return !1;
        }
    }();
    return function() {
        var n, i = (0, u.default)(e);
        if (t) {
            var o = (0, u.default)(this).constructor;
            n = Reflect.construct(i, arguments, o);
        } else n = i.apply(this, arguments);
        return (0, r.default)(this, n);
    };
}

var l = function(e) {
    (0, o.default)(l, e);
    var r = a(l);
    function l(e) {
        return (0, t.default)(this, l), r.call(this, e);
    }
    return (0, n.default)(l, [ {
        key: "getPrivateData",
        value: function() {
            return Object.assign({
                loginFade: "fade-in",
                showLoginPopup: !1
            }, (0, i.default)((0, u.default)(l.prototype), "getPrivateData", this).call(this));
        }
    }, {
        key: "injectPrivateFunction",
        value: function(e) {
            (0, i.default)((0, u.default)(l.prototype), "injectPrivateFunction", this).call(this, e), 
            e.onCloseLoginPopup = function() {
                e.setData({
                    loginFade: "fade-out"
                });
                var t = setTimeout(function() {
                    clearTimeout(t), e.setData({
                        showLoginPopup: !1
                    });
                }, 450);
                getApp().env.notify("__login_close_popup__"), getApp().env.notify(38002, null);
            }, e.onCompleteDelayBind = e.onCancelDelayBind = function() {
                e.setData({
                    loginFade: "fade-out"
                });
                var t = setTimeout(function() {
                    clearTimeout(t), e.setData({
                        showLoginPopup: !1
                    });
                }, 450);
                getApp().env.notify("__login_finish_popup__");
            };
        }
    }, {
        key: "onPageInit",
        value: function(e) {
            function t() {
                e.setData({
                    loginFade: "fade-in",
                    showLoginPopup: !0
                });
            }
            (0, i.default)((0, u.default)(l.prototype), "onPageInit", this).call(this, e), this.onRegisterPopup = function(n, i) {
                i.pageName === e.pageName && (this.onTokenRequire || (this.onTokenRequire = t.bind(this), 
                getApp().env.register(38001, this.onTokenRequire)));
            }.bind(this), getApp().env.register(20017, this.onRegisterPopup), this.onUnRegisterPopup = function(t, n) {
                n.pageName === e.pageName && this.onTokenRequire && (getApp().env.unregister(38001, this.onTokenRequire), 
                this.onTokenRequire = null);
            }.bind(this), getApp().env.register(20018, this.onUnRegisterPopup);
        }
    }, {
        key: "dispose",
        value: function(e) {
            e.onCompleteDelayBind = e.onCancelDelayBind = e.onCloseLoginPopup = null, this.onTokenRequire && (getApp().env.unregister(38001, this.onTokenRequire), 
            this.onTokenRequire = null), (0, i.default)((0, u.default)(l.prototype), "dispose", this).call(this, e);
        }
    } ]), l;
}(require("../login_base/login_base.js"));

module.exports = l;