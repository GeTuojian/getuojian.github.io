var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), r = e(require("../../../@babel/runtime/helpers/classCallCheck")), u = e(require("../../../@babel/runtime/helpers/createClass")), t = function() {
    function e() {
        (0, r.default)(this, e);
    }
    return (0, u.default)(e, [ {
        key: "dispose",
        value: function(e) {}
    } ]), e;
}();

module.exports = t;