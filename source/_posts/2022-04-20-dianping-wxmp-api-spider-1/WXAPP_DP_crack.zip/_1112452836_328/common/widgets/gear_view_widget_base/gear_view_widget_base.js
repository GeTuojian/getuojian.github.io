var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), i = e(require("../../../@babel/runtime/helpers/defineProperty")), t = e(require("../../../@babel/runtime/helpers/classCallCheck")), a = e(require("../../../@babel/runtime/helpers/createClass")), r = require("../../../framework/utils/layout_unit.js");

module.exports = function() {
    function e(i) {
        var a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1 / 0, r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0, n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : void 0, o = arguments.length > 4 && void 0 !== arguments[4] && arguments[4], s = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5];
        (0, t.default)(this, e), this._delgateViewName = i, this._maxIcon = a, this._widthBound = r, 
        this._heightBound = n, this._isSetData = s, this._useDataUpdateFunction = o, "function" == typeof o && (this.onViewNeedUpdate = o.bind(this), 
        this._useDataUpdateFunction = 1);
    }
    return (0, a.default)(e, [ {
        key: "getPrivateData",
        value: function(e) {
            return (0, i.default)({}, "gear" + this._delgateViewName + "Array", []);
        }
    }, {
        key: "injectPrivateFunction",
        value: function(e) {
            var i = this;
            e["onTap" + this._delgateViewName] = function(e) {
                for (var t, a = e.currentTarget.dataset, r = a.uid, n = a.issidebar, o = 0; o < i.rawDataFull.length; o++) if ((t = i.rawDataFull[o]).instanceUID === r) {
                    if (t.gear) {
                        if (n && getApp().env.notify(36001, {
                            behaviorType: "moduleClick",
                            data: {
                                bid: "b_dianping_nova_auyqsd03_mc",
                                activity_id: t.gear.activityId
                            }
                        }), t.gear.commonConfig.preventMultiClick && t._isTapping) return;
                        var s = getApp().workflow.createGearImpl(t.gear.commonConfig.clickAction);
                        s && (t._isTapping ? t._isTapping++ : t._isTapping = 1, s.completeFunction = function() {
                            t._isTapping--;
                        }, s.doAction());
                    }
                    return;
                }
            };
        }
    }, {
        key: "onPageInit",
        value: function(e) {
            var i = this;
            if (!this.onGearViewAddRemove) {
                this.onGearViewAddRemove = function(e, i) {
                    if (i.gear && i.gear.className !== t._delgateViewName) return;
                    var a = this.rawDataFull;
                    if ("__ON_GEAR_VIEW_ADD__" === e) o(a, i.gear); else if ("__ON_GEAR_VIEW_REMOVE__" === e) {
                        for (var r = 0; r < a.length; r++) {
                            var n = a[r];
                            if (n.instanceUID === i.gear.instanceUID) {
                                a.splice(r, 1);
                                break;
                            }
                            if (n.instanceUID === i.gear.imageUrl) {
                                delete n.gear;
                                break;
                            }
                        }
                        s(a);
                    }
                }.bind(this), getApp().env.register("__ON_GEAR_VIEW_ADD__", this.onGearViewAddRemove), 
                getApp().env.register("__ON_GEAR_VIEW_REMOVE__", this.onGearViewAddRemove);
                var t = this;
                this.rawDataFull || (this.rawDataFull = []), this.rawDataFull.forEach(function(e, i) {
                    void 0 === e.showPrority && (e.showPrority = 50), void 0 === e.sortPrority && (e.sortPrority = 50), 
                    e.index = i;
                });
                var a = getApp().gearViewMgr.getExistGearView(this._delgateViewName);
                if (a) {
                    this._isSetData = !1;
                    var n = Object.keys(a).length;
                    a.forEach(function(e, t) {
                        t === n - 1 && (i._isSetData = !0), o(i.rawDataFull, e);
                    });
                }
                return this.updatePageData = function(e) {
                    e && (i.rawDataFull = e), s(i.rawDataFull);
                }, void s(this.rawDataFull);
            }
            function o(i, t) {
                for (var a, r = !1, n = 0; n < i.length; n++) {
                    var o = i[n];
                    if (o.gear === t || o.gear && o.gear.instanceUID === t.instanceUID) return;
                    o.gear || (t.imageUrl !== o.instanceUID && t.instanceUID !== o.instanceUID || (r = !0, 
                    a = o));
                }
                if (a || (a = {
                    instanceUID: t.instanceUID,
                    index: i.length,
                    gear: t.commonConfig.clickAction ? t : null
                }), a.gear = t.commonConfig.clickAction ? t : null, a.showPrority = t.commonConfig.showPrority, 
                a.sortPrority = t.commonConfig.sortPrority, t.label && (a.label = t.label), t.imageUrl) if ("//" === t.imageUrl.substr(0, 2)) {
                    var g = e.data.pageProtocol || "https";
                    a.imageUrl = g + t.imageUrl;
                } else ("data:image" === t.imageUrl.substr(0, 10) || t.imageUrl.length > 10) && (a.imageUrl = t.imageUrl);
                t.contentId && (a.contentId = t.contentId), t.hasOwnProperty("imageWidth") && (a.imageWidth = t.imageWidth, 
                a.imageHeight = t.imageHeight), r || i.push(a), s(i);
            }
            function s(i) {
                var a, n = i.slice();
                n.sort(function(e, i) {
                    return e.showPrority === i.showPrority && e.sortPrority === i.sortPrority ? e.index - i.index : e.showPrority === i.showPrority ? e.sortPrority - i.sortPrority : e.showPrority - i.showPrority;
                }), (n = n.filter(function(i) {
                    if (!(i.showPrority >= 0 && i.showPrority < 65535)) return !1;
                    if (!i.gear || !i.gear.hasOwnProperty("pageList")) return !0;
                    var t = i.gear.pageList || "", r = !0;
                    33 === t.charCodeAt(0) && (t = t.substr(0), r = !1);
                    var n = t.split(",").map(function(e) {
                        return e.trim();
                    });
                    a || "mvvm" === (a = e.pageName) && (a = e.pageMVVMName);
                    var o = -1 !== n.indexOf(a);
                    return o && r || !o && !r;
                })).length > t._maxIcon && (n.length = t._maxIcon), n.sort(function(e, i) {
                    return e.sortPrority === i.sortPrority ? e.index - i.index : e.sortPrority - i.sortPrority;
                });
                var o = n.map(function(e) {
                    var i = Object.assign({}, e);
                    return void 0 !== t._widthBound && (void 0 === t._heightBound ? i.imageHeight = t._widthBound * i.imageHeight / i.imageWidth : (i.imageWidth = t._widthBound, 
                    i.imageHeight = t._heightBound)), void 0 !== t._heightBound && void 0 === t._widthBound && (i.imageWidth = t._heightBound * i.imageWidth / i.imageHeight), 
                    void 0 !== i.imageWidth && (i.imageWidth = r(i.imageWidth), i.imageHeight = r(i.imageHeight)), 
                    e.gear && e.gear.commonConfig && (e.gear.commonConfig.lxmc && (i.lxmc = e.gear.commonConfig.lxmc), 
                    e.gear.commonConfig.lxmv && (i.lxmv = e.gear.commonConfig.lxmv)), delete i.showPrority, 
                    delete i.sortPrority, delete i.index, delete i.gear, i;
                }), s = {};
                s["gear" + t._delgateViewName + "Array"] = o, t._isSetData && (t._useDataUpdateFunction ? t.onViewNeedUpdate && t.onViewNeedUpdate(e, s) : e.setData(s));
            }
        }
    }, {
        key: "dispose",
        value: function(e) {
            this.onGearViewAddRemove && (getApp().env.unregister("__ON_GEAR_VIEW_ADD__", this.onGearViewAddRemove), 
            getApp().env.unregister("__ON_GEAR_VIEW_REMOVE__", this.onGearViewAddRemove), this.onGearViewAddRemove = null), 
            this._delgateViewName && (null !== e && (e["onTap" + this._delgateViewName] = null), 
            this._delgateViewName = null), this.updatePageData = null, this.useDataUpdateFunction && (this.onViewNeedUpdate = null);
        }
    } ]), e;
}();