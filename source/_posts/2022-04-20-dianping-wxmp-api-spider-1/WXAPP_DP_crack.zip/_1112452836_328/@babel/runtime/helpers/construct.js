var setPrototypeOf = require("./setPrototypeOf");

function isNativeReflectConstruct() {
    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
    if (Reflect.construct.sham) return !1;
    if ("function" == typeof Proxy) return !0;
    try {
        return Date.prototype.toString.call(Reflect.construct(Date, [], function() {})), 
        !0;
    } catch (t) {
        return !1;
    }
}

function _construct(t, e, r) {
    return isNativeReflectConstruct() ? module.exports = _construct = Reflect.construct : module.exports = _construct = function(t, e, r) {
        var n = [ null ];
        n.push.apply(n, e);
        var o = new (Function.bind.apply(t, n))();
        return r && setPrototypeOf(o, r.prototype), o;
    }, _construct.apply(null, arguments);
}

module.exports = _construct;